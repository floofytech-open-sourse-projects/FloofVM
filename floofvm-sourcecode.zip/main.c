#include <stdint.h>
#include <stddef.h>
#include <string.h>

#include "uart.h"
#include "hdmi.h"
#include "usb.h"
#include "mmu.h"
#include "cpu.h"
#include "devices.h"
#include "interrupts.h"
#include "jit.h"
#include "loader.h"

/* -----------------------------------------------------------------------
 * Linker-exported symbols (defined in linker.ld)
 * --------------------------------------------------------------------- */
extern uint8_t _fb_start[];

/* -----------------------------------------------------------------------
 * Global subsystems
 * --------------------------------------------------------------------- */
static MMU        g_mmu;
static CPU        g_cpu;
static Devices    g_dev;
static Interrupts g_intr;
static JIT        g_jit;
static Loader     g_ldr;
static USBHost    g_usb;
static HDMI       g_hdmi;

/* -----------------------------------------------------------------------
 * USB image staging buffer at 0x80000000 (see linker.ld)
 * --------------------------------------------------------------------- */
#define USB_BUF_BASE 0x80000000UL
#define USB_BUF_SIZE (1UL * 1024 * 1024 * 1024)
static uint8_t * const g_usb_buf = (uint8_t *)(uintptr_t)USB_BUF_BASE;

#define GUEST_RAM_SIZE  (512UL * 1024 * 1024)
#define ISO_GUEST_BASE  0x10000000ULL
#define ISO_SECTOR      2048

/* -----------------------------------------------------------------------
 * status — print to both UART and HDMI
 * --------------------------------------------------------------------- */
static void status(const char *msg)
{
    uart_puts(msg);
    if (g_hdmi.ready)
        hdmi_puts(&g_hdmi, msg, 0xFFFFFFFF, 0xFF0A0A2E);
}

/* -----------------------------------------------------------------------
 * floofvm_load_iso
 * --------------------------------------------------------------------- */
void floofvm_load_iso(const uint8_t *iso_data, size_t iso_size)
{
    devices_mount_iso(&g_dev, iso_data, iso_size, ISO_GUEST_BASE);
    loader_boot_iso(&g_ldr);
}

/* -----------------------------------------------------------------------
 * build_demo_iso
 * --------------------------------------------------------------------- */
#define DEMO_NUM_SECTORS 21
static uint8_t s_demo_iso[DEMO_NUM_SECTORS * ISO_SECTOR];

static const uint8_t *build_demo_iso(size_t *out_size)
{
    memset(s_demo_iso, 0, sizeof(s_demo_iso));
    /* Sector 16: Boot Record Descriptor */
    { uint8_t *s=s_demo_iso+16*ISO_SECTOR; s[0]=0x00; memcpy(s+1,"CD001",5);
      s[6]=0x01; memcpy(s+7,"EL TORITO SPECIFICATION",23); s[71]=19; }
    /* Sector 17: PVD */
    { uint8_t *s=s_demo_iso+17*ISO_SECTOR; s[0]=0x01; memcpy(s+1,"CD001",5); s[6]=0x01; }
    /* Sector 18: Terminator */
    { uint8_t *s=s_demo_iso+18*ISO_SECTOR; s[0]=0xFF; memcpy(s+1,"CD001",5); s[6]=0x01; }
    /* Sector 19: Boot catalog */
    { uint8_t *s=s_demo_iso+19*ISO_SECTOR;
      s[0]=0x01; s[1]=0x00; memcpy(s+4,"FloofVM ",8); s[30]=0x55; s[31]=0xAA;
      uint8_t *e=s+32; e[0]=0x88; e[1]=0x00; e[6]=0x04; e[7]=0x00; e[8]=20; }
    /* Sector 20: Boot image — MOV RAX,0x42; MOV RBX,0x01; ADD RAX,RBX; HLT */
    { uint8_t *p=s_demo_iso+20*ISO_SECTOR; size_t i=0;
      p[i++]=0x01;p[i++]=0x00; p[i++]=0x42;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;
      p[i++]=0x01;p[i++]=0x01; p[i++]=0x01;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;p[i++]=0;
      p[i++]=0x03;p[i++]=0x00;p[i++]=0x01; p[i++]=0xFF; }
    *out_size = sizeof(s_demo_iso);
    return s_demo_iso;
}

/* -----------------------------------------------------------------------
 * usb_report_devices — log all enumerated USB devices to UART + HDMI
 * --------------------------------------------------------------------- */
static void usb_report_devices(void)
{
    static const char *class_names[] = {
        "None","Mass Storage","Keyboard","Mouse",
        "HID","Hub","CDC Serial","Audio","Printer","Unknown"
    };
    uart_printf("[USB] %d device(s) enumerated:\n", g_usb.n_devs);
    for (int i = 0; i < g_usb.n_devs; i++) {
        USBDev *d = &g_usb.devs[i];
        if (!d->active) continue;
        int ci = (int)d->dev_class;
        if (ci < 0 || ci > 8) ci = 9;
        uart_printf("  [%d] addr=%u VID=%04x PID=%04x class=%s\n",
                    i, d->dev_addr, d->vid, d->pid, class_names[ci]);
        if (g_hdmi.ready) {
            hdmi_puts(&g_hdmi, "  USB: ", 0xFF00FFFF, 0xFF0A0A2E);
            hdmi_puts(&g_hdmi, class_names[ci], 0xFF00FF00, 0xFF0A0A2E);
            hdmi_puts(&g_hdmi, "\n", 0xFFFFFFFF, 0xFF0A0A2E);
        }
    }
}

/* -----------------------------------------------------------------------
 * floofvm_main — bare-metal C entry point (called from startup.S)
 * --------------------------------------------------------------------- */
void floofvm_main(void)
{
    /* 1. UART */
    uart_init();
    uart_puts("\n\n========================================\n");
    uart_puts("  FloofVM -- ARM Firmware v1.0\n");
    uart_puts("========================================\n");

    /* 2. HDMI */
    uart_puts("[MAIN] Initialising HDMI...\n");
    if (hdmi_init(&g_hdmi, (uint32_t)(uintptr_t)_fb_start) == 0) {
        hdmi_splash(&g_hdmi);
        g_hdmi.cursor_x = 1;
        g_hdmi.cursor_y = (g_hdmi.height / 16) - 8;
        uart_puts("[MAIN] HDMI ready\n");
    } else {
        uart_puts("[MAIN] HDMI init failed -- continuing without display\n");
    }

    /* 3. MMU */
    status("[MAIN] Initialising MMU...\n");
    if (mmu_init(&g_mmu, GUEST_RAM_SIZE) != 0) {
        status("[MAIN] MMU FAILED -- halting\n");
        for (;;) __asm__ volatile("wfe");
    }

    /* 4-7. Core subsystems */
    devices_init(&g_dev);
    interrupts_init(&g_intr);
    jit_init(&g_jit, 1);
    cpu_init(&g_cpu, &g_mmu, &g_dev, &g_intr, &g_jit);
    cpu_reset(&g_cpu);
    loader_init(&g_ldr, &g_mmu, &g_cpu, &g_dev);

    /* 8. USB host — enumerate all devices */
    status("[MAIN] Initialising USB host...\n");
    int usb_devs = usb_host_init(&g_usb);

    if (usb_devs > 0) {
        usb_report_devices();

        /* Boot from the first mass-storage device found */
        USBDev *msc = usb_host_find(&g_usb, USB_DEV_MSC);
        if (msc) {
            status("[MAIN] USB MSC found -- reading ISO...\n");
            size_t iso_size = usb_msc_read_iso(msc, g_usb_buf, USB_BUF_SIZE);
            if (iso_size >= 17 * ISO_SECTOR) {
                uart_printf("[MAIN] ISO: %zu bytes\n", iso_size);
                if (g_hdmi.ready)
                    hdmi_puts(&g_hdmi, "[MAIN] Booting USB ISO...\n",
                              0xFF00FF00, 0xFF0A0A2E);
                g_dev.iso_from_usb = 1;
                floofvm_load_iso(g_usb_buf, iso_size);
            } else {
                status("[MAIN] USB image too small -- not ISO 9660\n");
            }
        } else {
            status("[MAIN] No MSC device -- running demo ISO\n");
            size_t sz; const uint8_t *demo = build_demo_iso(&sz);
            floofvm_load_iso(demo, sz);
        }
    } else {
        status("[MAIN] No USB devices found -- running demo ISO\n");
        size_t sz; const uint8_t *demo = build_demo_iso(&sz);
        floofvm_load_iso(demo, sz);
    }

    /* 9. Results */
    uart_puts("[MAIN] Execution complete\n");
    uart_puts("[MAIN] RAX = 0x"); uart_puthex64(g_cpu.regs[0]); uart_puts("\n");
    uart_puts("[MAIN] RIP = 0x"); uart_puthex64(g_cpu.rip);    uart_puts("\n");

    if (g_hdmi.ready) {
        g_hdmi.cursor_x = 1;
        g_hdmi.cursor_y = g_hdmi.height / 16 - 3;
        hdmi_puts(&g_hdmi, "Done. RAX=0x", 0xFF00FFFF, 0xFF0A0A2E);
        static const char hex[] = "0123456789abcdef";
        uint64_t rax = g_cpu.regs[0];
        char hbuf[17]; int hi = 16; hbuf[hi] = '\0';
        if (rax == 0) { hbuf[--hi] = '0'; }
        else { while (rax && hi > 0) { hbuf[--hi] = hex[rax & 0xF]; rax >>= 4; } }
        hdmi_puts(&g_hdmi, hbuf + hi, 0xFF00FFFF, 0xFF0A0A2E);
        g_hdmi.cursor_x = 1;
        g_hdmi.cursor_y = g_hdmi.height / 16 - 2;
        hdmi_puts(&g_hdmi, "FloofVM halted.", 0xFFFFAA00, 0xFF0A0A2E);
    }

    uart_puts("[MAIN] FloofVM halted.\n");
    for (;;) __asm__ volatile("wfe");
}
