#include "uart.h"
#include <stdarg.h>
#include <stdint.h>

/* -----------------------------------------------------------------------
 * Register access helpers
 * --------------------------------------------------------------------- */
static inline void mmio_write(uint32_t base, uint32_t off, uint32_t val)
{
    volatile uint32_t *reg = (volatile uint32_t *)(uintptr_t)(base + off);
    *reg = val;
}

static inline uint32_t mmio_read(uint32_t base, uint32_t off)
{
    volatile uint32_t *reg = (volatile uint32_t *)(uintptr_t)(base + off);
    return *reg;
}

/* -----------------------------------------------------------------------
 * uart_init — configure PL011 for 115200 8N1
 *
 * Baud divisor for a 24 MHz UART clock (QEMU virt default):
 *   Divisor = 24000000 / (16 * 115200) = 13.020833...
 *   IBRD = 13,  FBRD = round(0.020833 * 64) = 1
 *
 * For Raspberry Pi 4 (48 MHz UART clock):
 *   Divisor = 48000000 / (16 * 115200) = 26.041666...
 *   IBRD = 26,  FBRD = round(0.041666 * 64) = 3
 *   Override: -DUART_IBRD=26 -DUART_FBRD=3
 * --------------------------------------------------------------------- */
#ifndef UART_IBRD
#  define UART_IBRD 13
#endif
#ifndef UART_FBRD
#  define UART_FBRD 1
#endif

void uart_init(void)
{
    /* Disable UART */
    mmio_write(UART_BASE, PL011_CR, 0);
    /* Clear all pending interrupts */
    mmio_write(UART_BASE, PL011_ICR, 0x7FF);
    /* Set baud rate */
    mmio_write(UART_BASE, PL011_IBRD, UART_IBRD);
    mmio_write(UART_BASE, PL011_FBRD, UART_FBRD);
    /* 8N1, FIFO enabled */
    mmio_write(UART_BASE, PL011_LCR, PL011_LCR_FEN | PL011_LCR_8BIT);
    /* Mask all interrupts */
    mmio_write(UART_BASE, PL011_IMSC, 0);
    /* Enable UART, TX, RX */
    mmio_write(UART_BASE, PL011_CR,
               PL011_CR_UARTEN | PL011_CR_TXE | PL011_CR_RXE);
}

/* -----------------------------------------------------------------------
 * uart_putc — spin-wait until TX FIFO has space, then write one byte.
 * --------------------------------------------------------------------- */
void uart_putc(char c)
{
    while (mmio_read(UART_BASE, PL011_FR) & PL011_FR_TXFF)
        ;
    mmio_write(UART_BASE, PL011_DR, (uint32_t)(unsigned char)c);
}

/* -----------------------------------------------------------------------
 * uart_puts
 * --------------------------------------------------------------------- */
void uart_puts(const char *s)
{
    while (*s) {
        if (*s == '\n') uart_putc('\r');
        uart_putc(*s++);
    }
}

/* -----------------------------------------------------------------------
 * uart_puthex64 — print a 64-bit value as 16 hex digits, no prefix.
 * --------------------------------------------------------------------- */
void uart_puthex64(uint64_t v)
{
    static const char hex[] = "0123456789abcdef";
    for (int shift = 60; shift >= 0; shift -= 4) {
        uart_putc(hex[(v >> shift) & 0xF]);
    }
}

/* -----------------------------------------------------------------------
 * uart_putuint — print an unsigned decimal integer.
 * --------------------------------------------------------------------- */
void uart_putuint(uint64_t v)
{
    char buf[21];
    int  i = 20;
    buf[i] = '\0';
    if (v == 0) { uart_putc('0'); return; }
    while (v > 0 && i > 0) {
        buf[--i] = (char)('0' + (v % 10));
        v /= 10;
    }
    uart_puts(buf + i);
}

/* -----------------------------------------------------------------------
 * uart_printf — minimal subset of printf for bare-metal use.
 *
 * Supported format specifiers:
 *   %s   — string
 *   %c   — character
 *   %u   — unsigned int / unsigned long / unsigned long long
 *   %d   — signed int
 *   %x   — lowercase hex (32-bit)
 *   %llx — lowercase hex (64-bit)
 *   %llu — unsigned decimal (64-bit)
 *   %zu  — size_t (treated as 64-bit unsigned)
 *   %%   — literal '%'
 * --------------------------------------------------------------------- */
void uart_printf(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);

    for (const char *p = fmt; *p; p++) {
        if (*p != '%') {
            if (*p == '\n') uart_putc('\r');
            uart_putc(*p);
            continue;
        }
        p++;
        /* Handle 'll' length modifier */
        int longlong = 0;
        int longmod  = 0;
        if (*p == 'l') { p++; longmod = 1; }
        if (*p == 'l') { p++; longlong = 1; }
        if (*p == 'z') { p++; longlong = 1; } /* size_t */

        switch (*p) {
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            uart_puts(s);
            break;
        }
        case 'c':
            uart_putc((char)va_arg(ap, int));
            break;
        case 'u':
        case 'd': {
            uint64_t v;
            if (longlong)     v = (uint64_t)va_arg(ap, unsigned long long);
            else if (longmod) v = (uint64_t)va_arg(ap, unsigned long);
            else              v = (uint64_t)(unsigned)va_arg(ap, unsigned int);
            if (*p == 'd' && !longlong && !longmod) {
                int32_t sv = (int32_t)va_arg(ap, int);
                /* re-read as signed */
                (void)v;
                if (sv < 0) { uart_putc('-'); v = (uint64_t)(-sv); }
                else          v = (uint64_t)sv;
            }
            uart_putuint(v);
            break;
        }
        case 'x':
        case 'X': {
            uint64_t v;
            if (longlong)     v = (uint64_t)va_arg(ap, unsigned long long);
            else if (longmod) v = (uint64_t)va_arg(ap, unsigned long);
            else              v = (uint64_t)va_arg(ap, unsigned int);
            /* Print only as many nibbles as needed (min 1) */
            static const char hex[] = "0123456789abcdef";
            char buf[17]; int i = 16;
            buf[i] = '\0';
            if (v == 0) { buf[--i] = '0'; }
            else { while (v && i > 0) { buf[--i] = hex[v & 0xF]; v >>= 4; } }
            uart_puts(buf + i);
            break;
        }
        case '%':
            uart_putc('%');
            break;
        default:
            uart_putc('%');
            if (longlong) { uart_putc('l'); uart_putc('l'); }
            else if (longmod) uart_putc('l');
            uart_putc(*p);
            break;
        }
    }
    va_end(ap);
}
