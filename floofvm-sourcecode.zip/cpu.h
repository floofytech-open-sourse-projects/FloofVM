#ifndef CPU_H
#define CPU_H

#include <stdint.h>
#include <stddef.h>

struct MMU;
struct Devices;
struct Interrupts;
struct JIT;

#define REG_RAX  0
#define REG_RBX  1
#define REG_RCX  2
#define REG_RDX  3
#define REG_RSI  4
#define REG_RDI  5
#define REG_RBP  6
#define REG_RSP  7
#define REG_R8   8
#define REG_R9   9
#define REG_R10 10
#define REG_R11 11
#define REG_R12 12
#define REG_R13 13
#define REG_R14 14
#define REG_R15 15

#define RFLAGS_ZF (1ULL << 0)

/* FloofVM custom x86_64-like opcodes */
#define OP_MOV_RI  0x01  /* MOV reg, imm64    */
#define OP_MOV_RR  0x02  /* MOV reg, reg      */
#define OP_ADD_RR  0x03  /* ADD reg, reg      */
#define OP_SUB_RR  0x04  /* SUB reg, reg      */
#define OP_CMP_RR  0x05  /* CMP reg, reg      */
#define OP_JZ      0x06  /* JZ  rel32         */
#define OP_JMP     0x07  /* JMP rel32         */
#define OP_LOAD    0x08  /* LOAD dst, [base]  */
#define OP_STORE   0x09  /* STORE [base], src */
#define OP_HLT     0xFF  /* HLT               */

typedef struct CPU {
    uint64_t regs[16];
    uint64_t rip;
    uint64_t rsp;
    uint64_t rflags;
    int halted;
    struct MMU        *mmu;
    struct Devices    *dev;
    struct Interrupts *intr;
    struct JIT        *jit;
} CPU;

void cpu_init(CPU *cpu, struct MMU *mmu, struct Devices *dev,
              struct Interrupts *intr, struct JIT *jit);
void cpu_reset(CPU *cpu);
void cpu_step(CPU *cpu);
void cpu_run(CPU *cpu, size_t max_steps);

#endif /* CPU_H */
