#include "loader.h"
#include "mmu.h"
#include "cpu.h"
#include "devices.h"
#include "elf.h"
#include "uart.h"
#include <string.h>

#define ISO_SECTOR_SIZE       2048
#define ISO_SYSTEM_AREA_SECTS 16
#define ISO_VD_BOOT           0x00
#define ISO_VD_TERMINATOR     0xFF
#define ELTORITO_DEFAULT_ENTRY_OFFSET 32
#define ELTORITO_BOOTABLE     0x88
#define ELTORITO_MEDIA_NONE   0
#define BOOT_LOAD_ADDR        0x7C00ULL

static uint16_t le16(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}
static uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] <<  8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static int read_sector(const uint8_t *iso, size_t iso_size,
                       uint32_t lba, uint8_t *dst)
{
    uint64_t off = (uint64_t)lba * ISO_SECTOR_SIZE;
    if (off + ISO_SECTOR_SIZE > iso_size) {
        uart_printf("[LDR] Sector %u OOB\n", lba);
        return -1;
    }
    memcpy(dst, iso + off, ISO_SECTOR_SIZE);
    return 0;
}

void loader_init(Loader *ldr, struct MMU *mmu,
                 struct CPU *cpu, struct Devices *dev)
{
    ldr->mmu = mmu;
    ldr->cpu = cpu;
    ldr->dev = dev;
}

void loader_boot_iso(Loader *ldr)
{
    const uint8_t *iso      = ldr->dev->iso_data;
    size_t         iso_size = ldr->dev->iso_size;

    if (!iso || iso_size == 0) {
        uart_printf("[LDR] No ISO mounted\n");
        return;
    }

    uint8_t  sector[ISO_SECTOR_SIZE];
    uint32_t boot_catalog_lba = 0;
    int      found = 0;

    for (uint32_t lba = ISO_SYSTEM_AREA_SECTS; lba < 32; lba++) {
        if (read_sector(iso, iso_size, lba, sector) != 0) break;
        if (sector[0] == ISO_VD_TERMINATOR) break;
        if (memcmp(sector + 1, "CD001", 5) != 0) break;
        if (sector[0] == ISO_VD_BOOT &&
            memcmp(sector + 7, "EL TORITO SPECIFICATION", 23) == 0) {
            boot_catalog_lba = le32(sector + 71);
            found = 1;
            uart_printf("[LDR] El Torito catalog at LBA %u\n",
                        boot_catalog_lba);
            break;
        }
    }

    if (!found) {
        uart_printf("[LDR] El Torito boot record not found\n");
        return;
    }

    if (read_sector(iso, iso_size, boot_catalog_lba, sector) != 0) {
        uart_printf("[LDR] Cannot read boot catalog\n");
        return;
    }

    const uint8_t *entry = sector + ELTORITO_DEFAULT_ENTRY_OFFSET;
    uint8_t  boot_indicator = entry[0];
    uint8_t  media_type     = entry[1] & 0x0F;
    uint16_t sector_count   = le16(entry + 6);
    uint32_t load_lba       = le32(entry + 8);

    if (boot_indicator != ELTORITO_BOOTABLE) {
        uart_printf("[LDR] Entry not bootable (0x%x)\n",
                    (unsigned)boot_indicator);
        return;
    }
    if (load_lba == 0) {
        uart_printf("[LDR] Boot LBA is 0 -- invalid\n");
        return;
    }

    uart_printf("[LDR] Boot entry: media=%u lba=%u sectors=%u\n",
                (unsigned)media_type, load_lba, (unsigned)sector_count);

    uint32_t sectors_to_load = 1;
    if (sector_count > 0) {
        if (media_type == ELTORITO_MEDIA_NONE) {
            sectors_to_load = ((uint32_t)sector_count + 3) / 4;
            if (sectors_to_load == 0) sectors_to_load = 1;
        } else {
            sectors_to_load = sector_count;
        }
    }

    uint64_t guest_addr = BOOT_LOAD_ADDR;
    for (uint32_t s = 0; s < sectors_to_load; s++) {
        uint8_t buf[ISO_SECTOR_SIZE];
        if (read_sector(iso, iso_size, load_lba + s, buf) != 0) {
            uart_printf("[LDR] Cannot read boot sector %u\n", load_lba + s);
            break;
        }
        for (size_t b = 0; b < ISO_SECTOR_SIZE; b++)
            mmu_write8(ldr->mmu, guest_addr + b, buf[b]);
        guest_addr += ISO_SECTOR_SIZE;
    }

    ldr->cpu->rip    = BOOT_LOAD_ADDR;
    ldr->cpu->halted = 0;
    uart_printf("[LDR] Booting from 0x%llx\n",
                (unsigned long long)BOOT_LOAD_ADDR);
    cpu_run(ldr->cpu, 1000000);
}

void loader_boot_elf(Loader *ldr, const uint8_t *elf_data, size_t elf_size)
{
    if (elf_load(ldr->mmu, ldr->cpu, elf_data, elf_size) != 0) {
        uart_printf("[LDR] ELF load failed\n");
        return;
    }
    ldr->cpu->halted = 0;
    uart_printf("[LDR] ELF entry 0x%llx -- running\n",
                (unsigned long long)ldr->cpu->rip);
    cpu_run(ldr->cpu, 1000000);
}
