#ifndef USB_H
#define USB_H

#include <stdint.h>
#include <stddef.h>

/*
 * usb.h — USB 2.0 EHCI host controller + multi-class device driver stack
 *
 * Supported device classes
 * ─────────────────────────────────────────────────────────────────────
 *  0x01  Audio       – UAC 1.0  (mute/volume control)
 *  0x02  CDC/ACM     – Virtual serial port (set baud, read, write)
 *  0x03  HID
 *          Proto 0x01 → Keyboard  (boot-protocol 8-byte report + LED ctrl)
 *          Proto 0x02 → Mouse     (boot-protocol 4-byte report)
 *          Proto 0x00 → Generic   (gamepad / joystick / other HID)
 *  0x07  Printer     – Unidirectional and bidirectional (IEEE 1284)
 *  0x08  Mass Storage – BOT/SCSI (READ10, WRITE10, READ CAPACITY)
 *  0x09  Hub         – Single-TT, up to USB_HUB_MAX_PORTS downstream ports
 *
 * Architecture
 * ─────────────────────────────────────────────────────────────────────
 *  USBHost  – owns the EHCI controller and the flat device table
 *  USBDev   – one slot per enumerated device (up to USB_MAX_DEVICES)
 *
 * Transfer model: fully polled, no interrupts required.
 * Call usb_host_poll() from the main loop to service keyboard/mouse/HID.
 *
 * EHCI base: 0x08000000 (QEMU virt). Override: -DUSB_EHCI_BASE=0x...
 */

/* -----------------------------------------------------------------------
 * Tunable limits
 * --------------------------------------------------------------------- */
#define USB_MAX_DEVICES     16
#define USB_MAX_HUBS         4
#define USB_HUB_MAX_PORTS    7
#define USB_MAX_ENDPOINTS    8

/* -----------------------------------------------------------------------
 * EHCI base address
 * --------------------------------------------------------------------- */
#ifndef USB_EHCI_BASE
#  define USB_EHCI_BASE 0x08000000UL
#endif

/* -----------------------------------------------------------------------
 * EHCI register offsets
 * --------------------------------------------------------------------- */
#define EHCI_CAPLENGTH        0x00
#define EHCI_HCSPARAMS        0x04
#define EHCI_USBCMD           0x00
#define EHCI_USBSTS           0x04
#define EHCI_USBINTR          0x08
#define EHCI_FRINDEX          0x0C
#define EHCI_PERIODICLISTBASE 0x14
#define EHCI_ASYNCLISTADDR    0x18
#define EHCI_CONFIGFLAG       0x40
#define EHCI_PORTSC(n)       (0x44 + (n) * 4)

#define EHCI_CMD_RUN      (1u << 0)
#define EHCI_CMD_HCRESET  (1u << 1)
#define EHCI_CMD_ASE      (1u << 5)
#define EHCI_STS_HALT     (1u << 12)
#define EHCI_PORT_CONNECT  (1u << 0)
#define EHCI_PORT_ENABLED  (1u << 2)
#define EHCI_PORT_RESET    (1u << 8)
#define EHCI_PORT_POWER    (1u << 12)

/* -----------------------------------------------------------------------
 * USB standard constants
 * --------------------------------------------------------------------- */
#define USB_DIR_OUT           0x00
#define USB_DIR_IN            0x80
#define USB_TYPE_STANDARD     0x00
#define USB_TYPE_CLASS        0x20
#define USB_RECIP_DEVICE      0x00
#define USB_RECIP_INTERFACE   0x01
#define USB_RECIP_ENDPOINT    0x02

#define USB_REQ_CLEAR_FEATURE      0x01
#define USB_REQ_SET_ADDRESS        0x05
#define USB_REQ_GET_DESCRIPTOR     0x06
#define USB_REQ_SET_CONFIGURATION  0x09

#define USB_DT_DEVICE         0x01
#define USB_DT_CONFIG         0x02
#define USB_DT_INTERFACE      0x04
#define USB_DT_ENDPOINT       0x05
#define USB_DT_HUB            0x29

#define USB_EP_CONTROL        0x00
#define USB_EP_ISOCHRONOUS    0x01
#define USB_EP_BULK           0x02
#define USB_EP_INTERRUPT      0x03

#define USB_CLASS_AUDIO       0x01
#define USB_CLASS_CDC         0x02
#define USB_CLASS_HID         0x03
#define USB_CLASS_PRINTER     0x07
#define USB_CLASS_MASS_STOR   0x08
#define USB_CLASS_HUB         0x09
#define USB_CLASS_CDC_DATA    0x0A

#define USB_HID_PROTO_NONE      0x00
#define USB_HID_PROTO_KEYBOARD  0x01
#define USB_HID_PROTO_MOUSE     0x02

/* -----------------------------------------------------------------------
 * BOT / SCSI
 * --------------------------------------------------------------------- */
#define BOT_CBW_SIGNATURE    0x43425355UL
#define BOT_CSW_SIGNATURE    0x53425355UL
#define BOT_CBW_SIZE         31
#define BOT_CSW_SIZE         13
#define BOT_DIR_OUT          0x00
#define BOT_DIR_IN           0x80

#define SCSI_TEST_UNIT_READY 0x00
#define SCSI_INQUIRY         0x12
#define SCSI_READ_CAPACITY   0x25
#define SCSI_READ10          0x28
#define SCSI_WRITE10         0x2A

/* -----------------------------------------------------------------------
 * Hub class
 * --------------------------------------------------------------------- */
#define HUB_REQ_GET_STATUS      0x00
#define HUB_REQ_CLEAR_FEATURE   0x01
#define HUB_REQ_SET_FEATURE     0x03
#define HUB_REQ_GET_DESCRIPTOR  0x06
#define HUB_FEAT_PORT_RESET     0x04
#define HUB_FEAT_PORT_POWER     0x08
#define HUB_PORT_ST_CONNECT     (1u << 0)
#define HUB_PORT_ST_C_CONNECT   (1u << 16)

/* -----------------------------------------------------------------------
 * CDC/ACM class
 * --------------------------------------------------------------------- */
#define CDC_SUBCLASS_ACM          0x02
#define CDC_REQ_SET_LINE_CODING   0x20
#define CDC_REQ_GET_LINE_CODING   0x21
#define CDC_REQ_SET_CTRL_STATE    0x22

/* -----------------------------------------------------------------------
 * HID class
 * --------------------------------------------------------------------- */
#define HID_REQ_GET_REPORT   0x01
#define HID_REQ_SET_REPORT   0x09
#define HID_REQ_SET_IDLE     0x0A
#define HID_REQ_SET_PROTOCOL 0x0B

/* -----------------------------------------------------------------------
 * Audio (UAC 1.0) class
 * --------------------------------------------------------------------- */
#define AUDIO_REQ_SET_CUR    0x01
#define AUDIO_REQ_GET_CUR    0x81
#define AUDIO_CS_MUTE        0x01
#define AUDIO_CS_VOLUME      0x02

/* -----------------------------------------------------------------------
 * Printer class
 * --------------------------------------------------------------------- */
#define PRINTER_REQ_GET_PORT_STATUS  0x00
#define PRINTER_REQ_SOFT_RESET       0x02

/* -----------------------------------------------------------------------
 * Report structures
 * --------------------------------------------------------------------- */
typedef struct { uint8_t modifiers; uint8_t reserved; uint8_t keycode[6]; } USBKeyReport;
typedef struct { uint8_t buttons; int8_t dx; int8_t dy; int8_t wheel; }     USBMouseReport;
typedef struct { uint32_t baud; uint8_t stop; uint8_t parity; uint8_t bits; } CDCLineCoding;

/* -----------------------------------------------------------------------
 * Device class tag
 * --------------------------------------------------------------------- */
typedef enum {
    USB_DEV_NONE    = 0,
    USB_DEV_MSC     = 1,
    USB_DEV_KBD     = 2,
    USB_DEV_MOUSE   = 3,
    USB_DEV_HID     = 4,
    USB_DEV_HUB     = 5,
    USB_DEV_CDC     = 6,
    USB_DEV_AUDIO   = 7,
    USB_DEV_PRINTER = 8,
    USB_DEV_UNKNOWN = 255
} USBDevClass;

/* -----------------------------------------------------------------------
 * Cached endpoint
 * --------------------------------------------------------------------- */
typedef struct { uint8_t addr; uint8_t type; uint16_t mps; } USBEndpoint;

/* -----------------------------------------------------------------------
 * Per-device state
 * --------------------------------------------------------------------- */
typedef struct USBDev {
    int         active;
    USBDevClass dev_class;
    uint8_t     dev_addr;
    uint8_t     usb_class;
    uint8_t     usb_subclass;
    uint8_t     usb_protocol;
    uint16_t    vid;
    uint16_t    pid;
    uint8_t     num_eps;
    USBEndpoint eps[USB_MAX_ENDPOINTS];
    uint8_t     ep_bulk_in;
    uint8_t     ep_bulk_out;
    uint8_t     ep_intr_in;
    uint16_t    bulk_mps;
    uint16_t    intr_mps;
    uint32_t    op_base;

    union {
        struct { uint32_t num_blocks; uint32_t block_size; uint32_t bot_tag; } msc;
        struct { USBKeyReport   last; uint8_t leds; }                          kbd;
        struct { USBMouseReport last; }                                         mouse;
        struct { uint8_t report[64];  uint8_t len; }                           hid;
        struct { uint8_t num_ports;   uint8_t child[USB_HUB_MAX_PORTS]; }      hub;
        struct { CDCLineCoding lc; uint8_t ctrl_iface; uint8_t data_iface; }   cdc;
        struct { uint32_t sample_rate; uint8_t channels; int muted;
                 int16_t vol_db256; uint8_t ctrl_iface; uint8_t feature_unit; } audio;
        struct { uint8_t port_status; int bidir; }                             printer;
    } cls;
} USBDev;

/* -----------------------------------------------------------------------
 * Host controller state
 * --------------------------------------------------------------------- */
typedef struct USBHost {
    uint32_t op_base;
    uint8_t  num_ports;
    int      n_devs;
    USBDev   devs[USB_MAX_DEVICES];
} USBHost;

/* -----------------------------------------------------------------------
 * Public API — host
 * --------------------------------------------------------------------- */
int     usb_host_init(USBHost *host);
int     usb_host_poll(USBHost *host);
USBDev *usb_host_find(USBHost *host, USBDevClass cls);

/* -----------------------------------------------------------------------
 * Public API — Mass Storage
 * --------------------------------------------------------------------- */
int    usb_msc_read_blocks (USBDev *dev, uint32_t lba, uint32_t n, uint8_t *buf);
int    usb_msc_write_blocks(USBDev *dev, uint32_t lba, uint32_t n, const uint8_t *buf);
size_t usb_msc_read_iso    (USBDev *dev, uint8_t *buf, size_t buf_size);

/* -----------------------------------------------------------------------
 * Public API — HID Keyboard
 * --------------------------------------------------------------------- */
int usb_kbd_poll    (USBDev *dev, USBKeyReport   *rep);
int usb_kbd_set_leds(USBDev *dev, uint8_t leds);

/* -----------------------------------------------------------------------
 * Public API — HID Mouse
 * --------------------------------------------------------------------- */
int usb_mouse_poll(USBDev *dev, USBMouseReport *rep);

/* -----------------------------------------------------------------------
 * Public API — Generic HID
 * --------------------------------------------------------------------- */
int usb_hid_poll(USBDev *dev, uint8_t *buf, uint8_t *out_len);

/* -----------------------------------------------------------------------
 * Public API — CDC/ACM Serial
 * --------------------------------------------------------------------- */
int usb_cdc_set_line_coding(USBDev *dev, uint32_t baud,
                             uint8_t stop, uint8_t parity, uint8_t bits);
int usb_cdc_write(USBDev *dev, const uint8_t *buf, uint32_t len);
int usb_cdc_read (USBDev *dev,       uint8_t *buf, uint32_t len);

/* -----------------------------------------------------------------------
 * Public API — Audio (UAC 1.0)
 * --------------------------------------------------------------------- */
int usb_audio_set_mute  (USBDev *dev, int mute);
int usb_audio_set_volume(USBDev *dev, int16_t db256);

/* -----------------------------------------------------------------------
 * Public API — Printer
 * --------------------------------------------------------------------- */
int usb_printer_get_status(USBDev *dev, uint8_t *status_out);
int usb_printer_write     (USBDev *dev, const uint8_t *buf, uint32_t len);
int usb_printer_soft_reset(USBDev *dev);

#endif /* USB_H */
