#include "cpu.h"
#include "mmu.h"
#include "devices.h"
#include "interrupts.h"
#include "jit.h"
#include "uart.h"
#include <string.h>

void cpu_init(CPU *cpu, struct MMU *mmu, struct Devices *dev,
              struct Interrupts *intr, struct JIT *jit)
{
    memset(cpu, 0, sizeof(*cpu));
    cpu->mmu  = mmu;
    cpu->dev  = dev;
    cpu->intr = intr;
    cpu->jit  = jit;
}

void cpu_reset(CPU *cpu)
{
    memset(cpu->regs, 0, sizeof(cpu->regs));
    cpu->rip    = 0;
    cpu->rsp    = 0;
    cpu->rflags = 0;
    cpu->halted = 0;
}

/* Unified address-space read: ISO device mapping takes priority */
static uint8_t addr_read8(CPU *cpu, uint64_t addr)
{
    uint64_t base = cpu->dev->iso_base_addr;
    uint64_t sz   = (uint64_t)cpu->dev->iso_size;
    if (sz > 0 && addr >= base && addr < base + sz)
        return devices_read8(cpu->dev, addr);
    return mmu_read8(cpu->mmu, addr);
}

static uint64_t addr_read64(CPU *cpu, uint64_t addr)
{
    uint64_t v = 0;
    for (int i = 0; i < 8; i++)
        v |= ((uint64_t)addr_read8(cpu, addr + (uint64_t)i)) << (8 * i);
    return v;
}

static void addr_write8(CPU *cpu, uint64_t addr, uint8_t val)
{
    uint64_t base = cpu->dev->iso_base_addr;
    uint64_t sz   = (uint64_t)cpu->dev->iso_size;
    if (sz > 0 && addr >= base && addr < base + sz) {
        devices_write8(cpu->dev, addr, val);
        return;
    }
    mmu_write8(cpu->mmu, addr, val);
}

static void addr_write64(CPU *cpu, uint64_t addr, uint64_t val)
{
    for (int i = 0; i < 8; i++)
        addr_write8(cpu, addr + (uint64_t)i, (uint8_t)(val >> (8 * i)));
}

static uint8_t fetch8(CPU *cpu)
{
    uint8_t b = addr_read8(cpu, cpu->rip);
    cpu->rip++;
    return b;
}

static uint64_t fetch64(CPU *cpu)
{
    uint64_t v = addr_read64(cpu, cpu->rip);
    cpu->rip += 8;
    return v;
}

static int32_t fetch32(CPU *cpu)
{
    uint32_t v = 0;
    for (int i = 0; i < 4; i++)
        v |= ((uint32_t)addr_read8(cpu, cpu->rip + (uint64_t)i)) << (8 * i);
    cpu->rip += 4;
    return (int32_t)v;
}

void cpu_step(CPU *cpu)
{
    if (cpu->halted) return;

    /* Check for pending interrupts */
    uint8_t irq = 0;
    if (interrupts_fetch(cpu->intr, &irq)) {
        uint64_t vec = cpu->intr->vector_table[irq];
        if (vec != 0) {
            uart_printf("[CPU] IRQ %u -> vector 0x%llx\n",
                        (unsigned)irq, (unsigned long long)vec);
            cpu->rip = vec;
        }
    }

    /* Try JIT first */
    if (cpu->jit && cpu->jit->enabled) {
        if (jit_execute_block(cpu)) return;
    }

    uint8_t opcode = fetch8(cpu);

    switch (opcode) {
    case OP_MOV_RI: {
        uint8_t  dst = fetch8(cpu);
        uint64_t imm = fetch64(cpu);
        if (dst < 16) cpu->regs[dst] = imm;
        break;
    }
    case OP_MOV_RR: {
        uint8_t dst = fetch8(cpu);
        uint8_t src = fetch8(cpu);
        if (dst < 16 && src < 16) cpu->regs[dst] = cpu->regs[src];
        break;
    }
    case OP_ADD_RR: {
        uint8_t dst = fetch8(cpu);
        uint8_t src = fetch8(cpu);
        if (dst < 16 && src < 16) {
            cpu->regs[dst] += cpu->regs[src];
            cpu->rflags = (cpu->regs[dst] == 0) ? RFLAGS_ZF : 0;
        }
        break;
    }
    case OP_SUB_RR: {
        uint8_t dst = fetch8(cpu);
        uint8_t src = fetch8(cpu);
        if (dst < 16 && src < 16) {
            cpu->regs[dst] -= cpu->regs[src];
            cpu->rflags = (cpu->regs[dst] == 0) ? RFLAGS_ZF : 0;
        }
        break;
    }
    case OP_CMP_RR: {
        uint8_t a = fetch8(cpu);
        uint8_t b = fetch8(cpu);
        if (a < 16 && b < 16) {
            uint64_t result = cpu->regs[a] - cpu->regs[b];
            cpu->rflags = (result == 0) ? RFLAGS_ZF : 0;
        }
        break;
    }
    case OP_JZ: {
        int32_t rel = fetch32(cpu);
        if (cpu->rflags & RFLAGS_ZF)
            cpu->rip = (uint64_t)((int64_t)cpu->rip + (int64_t)rel);
        break;
    }
    case OP_JMP: {
        int32_t rel = fetch32(cpu);
        cpu->rip = (uint64_t)((int64_t)cpu->rip + (int64_t)rel);
        break;
    }
    case OP_LOAD: {
        uint8_t dst  = fetch8(cpu);
        uint8_t base = fetch8(cpu);
        if (dst < 16 && base < 16)
            cpu->regs[dst] = addr_read64(cpu, cpu->regs[base]);
        break;
    }
    case OP_STORE: {
        uint8_t base = fetch8(cpu);
        uint8_t src  = fetch8(cpu);
        if (base < 16 && src < 16)
            addr_write64(cpu, cpu->regs[base], cpu->regs[src]);
        break;
    }
    case OP_HLT:
        uart_printf("[CPU] HLT at RIP=0x%llx\n",
                    (unsigned long long)(cpu->rip - 1));
        cpu->halted = 1;
        break;
    default:
        uart_printf("[CPU] Unknown opcode 0x%x at RIP=0x%llx -- halting\n",
                    (unsigned)opcode,
                    (unsigned long long)(cpu->rip - 1));
        cpu->halted = 1;
        break;
    }

    cpu->rsp = cpu->regs[REG_RSP];
}

void cpu_run(CPU *cpu, size_t max_steps)
{
    for (size_t i = 0; i < max_steps && !cpu->halted; i++)
        cpu_step(cpu);
    if (!cpu->halted)
        uart_printf("[CPU] Step limit (%zu) reached\n", max_steps);
}
