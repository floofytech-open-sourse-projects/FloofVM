#ifndef INTERRUPTS_H
#define INTERRUPTS_H

#include <stdint.h>

typedef struct Interrupts {
    uint8_t  pending[256];
    uint64_t vector_table[256];
} Interrupts;

void interrupts_init(Interrupts *intr);
void interrupts_raise(Interrupts *intr, uint8_t irq);
int  interrupts_fetch(Interrupts *intr, uint8_t *irq_out);

#endif /* INTERRUPTS_H */
