#ifndef DEVICES_H
#define DEVICES_H

#include <stdint.h>
#include <stddef.h>

/*
 * devices.h — Virtual device bus
 *
 * Tracks the currently active ISO source (virtual CD-ROM or USB mass
 * storage image) and maps it into the guest address space.
 */

typedef struct Devices {
    const uint8_t *iso_data;
    size_t         iso_size;
    uint64_t       iso_base_addr;
    int            iso_from_usb;   /* 1 = image was read from USB device */
} Devices;

void    devices_init(Devices *dev);
void    devices_mount_iso(Devices *dev, const uint8_t *iso,
                          size_t size, uint64_t base_addr);
uint8_t devices_read8(Devices *dev, uint64_t addr);
void    devices_write8(Devices *dev, uint64_t addr, uint8_t value);

#endif /* DEVICES_H */
