#include "devices.h"
#include "uart.h"
#include <string.h>

void devices_init(Devices *dev)
{
    memset(dev, 0, sizeof(*dev));
}

void devices_mount_iso(Devices *dev, const uint8_t *iso,
                       size_t size, uint64_t base_addr)
{
    dev->iso_data      = iso;
    dev->iso_size      = size;
    dev->iso_base_addr = base_addr;
    uart_printf("[DEV] ISO mounted: %zu bytes at guest base 0x%llx%s\n",
                size, (unsigned long long)base_addr,
                dev->iso_from_usb ? " (from USB)" : "");
}

uint8_t devices_read8(Devices *dev, uint64_t addr)
{
    if (!dev->iso_data || dev->iso_size == 0) return 0;
    uint64_t base = dev->iso_base_addr;
    uint64_t sz   = (uint64_t)dev->iso_size;
    if (addr < base || addr >= base + sz) return 0;
    return dev->iso_data[addr - base];
}

void devices_write8(Devices *dev, uint64_t addr, uint8_t value)
{
    /* ISO/USB image mapping is read-only */
    (void)dev; (void)addr; (void)value;
}
