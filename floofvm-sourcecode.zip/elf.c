#include "elf.h"
#include "mmu.h"
#include "cpu.h"
#include "uart.h"
#include <string.h>

#define ELF_MAGIC0   0x7f
#define ELF_MAGIC1   'E'
#define ELF_MAGIC2   'L'
#define ELF_MAGIC3   'F'
#define ELFCLASS64   2
#define ELFDATA2LSB  1
#define ET_EXEC      2
#define EM_X86_64    62
#define PT_LOAD      1

static uint16_t le16(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}
static uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static uint64_t le64(const uint8_t *p)
{
    return (uint64_t)le32(p) | ((uint64_t)le32(p + 4) << 32);
}

#define EI_NIDENT    16
#define OFF_E_TYPE   (EI_NIDENT)
#define OFF_E_MACHINE (EI_NIDENT + 2)
#define OFF_E_ENTRY  (EI_NIDENT + 8)
#define OFF_E_PHOFF  (EI_NIDENT + 16)
#define OFF_E_PHENTSIZE (EI_NIDENT + 36)
#define OFF_E_PHNUM  (EI_NIDENT + 38)

#define OFF_PH_TYPE   0
#define OFF_PH_OFFSET 8
#define OFF_PH_VADDR  16
#define OFF_PH_FILESZ 32
#define OFF_PH_MEMSZ  40
#define PHDR_SIZE     56

int elf_load(struct MMU *mmu, struct CPU *cpu,
             const uint8_t *data, size_t size)
{
    if (size < EI_NIDENT + 48) {
        uart_printf("[ELF] File too small\n");
        return -1;
    }
    if (data[0] != ELF_MAGIC0 || data[1] != ELF_MAGIC1 ||
        data[2] != ELF_MAGIC2 || data[3] != ELF_MAGIC3) {
        uart_printf("[ELF] Bad magic\n");
        return -1;
    }
    if (data[4] != ELFCLASS64) { uart_printf("[ELF] Not ELF64\n"); return -1; }
    if (data[5] != ELFDATA2LSB){ uart_printf("[ELF] Not LE\n");    return -1; }

    uint16_t e_type     = le16(data + OFF_E_TYPE);
    uint16_t e_machine  = le16(data + OFF_E_MACHINE);
    uint64_t e_entry    = le64(data + OFF_E_ENTRY);
    uint64_t e_phoff    = le64(data + OFF_E_PHOFF);
    uint16_t e_phentsize= le16(data + OFF_E_PHENTSIZE);
    uint16_t e_phnum    = le16(data + OFF_E_PHNUM);

    if (e_type    != ET_EXEC)   { uart_printf("[ELF] Not ET_EXEC\n"); return -1; }
    if (e_machine != EM_X86_64) { uart_printf("[ELF] Not x86_64\n"); return -1; }
    if (e_phentsize < PHDR_SIZE){ uart_printf("[ELF] Phdr too small\n"); return -1; }

    for (uint16_t i = 0; i < e_phnum; i++) {
        uint64_t ph_off = e_phoff + (uint64_t)i * e_phentsize;
        if (ph_off + PHDR_SIZE > size) { uart_printf("[ELF] Phdr OOB\n"); return -1; }

        const uint8_t *ph = data + ph_off;
        if (le32(ph + OFF_PH_TYPE) != PT_LOAD) continue;

        uint64_t p_offset = le64(ph + OFF_PH_OFFSET);
        uint64_t p_vaddr  = le64(ph + OFF_PH_VADDR);
        uint64_t p_filesz = le64(ph + OFF_PH_FILESZ);
        uint64_t p_memsz  = le64(ph + OFF_PH_MEMSZ);

        if (p_offset + p_filesz > size)        { uart_printf("[ELF] Seg OOB file\n"); return -1; }
        if (p_vaddr  + p_memsz  > mmu->size)   { uart_printf("[ELF] Seg OOB RAM\n");  return -1; }

        for (uint64_t b = 0; b < p_memsz;  b++) mmu_write8(mmu, p_vaddr + b, 0);
        for (uint64_t b = 0; b < p_filesz; b++) mmu_write8(mmu, p_vaddr + b, data[p_offset + b]);

        uart_printf("[ELF] Seg %u: 0x%llx bytes -> vaddr 0x%llx\n",
                    (unsigned)i, (unsigned long long)p_filesz,
                    (unsigned long long)p_vaddr);
    }

    cpu->rip = e_entry;
    uart_printf("[ELF] Entry: 0x%llx\n", (unsigned long long)e_entry);
    return 0;
}
