#ifndef UART_H
#define UART_H

#include <stdint.h>
#include <stddef.h>

/*
 * uart.h — ARM PL011 UART driver (bare-metal)
 *
 * Default base address matches QEMU's aarch64 "virt" machine and the
 * Raspberry Pi 4 PL011 UART0.  Override UART_BASE in your build flags
 * if your board maps it elsewhere, e.g.:
 *   -DUART_BASE=0xFF000000
 *
 * For Raspberry Pi 3 (mini UART / AUX UART) you will need a different
 * register layout; substitute the appropriate base address and init
 * sequence for that peripheral.
 */

#ifndef UART_BASE
#  define UART_BASE 0x09000000UL   /* QEMU virt AArch64 default */
#endif

/* PL011 register offsets (word-addressed, each 4 bytes wide) */
#define PL011_DR    0x000   /* Data Register          */
#define PL011_FR    0x018   /* Flag Register          */
#define PL011_IBRD  0x024   /* Integer Baud Rate      */
#define PL011_FBRD  0x028   /* Fractional Baud Rate   */
#define PL011_LCR   0x02C   /* Line Control Register  */
#define PL011_CR    0x030   /* Control Register       */
#define PL011_IMSC  0x038   /* Interrupt Mask Set/Clr */
#define PL011_ICR   0x044   /* Interrupt Clear        */

/* FR bits */
#define PL011_FR_TXFF (1u << 5)  /* TX FIFO full  */
#define PL011_FR_RXFE (1u << 4)  /* RX FIFO empty */

/* CR bits */
#define PL011_CR_UARTEN (1u << 0)
#define PL011_CR_TXE    (1u << 8)
#define PL011_CR_RXE    (1u << 9)

/* LCR bits — 8N1 with FIFO enabled */
#define PL011_LCR_FEN  (1u << 4)   /* FIFO enable    */
#define PL011_LCR_8BIT (3u << 5)   /* Word length 8  */

void    uart_init(void);
void    uart_putc(char c);
void    uart_puts(const char *s);
void    uart_puthex64(uint64_t v);
void    uart_putuint(uint64_t v);
void    uart_printf(const char *fmt, ...);

#endif /* UART_H */
