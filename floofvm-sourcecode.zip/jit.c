#include "jit.h"
#include "cpu.h"
#include "mmu.h"
#include "devices.h"
#include "uart.h"
#include <string.h>

void jit_init(JIT *jit, int enabled)
{
    jit->enabled = enabled;
}

#define JIT_BLOCK_MAX 64

static uint8_t peek8(struct CPU *cpu, uint64_t addr)
{
    uint64_t base = cpu->dev->iso_base_addr;
    uint64_t sz   = (uint64_t)cpu->dev->iso_size;
    if (sz > 0 && addr >= base && addr < base + sz)
        return devices_read8(cpu->dev, addr);
    return mmu_read8(cpu->mmu, addr);
}

static uint8_t jit_fetch8(struct CPU *cpu)
{
    uint8_t b = peek8(cpu, cpu->rip);
    cpu->rip++;
    return b;
}

static uint64_t jit_fetch64(struct CPU *cpu)
{
    uint64_t v = 0;
    for (int i = 0; i < 8; i++)
        v |= ((uint64_t)peek8(cpu, cpu->rip + (uint64_t)i)) << (8 * i);
    cpu->rip += 8;
    return v;
}

int jit_execute_block(struct CPU *cpu)
{
    if (!cpu->jit || !cpu->jit->enabled) return 0;

    uint8_t first = peek8(cpu, cpu->rip);
    if (first != OP_MOV_RI && first != OP_MOV_RR &&
        first != OP_ADD_RR && first != OP_SUB_RR &&
        first != OP_HLT)
        return 0;

    int count = 0;
    while (!cpu->halted && count < JIT_BLOCK_MAX) {
        uint8_t op = peek8(cpu, cpu->rip);

        if (op == OP_MOV_RI) {
            cpu->rip++;
            uint8_t  dst = jit_fetch8(cpu);
            uint64_t imm = jit_fetch64(cpu);
            if (dst < 16) cpu->regs[dst] = imm;

        } else if (op == OP_MOV_RR) {
            cpu->rip++;
            uint8_t dst = jit_fetch8(cpu);
            uint8_t src = jit_fetch8(cpu);
            if (dst < 16 && src < 16) cpu->regs[dst] = cpu->regs[src];

        } else if (op == OP_ADD_RR) {
            cpu->rip++;
            uint8_t dst = jit_fetch8(cpu);
            uint8_t src = jit_fetch8(cpu);
            if (dst < 16 && src < 16) {
                cpu->regs[dst] += cpu->regs[src];
                cpu->rflags = (cpu->regs[dst] == 0) ? RFLAGS_ZF : 0;
            }

        } else if (op == OP_SUB_RR) {
            cpu->rip++;
            uint8_t dst = jit_fetch8(cpu);
            uint8_t src = jit_fetch8(cpu);
            if (dst < 16 && src < 16) {
                cpu->regs[dst] -= cpu->regs[src];
                cpu->rflags = (cpu->regs[dst] == 0) ? RFLAGS_ZF : 0;
            }

        } else if (op == OP_HLT) {
            cpu->rip++;
            uart_printf("[JIT] HLT at RIP=0x%llx\n",
                        (unsigned long long)(cpu->rip - 1));
            cpu->halted = 1;
            count++;
            break;

        } else {
            break;
        }
        count++;
    }

    cpu->rsp = cpu->regs[REG_RSP];
    return count > 0 ? 1 : 0;
}
