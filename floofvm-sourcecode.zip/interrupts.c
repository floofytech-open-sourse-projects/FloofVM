#include "interrupts.h"
#include <string.h>

void interrupts_init(Interrupts *intr)
{
    memset(intr->pending,      0, sizeof(intr->pending));
    memset(intr->vector_table, 0, sizeof(intr->vector_table));
}

void interrupts_raise(Interrupts *intr, uint8_t irq)
{
    intr->pending[irq] = 1;
}

int interrupts_fetch(Interrupts *intr, uint8_t *irq_out)
{
    for (int i = 0; i < 256; i++) {
        if (intr->pending[i]) {
            intr->pending[i] = 0;
            *irq_out = (uint8_t)i;
            return 1;
        }
    }
    return 0;
}
