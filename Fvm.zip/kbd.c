#include "kbd.h"
#include "uart.h"
#include "hdmi.h"
#include "flooflibc.h"

/* =======================================================================
 * HID Usage-Code Translation Tables
 *
 * Source: USB HID Usage Tables 1.4, Section 10 "Keyboard/Keypad Page"
 * Both tables are indexed directly by the HID usage code (0x00–0x73).
 * 0x00 = no key / error rollover — always maps to 0.
 * ===================================================================== */

/* Unshifted (normal) characters */
static const char s_normal[0x74] = {
    /*00*/ 0,    0,    0,    0,
    /*04*/ 'a',  'b',  'c',  'd',  'e',  'f',  'g',  'h',
    /*0C*/ 'i',  'j',  'k',  'l',  'm',  'n',  'o',  'p',
    /*14*/ 'q',  'r',  's',  't',  'u',  'v',  'w',  'x',
    /*1C*/ 'y',  'z',
    /*1E*/ '1',  '2',  '3',  '4',  '5',  '6',  '7',  '8',  '9',  '0',
    /*28*/ '\n', '\x1B', '\b', '\t', ' ',
    /*2D*/ '-',  '=',  '[',  ']',  '\\', '#',  ';',  '\'', '`',  ',',
    /*37*/ '.',  '/',
    /* Caps Lock usage 0x39 — handled separately */
    /*39*/ 0,
    /* F1–F12: 0x3A–0x45 */
    /*3A*/ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    /* Print Screen, Scroll Lock, Pause */
    /*46*/ 0, 0, 0,
    /* Insert, Home, PgUp, Delete, End, PgDn */
    /*49*/ 0, 0, 0, 0, 0, 0,
    /* Right arrow, Left arrow, Down arrow, Up arrow */
    /*4F*/ 0, 0, 0, 0,
    /* Num Lock */
    /*53*/ 0,
    /* Numpad / * - + Enter */
    /*54*/ '/', '*', '-', '+', '\n',
    /* Numpad 1–9, 0, . */
    /*59*/ '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.',
    /* Application / Power / = */
    /*64*/ 0, 0, 0,
    /* Numpad = , @ ! */
    /*67*/ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

/* Shifted characters */
static const char s_shifted[0x74] = {
    /*00*/ 0,    0,    0,    0,
    /*04*/ 'A',  'B',  'C',  'D',  'E',  'F',  'G',  'H',
    /*0C*/ 'I',  'J',  'K',  'L',  'M',  'N',  'O',  'P',
    /*14*/ 'Q',  'R',  'S',  'T',  'U',  'V',  'W',  'X',
    /*1C*/ 'Y',  'Z',
    /*1E*/ '!',  '@',  '#',  '$',  '%',  '^',  '&',  '*',  '(',  ')',
    /*28*/ '\n', '\x1B', '\b', '\t', ' ',
    /*2D*/ '_',  '+',  '{',  '}',  '|',  '~',  ':',  '"',  '~',  '<',
    /*37*/ '>',  '?',
    /*39*/ 0,
    /*3A*/ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    /*46*/ 0, 0, 0,
    /*49*/ 0, 0, 0, 0, 0, 0,
    /*4F*/ 0, 0, 0, 0,
    /*53*/ 0,
    /*54*/ '/', '*', '-', '+', '\n',
    /*59*/ '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.',
    /*64*/ 0, 0, 0,
    /*67*/ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

/*
 * Numpad usage codes 0x59–0x63 when Num Lock is OFF produce navigation
 * keys instead of digits.  Map them to special codes.
 */
static const uint8_t s_numpad_nav[0x0B] = {
    /* 0x59 = KP1 */ KBD_KEY_END,
    /* 0x5A = KP2 */ KBD_KEY_DOWN,
    /* 0x5B = KP3 */ KBD_KEY_PGDN,
    /* 0x5C = KP4 */ KBD_KEY_LEFT,
    /* 0x5D = KP5 */ 0,
    /* 0x5E = KP6 */ KBD_KEY_RIGHT,
    /* 0x5F = KP7 */ KBD_KEY_HOME,
    /* 0x60 = KP8 */ KBD_KEY_UP,
    /* 0x61 = KP9 */ KBD_KEY_PGUP,
    /* 0x62 = KP0 */ KBD_KEY_INS,
    /* 0x63 = KP. */ KBD_KEY_DEL,
};

/* =======================================================================
 * kbd_translate — core translation function
 * ===================================================================== */
KBDEvent kbd_translate(uint8_t usage, uint8_t mods,
                        int caps, int numlock, int repeat)
{
    KBDEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.usage     = usage;
    ev.modifiers = mods;
    ev.repeat    = repeat;

    if (usage == 0) return ev;

    int shifted = (mods & KBD_MOD_SHIFT) != 0;

    /* ---- Lock-toggle keys ------------------------------------------ */
    /* These are handled by the caller (kbd_poll); just return empty here */
    if (usage == 0x39 || usage == 0x53 || usage == 0x47) return ev;

    /* ---- Function keys F1–F12 (0x3A–0x45) -------------------------- */
    if (usage >= 0x3A && usage <= 0x45) {
        ev.special = (uint8_t)(KBD_KEY_F1 + (usage - 0x3A));
        return ev;
    }

    /* ---- Navigation cluster (0x49–0x52) ---------------------------- */
    switch (usage) {
    case 0x49: ev.special = KBD_KEY_INS;   return ev;
    case 0x4A: ev.special = KBD_KEY_HOME;  return ev;
    case 0x4B: ev.special = KBD_KEY_PGUP;  return ev;
    case 0x4C: ev.special = KBD_KEY_DEL;   return ev;
    case 0x4D: ev.special = KBD_KEY_END;   return ev;
    case 0x4E: ev.special = KBD_KEY_PGDN;  return ev;
    case 0x4F: ev.special = KBD_KEY_RIGHT; return ev;
    case 0x50: ev.special = KBD_KEY_LEFT;  return ev;
    case 0x51: ev.special = KBD_KEY_DOWN;  return ev;
    case 0x52: ev.special = KBD_KEY_UP;    return ev;
    case 0x46: ev.special = KBD_KEY_PRTSC; return ev;
    case 0x48: ev.special = KBD_KEY_PAUSE; return ev;
    case 0x65: ev.special = KBD_KEY_MENU;  return ev;
    default: break;
    }

    /* ---- Numpad when Num Lock is OFF (0x59–0x63) ------------------- */
    if (usage >= 0x59 && usage <= 0x63 && !numlock) {
        uint8_t sp = s_numpad_nav[usage - 0x59];
        if (sp) ev.special = sp;
        return ev;
    }

    /* ---- Letter keys with Caps Lock -------------------------------- */
    if (usage >= 0x04 && usage <= 0x1D) {
        /* Caps Lock flips the case of letters; Shift on top of that
           flips it back (XOR behaviour, matching real keyboards).    */
        int upper = caps ^ shifted;
        ev.ascii = upper ? s_shifted[usage] : s_normal[usage];
        return ev;
    }

    /* ---- Control characters (Ctrl + letter = 0x01–0x1A) ----------- */
    if ((mods & KBD_MOD_CTRL) && usage >= 0x04 && usage <= 0x1D) {
        ev.ascii = (char)(usage - 0x04 + 1); /* Ctrl-A=1, Ctrl-B=2, … */
        return ev;
    }

    /* ---- All other keys from the table ----------------------------- */
    if (usage < 0x74) {
        ev.ascii = shifted ? s_shifted[usage] : s_normal[usage];
    }

    return ev;
}

/* =======================================================================
 * Internal: push one event onto the queue
 * ===================================================================== */
static void enqueue(KBDState *kb, KBDEvent ev)
{
    if (ev.ascii == 0 && ev.special == 0) return; /* no-op key */
    int next = (kb->q_tail + 1) % 6;
    if (next == kb->q_head) return; /* queue full — drop oldest */
    kb->queue[kb->q_tail] = ev;
    kb->q_tail = next;
}

/* =======================================================================
 * Internal: update LEDs on the USB device
 * ===================================================================== */
static void sync_leds(KBDState *kb)
{
    if (!kb->dev) return;
    uint8_t leds = 0;
    if (kb->num_lock)    leds |= KBD_LED_NUMLOCK;
    if (kb->caps_lock)   leds |= KBD_LED_CAPSLOCK;
    if (kb->scroll_lock) leds |= KBD_LED_SCROLLLOCK;
    usb_kbd_set_leds(kb->dev, leds);
}

/* =======================================================================
 * kbd_init
 * ===================================================================== */
void kbd_init(KBDState *kb, USBDev *dev)
{
    memset(kb, 0, sizeof(*kb));
    kb->num_lock = 1; /* Num Lock on by default, matching PC BIOS */
    kb->dev = dev;
    if (dev) sync_leds(kb);
}

/* =======================================================================
 * kbd_attach
 * ===================================================================== */
void kbd_attach(KBDState *kb, USBDev *dev)
{
    kb->dev = dev;
    kb->prev_mods = 0;
    memset(kb->prev_keys, 0, sizeof(kb->prev_keys));
    kb->repeat_key = 0;
    kb->repeat_counter = 0;
    kb->q_head = kb->q_tail = 0;
    if (dev) sync_leds(kb);
}

/* =======================================================================
 * kbd_poll — fetch one HID report and decode into event queue
 * ===================================================================== */
int kbd_poll(KBDState *kb, KBDEvent *ev_out)
{
    /* ---- Drain the event queue first -------------------------------- */
    if (kb->q_head != kb->q_tail) {
        *ev_out = kb->queue[kb->q_head];
        kb->q_head = (kb->q_head + 1) % 6;
        return 1;
    }

    if (!kb->dev) return 0;

    /* ---- Fetch a new HID report from the USB device ----------------- */
    USBKeyReport rep;
    if (!usb_kbd_poll(kb->dev, &rep)) {
        /* No new report — handle key-repeat for the held key */
        if (kb->repeat_key != 0) {
            kb->repeat_counter++;
            if (kb->repeat_counter == KBD_REPEAT_DELAY ||
                (kb->repeat_counter > KBD_REPEAT_DELAY &&
                 (kb->repeat_counter - KBD_REPEAT_DELAY) % KBD_REPEAT_RATE == 0)) {
                KBDEvent re = kbd_translate(kb->repeat_key, kb->repeat_mods,
                                            kb->caps_lock, kb->num_lock, 1);
                enqueue(kb, re);
            }
        }
        /* Try to return a repeat event */
        if (kb->q_head != kb->q_tail) {
            *ev_out = kb->queue[kb->q_head];
            kb->q_head = (kb->q_head + 1) % 6;
            return 1;
        }
        return 0;
    }

    /* ---- Detect newly pressed keys ---------------------------------- */
    for (int i = 0; i < 6; i++) {
        uint8_t usage = rep.keycode[i];
        if (usage == 0) continue;

        /* Is this key new (not in previous report)? */
        int already = 0;
        for (int j = 0; j < 6; j++) {
            if (kb->prev_keys[j] == usage) { already = 1; break; }
        }
        if (already) continue;

        /* ---- Handle lock-toggle keys -------------------------------- */
        if (usage == 0x39) { /* Caps Lock */
            kb->caps_lock ^= 1;
            sync_leds(kb);
            continue;
        }
        if (usage == 0x53) { /* Num Lock */
            kb->num_lock ^= 1;
            sync_leds(kb);
            continue;
        }
        if (usage == 0x47) { /* Scroll Lock */
            kb->scroll_lock ^= 1;
            sync_leds(kb);
            continue;
        }

        /* ---- Normal key press --------------------------------------- */
        KBDEvent ev = kbd_translate(usage, rep.modifiers,
                                     kb->caps_lock, kb->num_lock, 0);
        enqueue(kb, ev);

        /* Start repeat tracking for the first new key */
        if (kb->repeat_key == 0) {
            kb->repeat_key     = usage;
            kb->repeat_mods    = rep.modifiers;
            kb->repeat_counter = 0;
        }
    }

    /* ---- Detect released keys (cancel repeat if held key released) -- */
    for (int i = 0; i < 6; i++) {
        uint8_t prev = kb->prev_keys[i];
        if (prev == 0) continue;
        int still = 0;
        for (int j = 0; j < 6; j++) {
            if (rep.keycode[j] == prev) { still = 1; break; }
        }
        if (!still && prev == kb->repeat_key) {
            kb->repeat_key = 0;
            kb->repeat_counter = 0;
        }
    }

    /* ---- Save current report ---------------------------------------- */
    kb->prev_mods = rep.modifiers;
    memcpy(kb->prev_keys, rep.keycode, 6);

    /* ---- Return first queued event ---------------------------------- */
    if (kb->q_head != kb->q_tail) {
        *ev_out = kb->queue[kb->q_head];
        kb->q_head = (kb->q_head + 1) % 6;
        return 1;
    }
    return 0;
}

/* =======================================================================
 * kbd_getchar — blocking: spin until a printable/control char arrives
 * ===================================================================== */
char kbd_getchar(KBDState *kb)
{
    KBDEvent ev;
    for (;;) {
        if (kbd_poll(kb, &ev) && ev.ascii != 0)
            return ev.ascii;
    }
}

/* =======================================================================
 * kbd_gets — read a line with echo (blocking)
 * ===================================================================== */
int kbd_gets(KBDState *kb, char *buf, int maxlen, struct HDMI *hdmi)
{
    int len = 0;
    if (maxlen <= 0) return 0;

    for (;;) {
        char c = kbd_getchar(kb);

        if (c == '\n' || c == '\r') {
            /* Echo newline */
            uart_putc('\r'); uart_putc('\n');
            if (hdmi) hdmi_puts(hdmi, "\n", 0xFFFFFFFF, 0xFF000000);
            break;
        }

        if (c == '\b' || c == 0x7F) { /* Backspace / Delete */
            if (len > 0) {
                len--;
                uart_puts("\b \b"); /* erase char on terminal */
                if (hdmi) {
                    /* Move cursor back one column and overwrite with space */
                    if (hdmi->cursor_x > 0) hdmi->cursor_x--;
                    hdmi_char(hdmi,
                              hdmi->cursor_x * 8,
                              hdmi->cursor_y * 16,
                              ' ', 0xFFFFFFFF, 0xFF000000);
                }
            }
            continue;
        }

        /* Printable character */
        if (c >= 0x20 && c < 0x7F && len < maxlen - 1) {
            buf[len++] = c;
            uart_putc(c);
            if (hdmi) {
                char ch[2] = { c, '\0' };
                hdmi_puts(hdmi, ch, 0xFFFFFFFF, 0xFF000000);
            }
        }
    }

    buf[len] = '\0';
    return len;
}