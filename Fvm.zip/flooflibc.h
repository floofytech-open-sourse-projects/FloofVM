#ifndef FLOOFLIBC_H
#define FLOOFLIBC_H

/*
 * flooflibc.h — Complete freestanding libc replacement for FloofVM
 *
 * Provides every symbol the project needs without depending on any
 * hosted header beyond the two that are mandated freestanding by C11:
 *   <stdint.h>  — fixed-width integer types
 *   <stddef.h>  — size_t, ptrdiff_t, NULL, offsetof
 *
 * Both of those are provided by the compiler itself (they live inside
 * the toolchain, not in a C library), so they are always safe to use
 * with -ffreestanding -nostdlib.
 *
 * Everything else — memset, memcpy, memcmp, va_list, va_arg, etc. —
 * is implemented here as static inline functions or macros so the
 * compiler can inline them directly at every call site with zero
 * link-time dependencies.
 *
 * Usage: replace every #include <string.h>, <stdlib.h>, <stdarg.h>
 *        with #include "flooflibc.h"
 */

#include <stdint.h>   /* uint8_t, uint32_t, uint64_t, int8_t … — freestanding */
#include <stddef.h>   /* size_t, ptrdiff_t, NULL, offsetof      — freestanding */

/* -----------------------------------------------------------------------
 * Sanity: make absolutely sure we are not pulling in hosted headers.
 * If <string.h> or <stdlib.h> were already included, poison their
 * guards so any accidental re-include is a hard error at build time.
 * --------------------------------------------------------------------- */
#ifdef _STRING_H
#  error "flooflibc.h: <string.h> was included before flooflibc.h — remove it"
#endif
#ifdef _STDLIB_H
#  error "flooflibc.h: <stdlib.h> was included before flooflibc.h — remove it"
#endif

/* -----------------------------------------------------------------------
 * Variadic argument support
 *
 * C11 §7.4 lists <stdarg.h> as a freestanding header, meaning it must
 * be provided by the compiler.  We replicate it here anyway so the
 * project has zero external header dependencies.
 *
 * GCC and Clang both define __builtin_va_list and the associated
 * builtins on every target they support (including arm-none-eabi and
 * aarch64-none-elf), so this is fully portable across ARMv7 and ARM64.
 * --------------------------------------------------------------------- */
#ifndef _FLOOFLIBC_VA_DEFINED
#define _FLOOFLIBC_VA_DEFINED

typedef __builtin_va_list fl_va_list;

#define fl_va_start(ap, last)  __builtin_va_start(ap, last)
#define fl_va_end(ap)          __builtin_va_end(ap)
#define fl_va_arg(ap, type)    __builtin_va_arg(ap, type)
#define fl_va_copy(dst, src)   __builtin_va_copy(dst, src)

/* Provide the standard names as aliases so existing code compiles
   without changes.  These will not conflict with <stdarg.h> because
   we never include that header. */
typedef fl_va_list va_list;
#define va_start   fl_va_start
#define va_end     fl_va_end
#define va_arg     fl_va_arg
#define va_copy    fl_va_copy

#endif /* _FLOOFLIBC_VA_DEFINED */

/* -----------------------------------------------------------------------
 * Boolean (C99/C11 freestanding — <stdbool.h> is a freestanding header
 * but we define it here to keep the dependency count at exactly 2).
 * --------------------------------------------------------------------- */
#ifndef __cplusplus
#  ifndef bool
#    define bool  _Bool
#    define true  1
#    define false 0
#  endif
#endif

/* -----------------------------------------------------------------------
 * Memory functions
 *
 * Implemented as static inline to give the compiler full visibility for
 * optimisation (loop unrolling, SIMD, etc.) without a separate object.
 *
 * GCC with -ffreestanding is allowed to replace these with __builtin_*
 * variants, but only if we do NOT use -fno-builtin.  Since we build
 * with -fno-builtin (to prevent the compiler from emitting calls to
 * libc), we provide the implementations explicitly.  The compiler will
 * still optimise the resulting loops aggressively.
 * --------------------------------------------------------------------- */

/* fl_memset — fill a region with a single byte value */
static inline void *fl_memset(void *dst, int c, size_t n)
{
    uint8_t *d = (uint8_t *)dst;
    uint8_t  v = (uint8_t)c;
    /* Word-at-a-time fill for speed */
    size_t i = 0;
    for (; i + 7 < n; i += 8) {
        d[i+0]=v; d[i+1]=v; d[i+2]=v; d[i+3]=v;
        d[i+4]=v; d[i+5]=v; d[i+6]=v; d[i+7]=v;
    }
    for (; i < n; i++) d[i] = v;
    return dst;
}

/* fl_memcpy — copy n bytes from src to dst (non-overlapping) */
static inline void *fl_memcpy(void *restrict dst,
                               const void *restrict src, size_t n)
{
    const uint8_t *s = (const uint8_t *)src;
    uint8_t       *d = (uint8_t *)dst;
    size_t i = 0;
    for (; i + 7 < n; i += 8) {
        d[i+0]=s[i+0]; d[i+1]=s[i+1]; d[i+2]=s[i+2]; d[i+3]=s[i+3];
        d[i+4]=s[i+4]; d[i+5]=s[i+5]; d[i+6]=s[i+6]; d[i+7]=s[i+7];
    }
    for (; i < n; i++) d[i] = s[i];
    return dst;
}

/* fl_memmove — copy n bytes allowing overlap */
static inline void *fl_memmove(void *dst, const void *src, size_t n)
{
    uint8_t       *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    if (d == s || n == 0) return dst;
    if (d < s || d >= s + n) {
        for (size_t i = 0; i < n; i++) d[i] = s[i];
    } else {
        for (size_t i = n; i > 0; i--) d[i-1] = s[i-1];
    }
    return dst;
}

/* fl_memcmp — compare n bytes; return <0, 0, or >0 */
static inline int fl_memcmp(const void *a, const void *b, size_t n)
{
    const uint8_t *p = (const uint8_t *)a;
    const uint8_t *q = (const uint8_t *)b;
    for (size_t i = 0; i < n; i++) {
        if (p[i] != q[i]) return (int)p[i] - (int)q[i];
    }
    return 0;
}

/* -----------------------------------------------------------------------
 * String functions
 * --------------------------------------------------------------------- */

/* fl_strlen — length of a NUL-terminated string */
static inline size_t fl_strlen(const char *s)
{
    size_t n = 0;
    while (s[n]) n++;
    return n;
}

/* fl_strcmp — lexicographic string comparison */
static inline int fl_strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}

/* fl_strncmp — compare at most n characters */
static inline int fl_strncmp(const char *a, const char *b, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        if (a[i] != b[i]) return (int)(unsigned char)a[i] - (int)(unsigned char)b[i];
        if (!a[i]) break;
    }
    return 0;
}

/* fl_strcpy — copy string including NUL terminator */
static inline char *fl_strcpy(char *dst, const char *src)
{
    char *d = dst;
    while ((*d++ = *src++));
    return dst;
}

/* fl_strncpy — copy at most n chars, pad with NUL */
static inline char *fl_strncpy(char *dst, const char *src, size_t n)
{
    size_t i = 0;
    for (; i < n && src[i]; i++) dst[i] = src[i];
    for (; i < n; i++) dst[i] = '\0';
    return dst;
}

/* fl_strchr — find first occurrence of c in s */
static inline char *fl_strchr(const char *s, int c)
{
    for (; *s; s++) if ((unsigned char)*s == (unsigned char)c) return (char *)s;
    if (c == '\0') return (char *)s;
    return (char *)0;
}

/* -----------------------------------------------------------------------
 * Provide standard names — these replace <string.h> entirely.
 * Code that uses memset(), memcpy() etc. will resolve to the inlines
 * above.  No object-file symbol is emitted; no linker dependency.
 * --------------------------------------------------------------------- */
#define memset   fl_memset
#define memcpy   fl_memcpy
#define memmove  fl_memmove
#define memcmp   fl_memcmp
#define strlen   fl_strlen
#define strcmp   fl_strcmp
#define strncmp  fl_strncmp
#define strcpy   fl_strcpy
#define strncpy  fl_strncpy
#define strchr   fl_strchr

/* -----------------------------------------------------------------------
 * Integer conversion helpers (replaces a subset of <stdlib.h>)
 * --------------------------------------------------------------------- */

/* fl_uitoa — convert unsigned 64-bit integer to decimal string.
   buf must be at least 21 bytes.  Returns pointer to start of digits. */
static inline char *fl_uitoa(uint64_t v, char *buf, int base)
{
    static const char digits[] = "0123456789abcdef";
    char tmp[65]; int i = 0;
    if (v == 0) { buf[0]='0'; buf[1]='\0'; return buf; }
    while (v) { tmp[i++] = digits[v % (uint64_t)base]; v /= (uint64_t)base; }
    for (int j = 0; j < i; j++) buf[j] = tmp[i-1-j];
    buf[i] = '\0';
    return buf;
}

/* fl_abs — absolute value of a signed 64-bit integer */
static inline int64_t fl_abs(int64_t v) { return v < 0 ? -v : v; }

/* -----------------------------------------------------------------------
 * Compiler barrier (prevents reordering across MMIO sequences)
 * --------------------------------------------------------------------- */
#define COMPILER_BARRIER() __asm__ volatile("" ::: "memory")

/* -----------------------------------------------------------------------
 * Static assert (C11 _Static_assert with a friendlier macro name)
 * --------------------------------------------------------------------- */
#define FL_STATIC_ASSERT(cond, msg) _Static_assert(cond, msg)

/* Verify our assumptions */
FL_STATIC_ASSERT(sizeof(uint8_t)  == 1, "uint8_t must be 1 byte");
FL_STATIC_ASSERT(sizeof(uint32_t) == 4, "uint32_t must be 4 bytes");
FL_STATIC_ASSERT(sizeof(uint64_t) == 8, "uint64_t must be 8 bytes");
FL_STATIC_ASSERT(sizeof(size_t)   >= 4, "size_t must be at least 4 bytes");

#endif /* FLOOFLIBC_H */
