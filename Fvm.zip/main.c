#include <stdint.h>
#include <stddef.h>

#include "uart.h"
#include "hdmi.h"
#include "usb.h"
#include "kbd.h"
#include "mmu.h"
#include "cpu.h"
#include "devices.h"
#include "interrupts.h"
#include "jit.h"
#include "loader.h"
#include "flooflibc.h"

/* -----------------------------------------------------------------------
 * Linker-exported symbols (defined in linker.ld)
 * --------------------------------------------------------------------- */
extern uint8_t _fb_start[];

/* -----------------------------------------------------------------------
 * Global subsystems
 * --------------------------------------------------------------------- */
static MMU        g_mmu;
static CPU        g_cpu;
static Devices    g_dev;
static Interrupts g_intr;
static JIT        g_jit;
static Loader     g_ldr;
static USBHost    g_usb;
static HDMI       g_hdmi;
static KBDState   g_kbd;

/* -----------------------------------------------------------------------
 * USB image staging buffer — physical 0x80000000, 1 GB (see linker.ld)
 * --------------------------------------------------------------------- */
#define USB_BUF_BASE 0x80000000UL
#define USB_BUF_SIZE (1UL * 1024 * 1024 * 1024)
static uint8_t * const g_usb_buf = (uint8_t *)(uintptr_t)USB_BUF_BASE;

#define GUEST_RAM_SIZE  (512UL * 1024 * 1024)
#define ISO_GUEST_BASE  0x10000000ULL
#define ISO_SECTOR      2048

/* -----------------------------------------------------------------------
 * Dual-output helper — UART + HDMI
 * --------------------------------------------------------------------- */
static void status(const char *msg)
{
    uart_puts(msg);
    if (g_hdmi.ready)
        hdmi_puts(&g_hdmi, msg, 0xFFFFFFFF, 0xFF0A0A2E);
}

/* -----------------------------------------------------------------------
 * floofvm_load_iso — mount ISO image and boot via El Torito
 * --------------------------------------------------------------------- */
void floofvm_load_iso(const uint8_t *iso_data, size_t iso_size)
{
    devices_mount_iso(&g_dev, iso_data, iso_size, ISO_GUEST_BASE);
    loader_boot_iso(&g_ldr);
}

/* -----------------------------------------------------------------------
 * build_demo_iso — minimal El Torito ISO using FloofVM bytecode
 *
 * Used as a self-test fallback when no USB mass-storage device is found.
 * Boot image:  MOV RAX, 0x42 / MOV RBX, 0x01 / ADD RAX, RBX / HLT
 * Expected result: RAX = 0x43
 * --------------------------------------------------------------------- */
#define DEMO_NUM_SECTORS 21
static uint8_t s_demo_iso[DEMO_NUM_SECTORS * ISO_SECTOR];

static const uint8_t *build_demo_iso(size_t *out_size)
{
    memset(s_demo_iso, 0, sizeof(s_demo_iso));

    /* Sector 16: Boot Record Descriptor */
    {
        uint8_t *s = s_demo_iso + 16 * ISO_SECTOR;
        s[0] = 0x00;
        memcpy(s + 1, "CD001", 5);
        s[6] = 0x01;
        memcpy(s + 7, "EL TORITO SPECIFICATION", 23);
        s[71] = 19;   /* boot catalog at LBA 19 */
    }
    /* Sector 17: Primary Volume Descriptor */
    {
        uint8_t *s = s_demo_iso + 17 * ISO_SECTOR;
        s[0] = 0x01; memcpy(s + 1, "CD001", 5); s[6] = 0x01;
    }
    /* Sector 18: VD Set Terminator */
    {
        uint8_t *s = s_demo_iso + 18 * ISO_SECTOR;
        s[0] = 0xFF; memcpy(s + 1, "CD001", 5); s[6] = 0x01;
    }
    /* Sector 19: Boot catalog */
    {
        uint8_t *s = s_demo_iso + 19 * ISO_SECTOR;
        /* Validation entry */
        s[0] = 0x01; s[1] = 0x00;
        memcpy(s + 4, "FloofVM ", 8);
        s[30] = 0x55; s[31] = 0xAA;
        /* Default/Initial boot entry at offset 32 */
        uint8_t *e = s + 32;
        e[0] = 0x88;              /* bootable          */
        e[1] = 0x00;              /* no emulation      */
        e[2] = 0x00; e[3] = 0x00; /* load segment = 0 → 0x07C0 */
        e[6] = 0x04; e[7] = 0x00; /* 4 × 512 = 1 ISO sector   */
        e[8] = 20;                 /* boot image at LBA 20      */
    }
    /* Sector 20: Boot image (FloofVM bytecode) */
    {
        uint8_t *p = s_demo_iso + 20 * ISO_SECTOR;
        size_t i = 0;
        /* MOV_RI RAX, 0x42 */
        p[i++]=0x01; p[i++]=0x00;
        p[i++]=0x42; p[i++]=0; p[i++]=0; p[i++]=0;
        p[i++]=0;    p[i++]=0; p[i++]=0; p[i++]=0;
        /* MOV_RI RBX, 0x01 */
        p[i++]=0x01; p[i++]=0x01;
        p[i++]=0x01; p[i++]=0; p[i++]=0; p[i++]=0;
        p[i++]=0;    p[i++]=0; p[i++]=0; p[i++]=0;
        /* ADD_RR RAX, RBX */
        p[i++]=0x03; p[i++]=0x00; p[i++]=0x01;
        /* HLT (0xFF = FloofVM HLT, NOT x86 HLT) */
        p[i++]=0xFF;
    }
    *out_size = sizeof(s_demo_iso);
    return s_demo_iso;
}

/* -----------------------------------------------------------------------
 * print_iso_info — display basic ISO identity info to help with diagnosis
 * --------------------------------------------------------------------- */
static void print_iso_info(const uint8_t *iso, size_t iso_size)
{
    if (iso_size < (uint64_t)(17 * ISO_SECTOR + 2048)) return;
    /* PVD is at sector 16 or 17.  Look for it. */
    for (int lba = 16; lba <= 17; lba++) {
        const uint8_t *pvd = iso + (size_t)lba * ISO_SECTOR;
        if (pvd[0] == 0x01 && memcmp(pvd + 1, "CD001", 5) == 0) {
            /* System identifier: bytes 8–39 (padded with spaces) */
            char sys[33]; memcpy(sys, pvd + 8,  32); sys[32] = '\0';
            char vol[33]; memcpy(vol, pvd + 40, 32); vol[32] = '\0';
            uart_printf("[LDR] ISO System ID : '%.32s'\n", sys);
            uart_printf("[LDR] ISO Volume ID : '%.32s'\n", vol);
            return;
        }
    }
}

/* -----------------------------------------------------------------------
 * usb_report_devices — enumerate USB devices to UART + HDMI
 * --------------------------------------------------------------------- */
static void usb_report_devices(void)
{
    static const char *class_names[] = {
        "None","Mass Storage","Keyboard","Mouse",
        "HID","Hub","CDC Serial","Audio","Printer","Unknown"
    };
    uart_printf("[USB] %d device(s) found:\n", g_usb.n_devs);
    for (int i = 0; i < g_usb.n_devs; i++) {
        USBDev *d = &g_usb.devs[i];
        if (!d->active) continue;
        int ci = (int)d->dev_class;
        if (ci < 0 || ci > 8) ci = 9;
        uart_printf("  [%d] %-14s VID=%04x PID=%04x addr=%u\n",
                    i, class_names[ci], d->vid, d->pid, d->dev_addr);
        if (g_hdmi.ready) {
            hdmi_puts(&g_hdmi, "  USB: ",           0xFF00FFFF, 0xFF0A0A2E);
            hdmi_puts(&g_hdmi, class_names[ci],     0xFF00FF00, 0xFF0A0A2E);
            hdmi_puts(&g_hdmi, "\n",                0xFFFFFFFF, 0xFF0A0A2E);
        }
    }
}

/* -----------------------------------------------------------------------
 * warn_keyboard_test — prominent warning before the interactive demo
 *
 * Displayed both on UART and HDMI so users are not confused when the
 * firmware pauses waiting for keyboard input.
 * --------------------------------------------------------------------- */
static void warn_keyboard_test(void)
{
    uart_puts("\n");
    uart_puts("╔══════════════════════════════════════════════╗\n");
    uart_puts("║         KEYBOARD INPUT TEST                  ║\n");
    uart_puts("╠══════════════════════════════════════════════╣\n");
    uart_puts("║  FloofVM is about to enter an interactive    ║\n");
    uart_puts("║  keyboard test.  A USB HID keyboard must     ║\n");
    uart_puts("║  be connected to proceed.                    ║\n");
    uart_puts("║                                              ║\n");
    uart_puts("║  • Type text and press Enter to echo it.     ║\n");
    uart_puts("║  • Press Escape to exit the keyboard test    ║\n");
    uart_puts("║    and continue to the halt state.           ║\n");
    uart_puts("║                                              ║\n");
    uart_puts("║  If no keyboard is connected the test will   ║\n");
    uart_puts("║  be skipped automatically.                   ║\n");
    uart_puts("╚══════════════════════════════════════════════╝\n");
    uart_puts("\n");

    if (g_hdmi.ready) {
        /* Draw a warning box on screen */
        /* Orange background banner */
        hdmi_rect(&g_hdmi,
                  (int)(g_hdmi.width  * 0.05f),
                  (int)(g_hdmi.height * 0.60f),
                  (int)(g_hdmi.width  * 0.90f),
                  (int)(g_hdmi.height * 0.25f),
                  0xFF8B4500);   /* dark orange */

        /* White inner box */
        hdmi_rect(&g_hdmi,
                  (int)(g_hdmi.width  * 0.05f) + 3,
                  (int)(g_hdmi.height * 0.60f) + 3,
                  (int)(g_hdmi.width  * 0.90f) - 6,
                  (int)(g_hdmi.height * 0.25f) - 6,
                  0xFF1A1A1A);   /* near-black */

        /* Warning text */
        g_hdmi.cursor_x = (uint32_t)(g_hdmi.width  * 0.07f) / 8;
        g_hdmi.cursor_y = (uint32_t)(g_hdmi.height * 0.62f) / 16;

        hdmi_puts(&g_hdmi,
                  "[ KEYBOARD TEST ]\n",
                  0xFFFFAA00, 0xFF1A1A1A);

        g_hdmi.cursor_x = (uint32_t)(g_hdmi.width  * 0.07f) / 8;
        hdmi_puts(&g_hdmi,
                  "Type text + Enter to echo. Esc to skip.\n",
                  0xFFFFFFFF, 0xFF1A1A1A);

        g_hdmi.cursor_x = (uint32_t)(g_hdmi.width  * 0.07f) / 8;
        hdmi_puts(&g_hdmi,
                  "Requires USB HID keyboard connected.\n",
                  0xFFCCCCCC, 0xFF1A1A1A);
    }
}

/* -----------------------------------------------------------------------
 * run_keyboard_demo — interactive typing loop
 * --------------------------------------------------------------------- */
static void run_keyboard_demo(void)
{
    if (!g_kbd.dev) {
        uart_puts("[KBD] No keyboard attached -- skipping test\n");
        if (g_hdmi.ready) {
            g_hdmi.cursor_x = (uint32_t)(g_hdmi.width * 0.07f) / 8;
            g_hdmi.cursor_y++;
            hdmi_puts(&g_hdmi, "No keyboard -- test skipped.\n",
                      0xFFFF4444, 0xFF1A1A1A);
        }
        return;
    }

    uart_puts("[KBD] Keyboard ready. Type (Esc = exit test):\n");

    /* Text area below the warning box */
    if (g_hdmi.ready) {
        g_hdmi.cursor_x = 1;
        g_hdmi.cursor_y = (uint32_t)(g_hdmi.height * 0.88f) / 16;
        hdmi_puts(&g_hdmi, "KBD> ", 0xFF00FFFF, 0xFF0A0A2E);
    }

    char line[128];

    for (;;) {
        uart_puts("KBD> ");
        if (g_hdmi.ready) {
            g_hdmi.cursor_x = 1;
            g_hdmi.cursor_y = (uint32_t)(g_hdmi.height * 0.88f) / 16;
            hdmi_puts(&g_hdmi, "KBD> ", 0xFF00FFFF, 0xFF0A0A2E);
        }

        int n = kbd_gets(&g_kbd, line, (int)sizeof(line),
                         g_hdmi.ready ? &g_hdmi : (struct HDMI *)0);

        if (n == 0) continue;

        /* Escape exits */
        if (n == 1 && (uint8_t)line[0] == 0x1B) {
            uart_puts("[KBD] Escape -- exiting keyboard test\n");
            if (g_hdmi.ready)
                hdmi_puts(&g_hdmi, "[KBD] Test complete.\n",
                          0xFF00FF00, 0xFF0A0A2E);
            break;
        }

        uart_puts("[KBD] Echo: ");
        uart_puts(line);
        uart_puts("\n");

        if (g_hdmi.ready) {
            hdmi_puts(&g_hdmi, "[KBD] Echo: ", 0xFF00FF00, 0xFF0A0A2E);
            hdmi_puts(&g_hdmi, line,           0xFFFFFFFF, 0xFF0A0A2E);
            hdmi_puts(&g_hdmi, "\n",           0xFFFFFFFF, 0xFF0A0A2E);
        }
    }
}

/* -----------------------------------------------------------------------
 * floofvm_main — bare-metal C entry point (called from startup.S)
 * --------------------------------------------------------------------- */
void floofvm_main(void)
{
    /* 1. UART — must be first */
    uart_init();
    uart_puts("\n\n");
    uart_puts("========================================\n");
    uart_puts("  FloofVM  --  ARM64 Firmware  v1.0\n");
    uart_puts("  AMD64 ISO Boot + USB Device Stack\n");
    uart_puts("========================================\n\n");

    /* 2. HDMI */
    uart_puts("[MAIN] Initialising HDMI...\n");
    if (hdmi_init(&g_hdmi, (uint32_t)(uintptr_t)_fb_start) == 0) {
        hdmi_splash(&g_hdmi);
        g_hdmi.cursor_x = 1;
        g_hdmi.cursor_y = (g_hdmi.height / 16) - 12;
        uart_puts("[MAIN] HDMI ready\n");
    } else {
        uart_puts("[MAIN] HDMI init failed -- continuing without display\n");
    }

    /* 3. MMU — 512 MB guest RAM */
    status("[MAIN] Initialising guest RAM (512 MB)...\n");
    if (mmu_init(&g_mmu, GUEST_RAM_SIZE) != 0) {
        status("[MAIN] MMU FAILED -- halting\n");
        for (;;) __asm__ volatile("wfe");
    }

    /* 4–7. Core VM subsystems */
    devices_init(&g_dev);
    interrupts_init(&g_intr);
    jit_init(&g_jit, 1);
    cpu_init(&g_cpu, &g_mmu, &g_dev, &g_intr, &g_jit);
    cpu_reset(&g_cpu);
    loader_init(&g_ldr, &g_mmu, &g_cpu, &g_dev);

    /* 8. USB host controller + device enumeration */
    status("[MAIN] Initialising USB host...\n");
    int usb_devs = usb_host_init(&g_usb);

    /* 9. Attach keyboard if present */
    USBDev *kbd_dev = usb_host_find(&g_usb, USB_DEV_KBD);
    kbd_init(&g_kbd, kbd_dev);
    if (kbd_dev)
        status("[MAIN] USB keyboard attached\n");
    else
        status("[MAIN] No USB keyboard found\n");

    /* 10. Report all enumerated USB devices */
    if (usb_devs > 0)
        usb_report_devices();
    else
        status("[MAIN] No USB devices found\n");

    /* 11. Boot source selection:
           Priority 1 — USB mass-storage device containing an ISO image
           Priority 2 — Built-in FloofVM demo ISO (self-test)          */
    USBDev *msc = usb_host_find(&g_usb, USB_DEV_MSC);

    if (msc) {
        /* ---- Real AMD64 ISO boot ----------------------------------- */
        status("[MAIN] USB mass-storage found -- reading ISO image...\n");

        size_t iso_size = usb_msc_read_iso(msc, g_usb_buf, USB_BUF_SIZE);

        if (iso_size < 17 * ISO_SECTOR) {
            uart_printf("[MAIN] USB image too small (%zu bytes) -- "
                        "not a valid ISO 9660\n", iso_size);
            status("[MAIN] Falling back to demo ISO\n");
            goto demo_boot;
        }

        uart_printf("[MAIN] ISO image: %zu bytes (%.1f MB)\n",
                    iso_size,
                    (uint32_t)(iso_size >> 20));

        print_iso_info(g_usb_buf, iso_size);

        if (g_hdmi.ready) {
            hdmi_puts(&g_hdmi, "[MAIN] Booting AMD64 ISO...\n",
                      0xFF00FF00, 0xFF0A0A2E);
        }

        g_dev.iso_from_usb = 1;
        floofvm_load_iso(g_usb_buf, iso_size);

    } else {
demo_boot:
        /* ---- Demo ISO self-test ------------------------------------ */
        status("[MAIN] No USB mass-storage -- running demo ISO\n");
        size_t demo_size;
        const uint8_t *demo = build_demo_iso(&demo_size);
        floofvm_load_iso(demo, demo_size);
    }

    /* 12. Display execution results */
    uart_puts("\n[MAIN] VM execution complete\n");
    uart_printf("[MAIN] Instruction count : %llu\n",
                (unsigned long long)g_cpu.insn_count);
    uart_printf("[MAIN] Final mode        : %s\n",
                g_cpu.mode == CPU_MODE_LONG ? "LONG (64-bit)" :
                g_cpu.mode == CPU_MODE_PROT ? "PROT (32-bit)" : "REAL (16-bit)");
    uart_puts  ("[MAIN] Final RAX         : 0x");
    uart_puthex64(g_cpu.regs[REG_RAX]);
    uart_puts  ("\n[MAIN] Final RIP         : 0x");
    uart_puthex64(g_cpu.rip);
    uart_puts  ("\n");

    if (g_hdmi.ready) {
        g_hdmi.cursor_x = 1;
        g_hdmi.cursor_y = (g_hdmi.height / 16) - 6;
        hdmi_puts(&g_hdmi, "VM done. RAX=0x", 0xFF00FFFF, 0xFF0A0A2E);
        /* Print RAX hex onto screen */
        static const char hx[] = "0123456789abcdef";
        uint64_t rax = g_cpu.regs[REG_RAX];
        char hbuf[17]; int hi = 16; hbuf[hi] = '\0';
        if (!rax) { hbuf[--hi] = '0'; }
        else { while (rax && hi > 0) { hbuf[--hi] = hx[rax & 0xF]; rax >>= 4; } }
        hdmi_puts(&g_hdmi, hbuf + hi, 0xFF00FFFF, 0xFF0A0A2E);
        hdmi_puts(&g_hdmi, "\n",      0xFFFFFFFF, 0xFF0A0A2E);
    }

    /* 13. Keyboard test — with prominent warning first */
    warn_keyboard_test();
    run_keyboard_demo();

    /* 14. Final halt */
    status("\n[MAIN] FloofVM halted. System is idle.\n");

    if (g_hdmi.ready) {
        g_hdmi.cursor_x = 1;
        g_hdmi.cursor_y = g_hdmi.height / 16 - 2;
        hdmi_puts(&g_hdmi, "FloofVM halted.",
                  0xFFFFAA00, 0xFF0A0A2E);
    }

    for (;;) __asm__ volatile("wfe");
}
