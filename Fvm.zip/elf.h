#ifndef ELF_H
#define ELF_H

#include <stdint.h>
#include <stddef.h>

struct MMU;
struct CPU;

int elf_load(struct MMU *mmu, struct CPU *cpu,
             const uint8_t *elf_data, size_t elf_size);

#endif /* ELF_H */