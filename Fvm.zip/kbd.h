#ifndef KBD_H
#define KBD_H

#include <stdint.h>
#include "usb.h"

/*
 * kbd.h — USB HID keyboard translation layer
 *
 * Converts raw HID boot-protocol reports (8-byte, usage-code keycodes)
 * into ASCII characters, with full support for:
 *
 *   - All printable ASCII keys (letters, digits, symbols, space)
 *   - Shift (uppercase letters + shifted symbol keys)
 *   - Caps Lock (toggles letter case independently of Shift)
 *   - Num Lock  (numpad digit keys vs navigation keys)
 *   - Control characters: Enter, Backspace, Tab, Escape
 *   - Function keys F1–F12 (returned as KBD_KEY_Fn constants)
 *   - Arrow keys, Home, End, PgUp, PgDn, Delete, Insert
 *   - LED feedback: Caps Lock / Num Lock / Scroll Lock LEDs
 *   - Key-repeat: configurable delay + rate (in poll ticks)
 *   - Up to 6 simultaneous keys (rollover as per HID boot protocol)
 *
 * Usage
 * ─────
 *   KBDState kbd;
 *   kbd_init(&kbd, usb_host_find(&host, USB_DEV_KBD));
 *
 *   // In your main loop:
 *   KBDEvent ev;
 *   while (kbd_poll(&kbd, &ev)) {
 *       if (ev.ascii) uart_putc(ev.ascii);
 *       else if (ev.special == KBD_KEY_UP) { ... }
 *   }
 */

/* -----------------------------------------------------------------------
 * Special key codes (non-ASCII)
 * Returned in KBDEvent.special when KBDEvent.ascii == 0.
 * --------------------------------------------------------------------- */
#define KBD_KEY_NONE    0x00
#define KBD_KEY_F1      0x01
#define KBD_KEY_F2      0x02
#define KBD_KEY_F3      0x03
#define KBD_KEY_F4      0x04
#define KBD_KEY_F5      0x05
#define KBD_KEY_F6      0x06
#define KBD_KEY_F7      0x07
#define KBD_KEY_F8      0x08
#define KBD_KEY_F9      0x09
#define KBD_KEY_F10     0x0A
#define KBD_KEY_F11     0x0B
#define KBD_KEY_F12     0x0C
#define KBD_KEY_UP      0x10
#define KBD_KEY_DOWN    0x11
#define KBD_KEY_LEFT    0x12
#define KBD_KEY_RIGHT   0x13
#define KBD_KEY_HOME    0x14
#define KBD_KEY_END     0x15
#define KBD_KEY_PGUP    0x16
#define KBD_KEY_PGDN    0x17
#define KBD_KEY_INS     0x18
#define KBD_KEY_DEL     0x7F   /* ASCII DEL — also used as special */
#define KBD_KEY_PRTSC   0x19
#define KBD_KEY_PAUSE   0x1A
#define KBD_KEY_MENU    0x1B

/* -----------------------------------------------------------------------
 * Modifier bitmask (matches HID boot-protocol byte 0)
 * --------------------------------------------------------------------- */
#define KBD_MOD_LCTRL   (1u << 0)
#define KBD_MOD_LSHIFT  (1u << 1)
#define KBD_MOD_LALT    (1u << 2)
#define KBD_MOD_LGUI    (1u << 3)
#define KBD_MOD_RCTRL   (1u << 4)
#define KBD_MOD_RSHIFT  (1u << 5)
#define KBD_MOD_RALT    (1u << 6)
#define KBD_MOD_RGUI    (1u << 7)
#define KBD_MOD_SHIFT   (KBD_MOD_LSHIFT | KBD_MOD_RSHIFT)
#define KBD_MOD_CTRL    (KBD_MOD_LCTRL  | KBD_MOD_RCTRL)
#define KBD_MOD_ALT     (KBD_MOD_LALT   | KBD_MOD_RALT)

/* -----------------------------------------------------------------------
 * LED bitmask — passed to usb_kbd_set_leds()
 * --------------------------------------------------------------------- */
#define KBD_LED_NUMLOCK    (1u << 0)
#define KBD_LED_CAPSLOCK   (1u << 1)
#define KBD_LED_SCROLLLOCK (1u << 2)

/* -----------------------------------------------------------------------
 * Key event — one per distinct key press (not per poll tick)
 * --------------------------------------------------------------------- */
typedef struct {
    char    ascii;      /* Printable ASCII char, or control char (\n \b \t \x1B)
                           0 if the key has no ASCII representation          */
    uint8_t special;    /* One of the KBD_KEY_* constants above; 0 if ascii≠0 */
    uint8_t modifiers;  /* Raw HID modifier byte at time of press             */
    uint8_t usage;      /* Raw HID usage code (for applications that need it) */
    int     repeat;     /* 1 if this is a key-repeat event, 0 for first press */
} KBDEvent;

/* -----------------------------------------------------------------------
 * Keyboard driver state
 * --------------------------------------------------------------------- */
#define KBD_REPEAT_DELAY  30   /* poll ticks before first repeat             */
#define KBD_REPEAT_RATE    4   /* poll ticks between repeat events           */

typedef struct {
    USBDev  *dev;               /* USB keyboard device (may be NULL)         */

    /* Toggle state */
    int      caps_lock;
    int      num_lock;
    int      scroll_lock;

    /* Previous report — used to detect key-down transitions */
    uint8_t  prev_mods;
    uint8_t  prev_keys[6];

    /* Key-repeat state */
    uint8_t  repeat_key;        /* usage code of the key being held          */
    uint8_t  repeat_mods;
    int      repeat_counter;    /* ticks since key was first pressed         */

    /* Event queue — holds up to 6 events decoded from one report */
    KBDEvent queue[6];
    int      q_head;
    int      q_tail;
} KBDState;

/* -----------------------------------------------------------------------
 * Public API
 * --------------------------------------------------------------------- */

/*
 * kbd_init — initialise the keyboard driver.
 * dev may be NULL (driver will return no events until a device attaches).
 */
void kbd_init(KBDState *kb, USBDev *dev);

/*
 * kbd_attach — hot-attach a newly enumerated keyboard device.
 * Resets all state and updates LEDs to match current lock state.
 */
void kbd_attach(KBDState *kb, USBDev *dev);

/*
 * kbd_poll — poll the USB device for new reports and decode them.
 * Fills *ev with the next pending key event.
 * Returns 1 if an event was returned, 0 if the queue is empty.
 * Call repeatedly until it returns 0 to drain all events from one poll.
 */
int kbd_poll(KBDState *kb, KBDEvent *ev);

/*
 * kbd_getchar — blocking-style convenience wrapper.
 * Returns the next ASCII character from the keyboard.
 * Spins (busy-waits) until a printable or control character arrives.
 * Non-ASCII special keys are silently discarded.
 */
char kbd_getchar(KBDState *kb);

/*
 * kbd_gets — read a line of text (blocking).
 * Echoes characters to UART and (if hdmi != NULL) to the HDMI screen.
 * Handles Backspace correctly.  Stops at Enter or when buf is full.
 * Always NUL-terminates.  Returns number of characters read (excl. NUL).
 */
struct HDMI;
int kbd_gets(KBDState *kb, char *buf, int maxlen, struct HDMI *hdmi);

/*
 * kbd_translate — translate a raw HID usage code + modifiers + lock state
 * into a KBDEvent.  Exposed for testing / custom integration.
 */
KBDEvent kbd_translate(uint8_t usage, uint8_t mods,
                        int caps, int numlock, int repeat);

#endif /* KBD_H */