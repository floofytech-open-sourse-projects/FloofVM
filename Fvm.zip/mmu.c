#include "mmu.h"
#include "uart.h"
#include "flooflibc.h"

/*
 * mmu.c — Guest memory (bare-metal)
 *
 * On bare-metal there is no heap allocator.  Guest RAM is mapped to the
 * fixed physical address GUEST_RAM_BASE (default 0x40000000 = 1 GB mark,
 * well above the FloofVM firmware text/data which sits in flash/ROM at
 * 0x00000000 on most ARM platforms).
 *
 * mmu_free() is a no-op — the region is statically owned by the firmware.
 */

int mmu_init(MMU *mmu, size_t size)
{
    mmu->ram  = (uint8_t *)(uintptr_t)GUEST_RAM_BASE;
    mmu->size = size;
    /* Zero guest RAM — memset is safe; provided by compiler builtins or
       the minimal libc that ships with arm-none-eabi-gcc (-lnosys). */
    memset(mmu->ram, 0, size);
    uart_printf("[MMU] Guest RAM: %zu MB at 0x%x\n",
                size / (1024 * 1024), (uint32_t)(uintptr_t)mmu->ram);
    return 0;
}

void mmu_free(MMU *mmu)
{
    /* No-op on bare-metal */
    (void)mmu;
}

static int check_addr(MMU *mmu, uint64_t addr, size_t width)
{
    if (addr + (uint64_t)width > (uint64_t)mmu->size) {
        uart_printf("[MMU] OOB access at 0x%llx\n",
                    (unsigned long long)addr);
        return 0;
    }
    return 1;
}

uint8_t mmu_read8(MMU *mmu, uint64_t addr)
{
    if (!check_addr(mmu, addr, 1)) return 0;
    return mmu->ram[addr];
}

uint64_t mmu_read64(MMU *mmu, uint64_t addr)
{
    if (!check_addr(mmu, addr, 8)) return 0;
    uint64_t v = 0;
    for (int i = 0; i < 8; i++)
        v |= ((uint64_t)mmu->ram[addr + (uint64_t)i]) << (8 * i);
    return v;
}

void mmu_write8(MMU *mmu, uint64_t addr, uint8_t val)
{
    if (!check_addr(mmu, addr, 1)) return;
    mmu->ram[addr] = val;
}

void mmu_write64(MMU *mmu, uint64_t addr, uint64_t val)
{
    if (!check_addr(mmu, addr, 8)) return;
    for (int i = 0; i < 8; i++)
        mmu->ram[addr + (uint64_t)i] = (uint8_t)(val >> (8 * i));
}