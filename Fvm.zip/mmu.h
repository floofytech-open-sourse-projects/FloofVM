#ifndef MMU_H
#define MMU_H

#include <stdint.h>
#include <stddef.h>

/*
 * mmu.h — Guest memory subsystem
 *
 * Bare-metal: guest RAM lives at a fixed physical address defined by
 * GUEST_RAM_BASE.  No dynamic allocation is performed.
 * Override in your build: -DGUEST_RAM_BASE=0x40000000UL
 */

#ifndef GUEST_RAM_BASE
#  define GUEST_RAM_BASE 0x40000000UL
#endif

typedef struct MMU {
    uint8_t *ram;
    size_t   size;
} MMU;

int  mmu_init(MMU *mmu, size_t size);
void mmu_free(MMU *mmu);

uint8_t  mmu_read8 (MMU *mmu, uint64_t addr);
uint64_t mmu_read64(MMU *mmu, uint64_t addr);

void mmu_write8 (MMU *mmu, uint64_t addr, uint8_t  val);
void mmu_write64(MMU *mmu, uint64_t addr, uint64_t val);

#endif /* MMU_H */