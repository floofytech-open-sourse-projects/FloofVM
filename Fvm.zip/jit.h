#ifndef JIT_H
#define JIT_H

struct CPU;

typedef struct JIT {
    int enabled;
} JIT;

void jit_init(JIT *jit, int enabled);
int  jit_execute_block(struct CPU *cpu);

#endif /* JIT_H */