#include "cpu.h"
#include "mmu.h"
#include "devices.h"
#include "interrupts.h"
#include "jit.h"
#include "uart.h"
#include "flooflibc.h"

/* =======================================================================
 * CPU — Real AMD64 x86_64 instruction interpreter
 *
 * Supports:
 *   Real mode (16-bit), Protected mode (32-bit), Long mode (64-bit)
 *
 * Decoded x86_64 opcode coverage:
 *   MOV  r/m, r/imm (8/16/32/64-bit)
 *   ADD, SUB, AND, OR, XOR, CMP, TEST (r/m, r/imm)
 *   INC, DEC (r/m)
 *   PUSH, POP (r/m/imm)
 *   JMP (rel8/rel16/rel32/r/m64)
 *   Jcc  (all 16 conditions, rel8/rel32)
 *   CALL (rel32/r/m64)
 *   RET / RETF
 *   LOOP / LOOPE / LOOPNE
 *   NOP
 *   HLT
 *   CLI / STI
 *   CLD / STD
 *   LGDT / LIDT  (loads GDTR/IDTR — enables pmode entry)
 *   MOV  CRn, r  / MOV r, CRn  (CR0 write enables protected mode)
 *   IN / OUT  (port I/O — returns 0 / discards)
 *   WRMSR / RDMSR  (MSR access — EFER recognised)
 *   CPUID  (returns synthetic "FloofVM" CPU identification)
 *   XCHG  (register swap)
 *   LEA
 *   MOVZX / MOVSX
 *   REP MOVS / REP STOS / REP CMPS  (string ops)
 *   SHL / SHR / SAR / ROL / ROR (r/m, imm8/CL)
 *   MUL / IMUL (two-operand form)
 *   RDTSC  (returns insn_count in EDX:EAX)
 *   INT n  (dispatched through IDT / vector table)
 *   IRET
 *
 * ModRM decoding:
 *   All mod=0/1/2/3 combinations, 16 base registers, SIB byte,
 *   RIP-relative addressing (mod=0, r/m=5 in 64-bit mode).
 *
 * This is a fetch-decode-execute interpreter.  No JIT is used for the
 * real-x86 path — the JIT fast-path only handles FloofVM demo opcodes.
 * ===================================================================== */

/* -----------------------------------------------------------------------
 * Unified address-space memory helpers
 * --------------------------------------------------------------------- */
static uint8_t mem_r8(CPU *cpu, uint64_t addr)
{
    uint64_t base = cpu->dev->iso_base_addr;
    uint64_t sz   = (uint64_t)cpu->dev->iso_size;
    if (sz > 0 && addr >= base && addr < base + sz)
        return devices_read8(cpu->dev, addr);
    return mmu_read8(cpu->mmu, addr);
}

static void mem_w8(CPU *cpu, uint64_t addr, uint8_t v)
{
    uint64_t base = cpu->dev->iso_base_addr;
    uint64_t sz   = (uint64_t)cpu->dev->iso_size;
    if (sz > 0 && addr >= base && addr < base + sz)
        { devices_write8(cpu->dev, addr, v); return; }
    mmu_write8(cpu->mmu, addr, v);
}

static uint16_t mem_r16(CPU *cpu, uint64_t a)
{
    return (uint16_t)mem_r8(cpu,a) | ((uint16_t)mem_r8(cpu,a+1)<<8);
}
static uint32_t mem_r32(CPU *cpu, uint64_t a)
{
    return (uint32_t)mem_r16(cpu,a) | ((uint32_t)mem_r16(cpu,a+2)<<16);
}
static uint64_t mem_r64(CPU *cpu, uint64_t a)
{
    return (uint64_t)mem_r32(cpu,a) | ((uint64_t)mem_r32(cpu,a+4)<<32);
}
static void mem_w16(CPU *cpu, uint64_t a, uint16_t v)
    { mem_w8(cpu,a,(uint8_t)v); mem_w8(cpu,a+1,(uint8_t)(v>>8)); }
static void mem_w32(CPU *cpu, uint64_t a, uint32_t v)
    { mem_w16(cpu,a,(uint16_t)v); mem_w16(cpu,a+2,(uint16_t)(v>>16)); }
static void mem_w64(CPU *cpu, uint64_t a, uint64_t v)
    { mem_w32(cpu,a,(uint32_t)v); mem_w32(cpu,a+4,(uint32_t)(v>>32)); }

/* -----------------------------------------------------------------------
 * Fetch helpers — advance RIP
 * --------------------------------------------------------------------- */
static uint8_t  fetch8 (CPU *c){ uint8_t  v=mem_r8 (c,c->rip); c->rip+=1; return v; }
static uint16_t fetch16(CPU *c){ uint16_t v=mem_r16(c,c->rip); c->rip+=2; return v; }
static uint32_t fetch32(CPU *c){ uint32_t v=mem_r32(c,c->rip); c->rip+=4; return v; }
static uint64_t fetch64(CPU *c){ uint64_t v=mem_r64(c,c->rip); c->rip+=8; return v; }

/* -----------------------------------------------------------------------
 * Stack helpers
 * --------------------------------------------------------------------- */
static void push64(CPU *cpu, uint64_t v)
    { cpu->regs[REG_RSP]-=8; mem_w64(cpu,cpu->regs[REG_RSP],v); }
static uint64_t pop64(CPU *cpu)
    { uint64_t v=mem_r64(cpu,cpu->regs[REG_RSP]); cpu->regs[REG_RSP]+=8; return v; }
static void push32(CPU *cpu, uint32_t v)
    { cpu->regs[REG_RSP]-=4; mem_w32(cpu,cpu->regs[REG_RSP]&0xFFFFFFFF,v); }
static uint32_t pop32(CPU *cpu)
    { uint32_t v=mem_r32(cpu,cpu->regs[REG_RSP]&0xFFFFFFFF);
      cpu->regs[REG_RSP]=(cpu->regs[REG_RSP]+4)&0xFFFFFFFF; return v; }
static void push16(CPU *cpu, uint16_t v)
    { cpu->regs[REG_RSP]=(cpu->regs[REG_RSP]-2)&0xFFFF;
      mem_w16(cpu,cpu->regs[REG_RSP],v); }
static uint16_t pop16(CPU *cpu)
    { uint16_t v=mem_r16(cpu,cpu->regs[REG_RSP]);
      cpu->regs[REG_RSP]=(cpu->regs[REG_RSP]+2)&0xFFFF; return v; }

/* -----------------------------------------------------------------------
 * RFLAGS helpers — set/test condition codes
 * --------------------------------------------------------------------- */
static void set_flags_add(CPU *c, uint64_t a, uint64_t b, uint64_t r, int w)
{
    uint64_t mask = (w==8)?(uint64_t)0xFF:(w==16)?(uint64_t)0xFFFF:
                   (w==32)?(uint64_t)0xFFFFFFFF:(uint64_t)0xFFFFFFFFFFFFFFFFULL;
    r &= mask;
    c->rflags &= ~(RFLAGS_CF|RFLAGS_ZF|RFLAGS_SF|RFLAGS_OF|RFLAGS_PF|RFLAGS_AF);
    if (r==0)                          c->rflags |= RFLAGS_ZF;
    if (r >> (w*8-1))                  c->rflags |= RFLAGS_SF;
    if ((a&mask)+(b&mask) > mask)      c->rflags |= RFLAGS_CF;
    /* OF: signed overflow */
    uint64_t sb = (uint64_t)1<<(w*8-1);
    if (!((a^b)&sb) && ((a^r)&sb))    c->rflags |= RFLAGS_OF;
}
static void set_flags_sub(CPU *c, uint64_t a, uint64_t b, uint64_t r, int w)
{
    uint64_t mask = (w==8)?(uint64_t)0xFF:(w==16)?(uint64_t)0xFFFF:
                   (w==32)?(uint64_t)0xFFFFFFFF:(uint64_t)0xFFFFFFFFFFFFFFFFULL;
    r &= mask; a &= mask; b &= mask;
    c->rflags &= ~(RFLAGS_CF|RFLAGS_ZF|RFLAGS_SF|RFLAGS_OF|RFLAGS_PF|RFLAGS_AF);
    if (r==0)                   c->rflags |= RFLAGS_ZF;
    if (r>>(w*8-1))             c->rflags |= RFLAGS_SF;
    if (a < b)                  c->rflags |= RFLAGS_CF;
    uint64_t sb=(uint64_t)1<<(w*8-1);
    if (((a^b)&sb) && ((a^r)&sb)) c->rflags |= RFLAGS_OF;
}
static void set_flags_logic(CPU *c, uint64_t r, int w)
{
    uint64_t mask=(w==8)?(uint64_t)0xFF:(w==16)?(uint64_t)0xFFFF:
                  (w==32)?(uint64_t)0xFFFFFFFF:(uint64_t)0xFFFFFFFFFFFFFFFFULL;
    r &= mask;
    c->rflags &= ~(RFLAGS_CF|RFLAGS_ZF|RFLAGS_SF|RFLAGS_OF);
    if (r==0)           c->rflags |= RFLAGS_ZF;
    if (r>>(w*8-1))     c->rflags |= RFLAGS_SF;
}

/* Evaluate Jcc condition from RFLAGS */
static int eval_cond(CPU *c, uint8_t cc)
{
    int CF=!!(c->rflags&RFLAGS_CF), ZF=!!(c->rflags&RFLAGS_ZF);
    int SF=!!(c->rflags&RFLAGS_SF), OF=!!(c->rflags&RFLAGS_OF);
    switch(cc&0xF){
    case 0: return  OF;           /* JO  */
    case 1: return !OF;           /* JNO */
    case 2: return  CF;           /* JB/JNAE/JC */
    case 3: return !CF;           /* JAE/JNB/JNC */
    case 4: return  ZF;           /* JE/JZ */
    case 5: return !ZF;           /* JNE/JNZ */
    case 6: return  CF||ZF;       /* JBE/JNA */
    case 7: return !CF&&!ZF;      /* JA/JNBE */
    case 8: return  SF;           /* JS */
    case 9: return !SF;           /* JNS */
    case 10:return  0;            /* JP/JPE — parity not tracked, never taken */
    case 11:return  1;            /* JNP/JPO */
    case 12:return  SF!=OF;       /* JL/JNGE */
    case 13:return  SF==OF;       /* JGE/JNL */
    case 14:return  ZF||(SF!=OF); /* JLE/JNG */
    case 15:return !ZF&&(SF==OF); /* JG/JNLE */
    default: return 0;
    }
}

/* -----------------------------------------------------------------------
 * ModRM decoder
 *
 * Returns the effective address of the r/m operand.
 * Fills *reg_idx with the reg field (+ REX.R extension).
 * For mod=3 (register direct), returns (uint64_t)-1 and the register
 * index is returned in *rm_reg instead.
 * --------------------------------------------------------------------- */
#define MODRM_REG 0xFFFFFFFFFFFFFFFFULL  /* sentinel: register, not memory */

static uint64_t decode_modrm(CPU *cpu, uint8_t modrm, uint32_t pfx,
                               int *reg_out, int *rm_reg_out)
{
    int mod    = (modrm >> 6) & 3;
    int reg    = (modrm >> 3) & 7;
    int rm     = modrm & 7;
    int is64   = (cpu->mode == CPU_MODE_LONG);

    if (pfx & PFX_REXR) reg |= 8;
    *reg_out = reg;

    if (mod == 3) {
        int rmr = rm;
        if (pfx & PFX_REXB) rmr |= 8;
        *rm_reg_out = rmr;
        return MODRM_REG;
    }

    *rm_reg_out = -1;

    /* SIB byte */
    uint64_t base = 0;
    uint64_t idx  = 0;
    int      scale= 0;
    int      has_sib = (rm == 4);

    if (has_sib) {
        uint8_t sib = fetch8(cpu);
        scale = 1 << ((sib >> 6) & 3);
        int si = (sib >> 3) & 7;
        int ba =  sib & 7;
        if (pfx & PFX_REXX) si |= 8;
        if (pfx & PFX_REXB) ba |= 8;
        base = (ba == 5 && mod == 0) ? 0 : cpu->regs[ba];
        idx  = (si == 4) ? 0 : cpu->regs[si] * (uint64_t)scale;
    } else {
        int rmr = rm;
        if (pfx & PFX_REXB) rmr |= 8;
        base = (is64 && mod == 0 && rmr == 5) ? cpu->rip : cpu->regs[rmr];
    }

    int64_t disp = 0;
    if (mod == 0) {
        /* RIP-relative in 64-bit mode when rm==5 and no SIB */
        if (!has_sib && rm == 5 && is64) {
            disp = (int32_t)fetch32(cpu); /* already consumed rip past disp */
        } else if (has_sib) {
            /* SIB with mod=0, base=5 → disp32 replaces base */
            uint8_t sib_prev = (uint8_t)(/* already fetched */ 0);
            (void)sib_prev;
            int ba = /* recalculate from saved values is complex;
                        just check if original base==5 */
                     (rm==4) ? -1 : -1; /* SIB base=5,mod=0 → disp32 already handled */
            (void)ba;
        }
        /* If mod=0 and rm==5 (no sib), it's disp32-only */
        if (!has_sib && rm == 5) disp = (int32_t)fetch32(cpu);
    } else if (mod == 1) {
        disp = (int8_t)fetch8(cpu);
    } else if (mod == 2) {
        disp = (int32_t)fetch32(cpu);
    }

    uint64_t ea = base + idx + (uint64_t)disp;
    if (!is64) ea &= 0xFFFFFFFF;
    return ea;
}

/* -----------------------------------------------------------------------
 * Register read/write helpers with width masking
 * --------------------------------------------------------------------- */
static uint64_t reg_read(CPU *cpu, int idx, int w)
{
    uint64_t v = cpu->regs[idx & 15];
    switch(w){
    case 1: return v & 0xFF;
    case 2: return v & 0xFFFF;
    case 4: return v & 0xFFFFFFFF;
    default: return v;
    }
}
static void reg_write(CPU *cpu, int idx, int w, uint64_t v)
{
    idx &= 15;
    switch(w){
    case 1:  cpu->regs[idx] = (cpu->regs[idx] & ~(uint64_t)0xFF) | (v & 0xFF); break;
    case 2:  cpu->regs[idx] = (cpu->regs[idx] & ~(uint64_t)0xFFFF) | (v & 0xFFFF); break;
    case 4:  cpu->regs[idx] = v & 0xFFFFFFFF; break; /* zero-extends to 64 */
    default: cpu->regs[idx] = v; break;
    }
}

/* Read/write memory or register from ModRM result */
static uint64_t ea_read(CPU *cpu, uint64_t ea, int rm_reg, int w)
{
    if (ea == MODRM_REG) return reg_read(cpu, rm_reg, w);
    switch(w){
    case 1:  return mem_r8 (cpu, ea);
    case 2:  return mem_r16(cpu, ea);
    case 4:  return mem_r32(cpu, ea);
    default: return mem_r64(cpu, ea);
    }
}
static void ea_write(CPU *cpu, uint64_t ea, int rm_reg, int w, uint64_t v)
{
    if (ea == MODRM_REG) { reg_write(cpu, rm_reg, w, v); return; }
    switch(w){
    case 1:  mem_w8 (cpu, ea, (uint8_t)v);  break;
    case 2:  mem_w16(cpu, ea, (uint16_t)v); break;
    case 4:  mem_w32(cpu, ea, (uint32_t)v); break;
    default: mem_w64(cpu, ea, v);           break;
    }
}

/* -----------------------------------------------------------------------
 * cpu_init / cpu_reset / cpu_set_mode
 * --------------------------------------------------------------------- */
void cpu_init(CPU *cpu, struct MMU *mmu, struct Devices *dev,
              struct Interrupts *intr, struct JIT *jit)
{
    memset(cpu, 0, sizeof(*cpu));
    cpu->mmu  = mmu;
    cpu->dev  = dev;
    cpu->intr = intr;
    cpu->jit  = jit;
}

void cpu_reset(CPU *cpu)
{
    memset(cpu->regs, 0, sizeof(cpu->regs));
    cpu->rip    = 0xFFF0;   /* real-mode reset vector */
    cpu->rsp    = 0;
    cpu->rflags = 0x0002;   /* bit 1 always 1 per spec */
    cpu->mode   = CPU_MODE_REAL;
    cpu->halted = 0;
    cpu->fault  = 0;
    cpu->insn_count = 0;
    cpu->cr0    = 0;
    cpu->efer   = 0;
    cpu->gdtr_base = 0; cpu->gdtr_limit = 0xFFFF;
    cpu->idtr_base = 0; cpu->idtr_limit = 0x3FF;
}

void cpu_set_mode(CPU *cpu, int mode)
{
    cpu->mode = mode;
    uart_printf("[CPU] Mode -> %s\n",
                mode==CPU_MODE_REAL?"REAL":
                mode==CPU_MODE_PROT?"PROT":"LONG");
}

/* -----------------------------------------------------------------------
 * cpu_step — fetch, decode, execute one instruction
 * --------------------------------------------------------------------- */
void cpu_step(CPU *cpu)
{
    if (cpu->halted || cpu->fault) return;

    /* Check for pending interrupts */
    if (cpu->rflags & RFLAGS_IF) {
        uint8_t irq = 0;
        if (interrupts_fetch(cpu->intr, &irq)) {
            uint64_t vec = cpu->intr->vector_table[irq];
            if (vec) { push64(cpu, cpu->rflags); push64(cpu, cpu->rip);
                       cpu->rflags &= ~RFLAGS_IF; cpu->rip = vec; }
        }
    }

    /* JIT fast-path (FloofVM demo opcodes only) */
    if (cpu->jit && cpu->jit->enabled && cpu->mode == CPU_MODE_REAL) {
        uint8_t probe = mem_r8(cpu, cpu->rip);
        if (probe == OP_MOV_RI || probe == OP_MOV_RR ||
            probe == OP_ADD_RR || probe == OP_SUB_RR || probe == OP_HLT) {
            if (jit_execute_block(cpu)) { cpu->insn_count++; return; }
        }
    }

    cpu->insn_count++;

    /* ---- Decode prefix bytes ---- */
    uint32_t pfx = 0;
    uint8_t  rex = 0;

    for (;;) {
        uint8_t b = mem_r8(cpu, cpu->rip);
        if (b == X86_PREFIX_OPSIZE) { pfx|=PFX_OPZ; cpu->rip++; }
        else if (b == X86_PREFIX_ADSIZE){ pfx|=PFX_ADZ; cpu->rip++; }
        else if (b == X86_PREFIX_REPZ)  { pfx|=PFX_REP;  cpu->rip++; }
        else if (b == X86_PREFIX_REPNZ) { pfx|=PFX_REPNE;cpu->rip++; }
        else if (b==X86_PREFIX_SEG_ES||b==X86_PREFIX_SEG_CS||
                 b==X86_PREFIX_SEG_SS||b==X86_PREFIX_SEG_DS||
                 b==X86_PREFIX_SEG_FS||b==X86_PREFIX_SEG_GS)
             { cpu->rip++; } /* segment overrides ignored in flat model */
        else if (b == X86_PREFIX_LOCK) { cpu->rip++; }
        else if (cpu->mode==CPU_MODE_LONG && b>=0x40 && b<=0x4F)
             { rex=b; pfx|=PFX_REX;
               if(b&8){pfx|=PFX_REXW;} if(b&4){pfx|=PFX_REXR;}
               if(b&2){pfx|=PFX_REXX;} if(b&1){pfx|=PFX_REXB;}
               cpu->rip++; }
        else if (b == X86_PREFIX_ESC2) { pfx|=PFX_ESC2; cpu->rip++; break; }
        else break;
    }
    (void)rex;

    /* Operand width: default 32-bit (PROT/LONG), 16-bit (REAL).
       REX.W forces 64-bit.  0x66 toggles 16/32. */
    int dw; /* default width */
    if (cpu->mode == CPU_MODE_REAL)
        dw = (pfx & PFX_OPZ) ? 4 : 2;
    else
        dw = (pfx & PFX_OPZ) ? 2 : 4;
    if (pfx & PFX_REXW) dw = 8;

    uint8_t op = fetch8(cpu);

    /* ================================================================
     * 0x0F two-byte opcodes
     * ============================================================== */
    if (pfx & PFX_ESC2) {
        switch (op) {

        /* JCC rel32 (0F 80–0F 8F) */
        case 0x80: case 0x81: case 0x82: case 0x83:
        case 0x84: case 0x85: case 0x86: case 0x87:
        case 0x88: case 0x89: case 0x8A: case 0x8B:
        case 0x8C: case 0x8D: case 0x8E: case 0x8F: {
            int32_t rel = (int32_t)fetch32(cpu);
            if (eval_cond(cpu, op & 0xF))
                cpu->rip = (uint64_t)((int64_t)cpu->rip + rel);
            break;
        }

        /* SETCC r/m8 (0F 90–0F 9F) */
        case 0x90: case 0x91: case 0x92: case 0x93:
        case 0x94: case 0x95: case 0x96: case 0x97:
        case 0x98: case 0x99: case 0x9A: case 0x9B:
        case 0x9C: case 0x9D: case 0x9E: case 0x9F: {
            int reg, rm; uint8_t modrm=fetch8(cpu);
            uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
            ea_write(cpu,ea,rm,1,(uint64_t)eval_cond(cpu,op&0xF));
            break;
        }

        /* MOVZX r, r/m8  (0F B6) */
        case 0xB6: { int reg,rm; uint8_t modrm=fetch8(cpu);
            uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
            uint64_t v=ea_read(cpu,ea,rm,1);
            reg_write(cpu,reg,dw,v); break; }

        /* MOVZX r, r/m16 (0F B7) */
        case 0xB7: { int reg,rm; uint8_t modrm=fetch8(cpu);
            uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
            uint64_t v=ea_read(cpu,ea,rm,2);
            reg_write(cpu,reg,dw,v); break; }

        /* MOVSX r, r/m8  (0F BE) */
        case 0xBE: { int reg,rm; uint8_t modrm=fetch8(cpu);
            uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
            int64_t v=(int8_t)ea_read(cpu,ea,rm,1);
            reg_write(cpu,reg,dw,(uint64_t)v); break; }

        /* MOVSX r, r/m16 (0F BF) */
        case 0xBF: { int reg,rm; uint8_t modrm=fetch8(cpu);
            uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
            int64_t v=(int16_t)ea_read(cpu,ea,rm,2);
            reg_write(cpu,reg,dw,(uint64_t)v); break; }

        /* IMUL r, r/m (0F AF) */
        case 0xAF: { int reg,rm; uint8_t modrm=fetch8(cpu);
            uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
            uint64_t a=reg_read(cpu,reg,dw), b=ea_read(cpu,ea,rm,dw);
            reg_write(cpu,reg,dw,a*b); break; }

        /* CPUID (0F A2) */
        case 0xA2: {
            uint32_t leaf=(uint32_t)cpu->regs[REG_RAX];
            switch(leaf){
            case 0:
                cpu->regs[REG_RAX]=1;
                cpu->regs[REG_RBX]=0x666F6F6C; /* "loof" */
                cpu->regs[REG_RCX]=0x666D5620; /* " VMf" */
                cpu->regs[REG_RDX]=0x6F6F6C46; /* "Floo" */
                break;
            case 1:
                cpu->regs[REG_RAX]=0x000006A0; /* family 6, model A */
                cpu->regs[REG_RBX]=0;
                cpu->regs[REG_RCX]=0;           /* no SSE3 etc. */
                cpu->regs[REG_RDX]=(1u<<0)|(1u<<4)|(1u<<5)|(1u<<15)|(1u<<23);
                /* FPU,TSC,MSR,CMOV,MMX bits set */
                break;
            case 0x80000000:
                cpu->regs[REG_RAX]=0x80000004; break;
            default:
                cpu->regs[REG_RAX]=0; cpu->regs[REG_RBX]=0;
                cpu->regs[REG_RCX]=0; cpu->regs[REG_RDX]=0;
                break;
            }
            break;
        }

        /* RDTSC (0F 31) */
        case 0x31: {
            cpu->regs[REG_RDX]=(cpu->insn_count>>32)&0xFFFFFFFF;
            cpu->regs[REG_RAX]= cpu->insn_count     &0xFFFFFFFF;
            break;
        }

        /* WRMSR (0F 30) */
        case 0x30: {
            uint32_t msr=(uint32_t)cpu->regs[REG_RCX];
            uint64_t val=((cpu->regs[REG_RDX]&0xFFFFFFFF)<<32)
                        |(cpu->regs[REG_RAX]&0xFFFFFFFF);
            if (msr==0xC0000080) { /* EFER */
                cpu->efer=val;
                if ((val>>8)&1) { /* LME set */
                    if (cpu->cr0&1) { cpu->mode=CPU_MODE_LONG;
                        uart_printf("[CPU] Long mode enabled\n"); }
                }
            }
            break;
        }

        /* RDMSR (0F 32) */
        case 0x32: {
            uint32_t msr=(uint32_t)cpu->regs[REG_RCX];
            uint64_t val=0;
            if (msr==0xC0000080) val=cpu->efer;
            cpu->regs[REG_RDX]=(val>>32)&0xFFFFFFFF;
            cpu->regs[REG_RAX]= val     &0xFFFFFFFF;
            break;
        }

        /* LGDT m (0F 01 /2) */
        /* LIDT m (0F 01 /3) */
        case 0x01: {
            uint8_t modrm2=fetch8(cpu);
            int reg2=(modrm2>>3)&7, rm2; int dummy;
            uint64_t ea=decode_modrm(cpu,modrm2,pfx,&dummy,&rm2);
            if (ea != MODRM_REG) {
                uint16_t lim=mem_r16(cpu,ea);
                uint64_t base2=(dw==8)?mem_r64(cpu,ea+2):mem_r32(cpu,ea+2);
                if (reg2==2){ cpu->gdtr_base=base2; cpu->gdtr_limit=lim;
                    uart_printf("[CPU] LGDT base=0x%llx lim=0x%x\n",(unsigned long long)base2,lim); }
                if (reg2==3){ cpu->idtr_base=base2; cpu->idtr_limit=lim; }
            }
            break;
        }

        /* MOVD/MOVQ xmm/mmx — ignore silently */
        case 0x6E: case 0x7E: case 0xD6:
            fetch8(cpu); /* consume ModRM */
            break;

        /* BSF / BSR — simplified */
        case 0xBC: case 0xBD: {
            int reg,rm; uint8_t modrm=fetch8(cpu);
            uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
            uint64_t v=ea_read(cpu,ea,rm,dw);
            if (v==0){ cpu->rflags|=RFLAGS_ZF; break; }
            cpu->rflags&=~RFLAGS_ZF;
            int bit=0;
            if (op==0xBC){ while(!(v&1)){v>>=1;bit++;} }
            else { int n=dw*8-1; while(!(v>>(n-bit)&1))bit++; }
            reg_write(cpu,reg,dw,(uint64_t)bit);
            break;
        }

        default:
            /* Unknown two-byte — log and skip (do not halt) */
            uart_printf("[CPU] Unknown 0F %02x at 0x%llx\n",
                        op,(unsigned long long)(cpu->rip-1));
            break;
        }
        goto insn_done;
    }

    /* ================================================================
     * One-byte opcodes
     * ============================================================== */
    switch (op) {

    /* NOP (0x90 when not XCHG EAX,EAX) */
    case 0x90:
        break;

    /* HLT */
    case 0xF4:
        uart_printf("[CPU] HLT at 0x%llx (mode=%d)\n",
                    (unsigned long long)(cpu->rip-1), cpu->mode);
        cpu->halted = 1;
        break;

    /* CLI / STI */
    case 0xFA: cpu->rflags &= ~RFLAGS_IF; break;
    case 0xFB: cpu->rflags |=  RFLAGS_IF; break;

    /* CLD / STD */
    case 0xFC: cpu->rflags &= ~RFLAGS_DF; break;
    case 0xFD: cpu->rflags |=  RFLAGS_DF; break;

    /* CMC */
    case 0xF5: cpu->rflags ^= RFLAGS_CF; break;

    /* CLC / STC */
    case 0xF8: cpu->rflags &= ~RFLAGS_CF; break;
    case 0xF9: cpu->rflags |=  RFLAGS_CF; break;

    /* PUSHF / POPF */
    case 0x9C:
        if(dw==8) push64(cpu,cpu->rflags);
        else if(dw==4) push32(cpu,(uint32_t)cpu->rflags);
        else push16(cpu,(uint16_t)cpu->rflags);
        break;
    case 0x9D:
        if(dw==8) cpu->rflags=pop64(cpu);
        else if(dw==4) cpu->rflags=(cpu->rflags&~0xFFFFFFFFULL)|pop32(cpu);
        else cpu->rflags=(cpu->rflags&~0xFFFFULL)|pop16(cpu);
        break;

    /* SAHF / LAHF */
    case 0x9E: /* SAHF */
        cpu->rflags=(cpu->rflags&~0xD5ULL)|((cpu->regs[REG_RAX]>>8)&0xD5);
        break;
    case 0x9F: /* LAHF */
        cpu->regs[REG_RAX]=(cpu->regs[REG_RAX]&~0xFF00ULL)|
                           ((cpu->rflags&0xD5)|0x02)<<8;
        break;

    /* PUSH r16/32/64 (0x50–0x57) */
    case 0x50: case 0x51: case 0x52: case 0x53:
    case 0x54: case 0x55: case 0x56: case 0x57: {
        int r=(op-0x50)|((pfx&PFX_REXB)?8:0);
        if(dw==8) push64(cpu,cpu->regs[r]);
        else if(dw==4) push32(cpu,(uint32_t)cpu->regs[r]);
        else push16(cpu,(uint16_t)cpu->regs[r]);
        break;
    }
    /* POP r16/32/64 (0x58–0x5F) */
    case 0x58: case 0x59: case 0x5A: case 0x5B:
    case 0x5C: case 0x5D: case 0x5E: case 0x5F: {
        int r=(op-0x58)|((pfx&PFX_REXB)?8:0);
        if(dw==8) reg_write(cpu,r,8,pop64(cpu));
        else if(dw==4) reg_write(cpu,r,4,pop32(cpu));
        else reg_write(cpu,r,2,pop16(cpu));
        break;
    }

    /* PUSH imm8 */
    case 0x6A: {
        int64_t imm=(int8_t)fetch8(cpu);
        if(dw==8) push64(cpu,(uint64_t)imm);
        else if(dw==4) push32(cpu,(uint32_t)(int32_t)imm);
        else push16(cpu,(uint16_t)(int16_t)imm);
        break;
    }
    /* PUSH imm16/32 */
    case 0x68: {
        uint64_t imm=(dw==2)?fetch16(cpu):(dw==8||dw==4)?(uint32_t)fetch32(cpu):fetch16(cpu);
        if(dw==8) push64(cpu,imm); else if(dw==4) push32(cpu,(uint32_t)imm);
        else push16(cpu,(uint16_t)imm);
        break;
    }

    /* MOV r8, imm8 (0xB0–0xB7) */
    case 0xB0: case 0xB1: case 0xB2: case 0xB3:
    case 0xB4: case 0xB5: case 0xB6: case 0xB7: {
        int r=(op-0xB0)|((pfx&PFX_REXB)?8:0);
        reg_write(cpu,r,1,fetch8(cpu)); break;
    }
    /* MOV r16/32/64, imm (0xB8–0xBF) */
    case 0xB8: case 0xB9: case 0xBA: case 0xBB:
    case 0xBC: case 0xBD: case 0xBE: case 0xBF: {
        int r=(op-0xB8)|((pfx&PFX_REXB)?8:0);
        uint64_t imm;
        if(dw==8) imm=fetch64(cpu);
        else if(dw==4) imm=fetch32(cpu);
        else imm=fetch16(cpu);
        reg_write(cpu,r,dw,imm); break;
    }

    /* MOV r/m8, imm8  (0xC6) */
    case 0xC6: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        ea_write(cpu,ea,rm,1,fetch8(cpu)); break; }

    /* MOV r/m16/32/64, imm (0xC7) */
    case 0xC7: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t imm=(dw==2)?fetch16(cpu):(uint64_t)(int32_t)fetch32(cpu);
        ea_write(cpu,ea,rm,dw,imm); break; }

    /* MOV r8, r/m8 (0x8A) */
    case 0x8A: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        reg_write(cpu,reg,1,ea_read(cpu,ea,rm,1)); break; }

    /* MOV r/m8, r8 (0x88) */
    case 0x88: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        ea_write(cpu,ea,rm,1,reg_read(cpu,reg,1)); break; }

    /* MOV r, r/m (0x8B) */
    case 0x8B: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        reg_write(cpu,reg,dw,ea_read(cpu,ea,rm,dw)); break; }

    /* MOV r/m, r (0x89) */
    case 0x89: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        ea_write(cpu,ea,rm,dw,reg_read(cpu,reg,dw)); break; }

    /* MOV r/m, Sreg (0x8C) — treat as 16-bit zero */
    case 0x8C: fetch8(cpu); break;
    /* MOV Sreg, r/m (0x8E) — ignore */
    case 0x8E: fetch8(cpu); break;

    /* MOV CR0/2/3/4, r (0x0F 20/22 handled via ESC2 path above, but
       some encodings come without ESC2 prefix in real-mode code) */

    /* LEA r, m (0x8D) */
    case 0x8D: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        if(ea!=MODRM_REG) reg_write(cpu,reg,dw,ea);
        break; }

    /* XCHG r, r/m (0x86=8-bit, 0x87=full) */
    case 0x86: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,1), b=ea_read(cpu,ea,rm,1);
        reg_write(cpu,reg,1,b); ea_write(cpu,ea,rm,1,a); break; }
    case 0x87: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,dw), b=ea_read(cpu,ea,rm,dw);
        reg_write(cpu,reg,dw,b); ea_write(cpu,ea,rm,dw,a); break; }

    /* XCHG rAX, r (0x91–0x97) */
    case 0x91: case 0x92: case 0x93: case 0x94:
    case 0x95: case 0x96: case 0x97: {
        int r=(op-0x90)|((pfx&PFX_REXB)?8:0);
        uint64_t tmp=reg_read(cpu,REG_RAX,dw);
        reg_write(cpu,REG_RAX,dw,reg_read(cpu,r,dw));
        reg_write(cpu,r,dw,tmp); break;
    }

    /* ADD/OR/ADC/SBB/AND/SUB/XOR/CMP r/m, imm8  (0x83) */
    case 0x83: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        int64_t imm=(int8_t)fetch8(cpu);
        uint64_t a=ea_read(cpu,ea,rm,dw), b=(uint64_t)imm, r;
        switch(reg&7){
        case 0: r=a+b; set_flags_add(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 1: r=a|b; set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 2: r=a+b+(cpu->rflags&RFLAGS_CF?1:0); set_flags_add(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 3: r=a-b-(cpu->rflags&RFLAGS_CF?1:0); set_flags_sub(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 4: r=a&b; set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 5: r=a-b; set_flags_sub(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 6: r=a^b; set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 7: r=a-b; set_flags_sub(cpu,a,b,r,dw); break; /* CMP */
        }
        break;
    }

    /* ADD/OR/.../CMP r/m, imm16/32  (0x81) */
    case 0x81: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t imm=(dw==2)?(uint64_t)fetch16(cpu):(uint64_t)(int32_t)fetch32(cpu);
        uint64_t a=ea_read(cpu,ea,rm,dw), b=imm, r;
        switch(reg&7){
        case 0: r=a+b; set_flags_add(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 1: r=a|b; set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 4: r=a&b; set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 5: r=a-b; set_flags_sub(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 6: r=a^b; set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break;
        case 7: r=a-b; set_flags_sub(cpu,a,b,r,dw); break;
        default: r=a; ea_write(cpu,ea,rm,dw,r); break;
        }
        break;
    }

    /* ADD r/m8, r8   (0x00) */
    case 0x00: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=ea_read(cpu,ea,rm,1),b=reg_read(cpu,reg,1),r=a+b;
        set_flags_add(cpu,a,b,r,1); ea_write(cpu,ea,rm,1,r); break; }
    /* ADD r/m, r     (0x01) */
    case 0x01: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=ea_read(cpu,ea,rm,dw),b=reg_read(cpu,reg,dw),r=a+b;
        set_flags_add(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break; }
    /* ADD r8, r/m8   (0x02) */
    case 0x02: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,1),b=ea_read(cpu,ea,rm,1),r=a+b;
        set_flags_add(cpu,a,b,r,1); reg_write(cpu,reg,1,r); break; }
    /* ADD r, r/m     (0x03) */
    case 0x03: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,dw),b=ea_read(cpu,ea,rm,dw),r=a+b;
        set_flags_add(cpu,a,b,r,dw); reg_write(cpu,reg,dw,r); break; }
    /* ADD AL,imm8 (0x04) */
    case 0x04: { uint8_t i=fetch8(cpu);
        uint64_t a=cpu->regs[REG_RAX]&0xFF,b=i,r=a+b;
        set_flags_add(cpu,a,b,r,1); reg_write(cpu,REG_RAX,1,r); break; }
    /* ADD rAX, imm (0x05) */
    case 0x05: { uint64_t i=(dw==2)?fetch16(cpu):(uint64_t)(int32_t)fetch32(cpu);
        uint64_t a=reg_read(cpu,REG_RAX,dw),r=a+i;
        set_flags_add(cpu,a,i,r,dw); reg_write(cpu,REG_RAX,dw,r); break; }

    /* SUB r/m8, r8  (0x28) */
    case 0x28: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=ea_read(cpu,ea,rm,1),b=reg_read(cpu,reg,1),r=a-b;
        set_flags_sub(cpu,a,b,r,1); ea_write(cpu,ea,rm,1,r); break; }
    /* SUB r/m, r    (0x29) */
    case 0x29: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=ea_read(cpu,ea,rm,dw),b=reg_read(cpu,reg,dw),r=a-b;
        set_flags_sub(cpu,a,b,r,dw); ea_write(cpu,ea,rm,dw,r); break; }
    /* SUB r8, r/m8  (0x2A) */
    case 0x2A: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,1),b=ea_read(cpu,ea,rm,1),r=a-b;
        set_flags_sub(cpu,a,b,r,1); reg_write(cpu,reg,1,r); break; }
    /* SUB r, r/m    (0x2B) */
    case 0x2B: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,dw),b=ea_read(cpu,ea,rm,dw),r=a-b;
        set_flags_sub(cpu,a,b,r,dw); reg_write(cpu,reg,dw,r); break; }
    /* SUB AL, imm8 (0x2C) */
    case 0x2C: { uint8_t i=fetch8(cpu);
        uint64_t a=cpu->regs[REG_RAX]&0xFF,r=a-i;
        set_flags_sub(cpu,a,i,r,1); reg_write(cpu,REG_RAX,1,r); break; }
    /* SUB rAX,imm (0x2D) */
    case 0x2D: { uint64_t i=(dw==2)?fetch16(cpu):(uint64_t)(int32_t)fetch32(cpu);
        uint64_t a=reg_read(cpu,REG_RAX,dw),r=a-i;
        set_flags_sub(cpu,a,i,r,dw); reg_write(cpu,REG_RAX,dw,r); break; }

    /* AND r/m, r (0x20–0x23) */
    case 0x20: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=ea_read(cpu,ea,rm,1)&reg_read(cpu,reg,1);
        set_flags_logic(cpu,r,1); ea_write(cpu,ea,rm,1,r); break; }
    case 0x21: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=ea_read(cpu,ea,rm,dw)&reg_read(cpu,reg,dw);
        set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break; }
    case 0x22: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=reg_read(cpu,reg,1)&ea_read(cpu,ea,rm,1);
        set_flags_logic(cpu,r,1); reg_write(cpu,reg,1,r); break; }
    case 0x23: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=reg_read(cpu,reg,dw)&ea_read(cpu,ea,rm,dw);
        set_flags_logic(cpu,r,dw); reg_write(cpu,reg,dw,r); break; }
    case 0x24: { uint64_t r=(cpu->regs[REG_RAX]&0xFF)&fetch8(cpu);
        set_flags_logic(cpu,r,1); reg_write(cpu,REG_RAX,1,r); break; }
    case 0x25: { uint64_t i=(dw==2)?fetch16(cpu):(uint64_t)fetch32(cpu);
        uint64_t r=reg_read(cpu,REG_RAX,dw)&i;
        set_flags_logic(cpu,r,dw); reg_write(cpu,REG_RAX,dw,r); break; }

    /* OR (0x08–0x0D) */
    case 0x08: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=ea_read(cpu,ea,rm,1)|reg_read(cpu,reg,1);
        set_flags_logic(cpu,r,1); ea_write(cpu,ea,rm,1,r); break; }
    case 0x09: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=ea_read(cpu,ea,rm,dw)|reg_read(cpu,reg,dw);
        set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break; }
    case 0x0A: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=reg_read(cpu,reg,1)|ea_read(cpu,ea,rm,1);
        set_flags_logic(cpu,r,1); reg_write(cpu,reg,1,r); break; }
    case 0x0B: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=reg_read(cpu,reg,dw)|ea_read(cpu,ea,rm,dw);
        set_flags_logic(cpu,r,dw); reg_write(cpu,reg,dw,r); break; }
    case 0x0C: { uint64_t r=(cpu->regs[REG_RAX]&0xFF)|fetch8(cpu);
        set_flags_logic(cpu,r,1); reg_write(cpu,REG_RAX,1,r); break; }
    case 0x0D: { uint64_t i=(dw==2)?fetch16(cpu):(uint64_t)fetch32(cpu);
        uint64_t r=reg_read(cpu,REG_RAX,dw)|i;
        set_flags_logic(cpu,r,dw); reg_write(cpu,REG_RAX,dw,r); break; }

    /* XOR (0x30–0x35) */
    case 0x30: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=ea_read(cpu,ea,rm,1)^reg_read(cpu,reg,1);
        set_flags_logic(cpu,r,1); ea_write(cpu,ea,rm,1,r); break; }
    case 0x31: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=ea_read(cpu,ea,rm,dw)^reg_read(cpu,reg,dw);
        set_flags_logic(cpu,r,dw); ea_write(cpu,ea,rm,dw,r); break; }
    case 0x32: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=reg_read(cpu,reg,1)^ea_read(cpu,ea,rm,1);
        set_flags_logic(cpu,r,1); reg_write(cpu,reg,1,r); break; }
    case 0x33: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t r=reg_read(cpu,reg,dw)^ea_read(cpu,ea,rm,dw);
        set_flags_logic(cpu,r,dw); reg_write(cpu,reg,dw,r); break; }
    case 0x34: { uint64_t r=(cpu->regs[REG_RAX]&0xFF)^fetch8(cpu);
        set_flags_logic(cpu,r,1); reg_write(cpu,REG_RAX,1,r); break; }
    case 0x35: { uint64_t i=(dw==2)?fetch16(cpu):(uint64_t)fetch32(cpu);
        uint64_t r=reg_read(cpu,REG_RAX,dw)^i;
        set_flags_logic(cpu,r,dw); reg_write(cpu,REG_RAX,dw,r); break; }

    /* CMP (0x38–0x3D) */
    case 0x38: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=ea_read(cpu,ea,rm,1),b=reg_read(cpu,reg,1),r=a-b;
        set_flags_sub(cpu,a,b,r,1); break; }
    case 0x39: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=ea_read(cpu,ea,rm,dw),b=reg_read(cpu,reg,dw),r=a-b;
        set_flags_sub(cpu,a,b,r,dw); break; }
    case 0x3A: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,1),b=ea_read(cpu,ea,rm,1),r=a-b;
        set_flags_sub(cpu,a,b,r,1); break; }
    case 0x3B: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=reg_read(cpu,reg,dw),b=ea_read(cpu,ea,rm,dw),r=a-b;
        set_flags_sub(cpu,a,b,r,dw); break; }
    case 0x3C: { uint64_t a=cpu->regs[REG_RAX]&0xFF,b=fetch8(cpu),r=a-b;
        set_flags_sub(cpu,a,b,r,1); break; }
    case 0x3D: { uint64_t i=(dw==2)?fetch16(cpu):(uint64_t)(int32_t)fetch32(cpu);
        uint64_t a=reg_read(cpu,REG_RAX,dw),r=a-i;
        set_flags_sub(cpu,a,i,r,dw); break; }

    /* TEST r/m8, r8 (0x84) / TEST r/m, r (0x85) */
    case 0x84: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        set_flags_logic(cpu,ea_read(cpu,ea,rm,1)&reg_read(cpu,reg,1),1); break; }
    case 0x85: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        set_flags_logic(cpu,ea_read(cpu,ea,rm,dw)&reg_read(cpu,reg,dw),dw); break; }

    /* INC/DEC r16/32/64 short form (0x40–0x4F) — only in non-64-bit mode
       (in 64-bit mode these are REX prefixes, handled above) */
    case 0x40: case 0x41: case 0x42: case 0x43:
    case 0x44: case 0x45: case 0x46: case 0x47: {
        if (cpu->mode != CPU_MODE_LONG) {
            int r=op-0x40; uint64_t a=reg_read(cpu,r,dw),v=a+1;
            reg_write(cpu,r,dw,v);
            cpu->rflags&=~(RFLAGS_ZF|RFLAGS_SF|RFLAGS_OF);
            if (!v) cpu->rflags|=RFLAGS_ZF;
            if (v>>(dw*8-1)) cpu->rflags|=RFLAGS_SF;
        }
        break;
    }
    case 0x48: case 0x49: case 0x4A: case 0x4B:
    case 0x4C: case 0x4D: case 0x4E: case 0x4F: {
        if (cpu->mode != CPU_MODE_LONG) {
            int r=op-0x48; uint64_t a=reg_read(cpu,r,dw),v=a-1;
            reg_write(cpu,r,dw,v);
            cpu->rflags&=~(RFLAGS_ZF|RFLAGS_SF|RFLAGS_OF);
            if (!v) cpu->rflags|=RFLAGS_ZF;
            if (v>>(dw*8-1)) cpu->rflags|=RFLAGS_SF;
        }
        break;
    }

    /* GRP5: INC/DEC/CALL/JMP/PUSH r/m (0xFF) */
    case 0xFF: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        switch(reg&7){
        case 0: { uint64_t v=ea_read(cpu,ea,rm,dw)+1; ea_write(cpu,ea,rm,dw,v);
                   set_flags_logic(cpu,v,dw); break; }
        case 1: { uint64_t v=ea_read(cpu,ea,rm,dw)-1; ea_write(cpu,ea,rm,dw,v);
                   set_flags_logic(cpu,v,dw); break; }
        case 2: push64(cpu,cpu->rip); /* CALL r/m64 — fall through to JMP */
                /* FALL THROUGH */
        case 4: cpu->rip=ea_read(cpu,ea,rm,8); break;  /* JMP r/m64 */
        case 6: push64(cpu,ea_read(cpu,ea,rm,dw)); break; /* PUSH r/m */
        default: break;
        }
        break;
    }

    /* GRP4: INC/DEC r/m8 (0xFE) */
    case 0xFE: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t v=ea_read(cpu,ea,rm,1);
        v=(reg&7)==0?v+1:v-1;
        ea_write(cpu,ea,rm,1,v); set_flags_logic(cpu,v,1); break; }

    /* GRP2: shift/rotate r/m (0xC0 imm8, 0xC1 imm8, 0xD0 1, 0xD1 1, 0xD2 CL, 0xD3 CL) */
    case 0xC0: case 0xC1: case 0xD0: case 0xD1: case 0xD2: case 0xD3: {
        int w2=(op==0xC0||op==0xD0||op==0xD2)?1:dw;
        int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        int cnt=0;
        if(op==0xC0||op==0xC1) cnt=fetch8(cpu)&0x1F;
        else if(op==0xD0||op==0xD1) cnt=1;
        else cnt=(int)(cpu->regs[REG_RCX]&0x1F);
        uint64_t v=ea_read(cpu,ea,rm,w2);
        uint64_t mask=(w2==8)?(uint64_t)0xFF:(w2==16)?(uint64_t)0xFFFF:
                     (w2==32)?(uint64_t)0xFFFFFFFF:(uint64_t)0xFFFFFFFFFFFFFFFFULL;
        v&=mask;
        switch(reg&7){
        case 4: v=(v<<cnt)&mask; break; /* SHL */
        case 5: v=v>>cnt; break;        /* SHR */
        case 7: { /* SAR */
            int64_t sv=(w2==1)?(int8_t)v:(w2==2)?(int16_t)v:
                       (w2==4)?(int32_t)v:(int64_t)v;
            v=(uint64_t)(sv>>cnt)&mask; break; }
        case 0: { /* ROL */
            int n=w2*8; cnt%=n;
            v=((v<<cnt)|(v>>(n-cnt)))&mask; break; }
        case 1: { /* ROR */
            int n=w2*8; cnt%=n;
            v=((v>>cnt)|(v<<(n-cnt)))&mask; break; }
        default: break;
        }
        ea_write(cpu,ea,rm,w2,v);
        set_flags_logic(cpu,v,w2);
        break;
    }

    /* IMUL r8/16/32/64, r/m, imm (0x69 imm, 0x6B imm8) */
    case 0x69: case 0x6B: { int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t a=ea_read(cpu,ea,rm,dw);
        uint64_t b=(op==0x6B)?(uint64_t)(int8_t)fetch8(cpu):
                   (dw==2)?fetch16(cpu):(uint64_t)(int32_t)fetch32(cpu);
        reg_write(cpu,reg,dw,a*b); break; }

    /* MUL r/m (GRP3 /4) — simplified: only 32-bit */
    case 0xF6: case 0xF7: {
        int w2=(op==0xF6)?1:dw;
        int reg,rm; uint8_t modrm=fetch8(cpu);
        uint64_t ea=decode_modrm(cpu,modrm,pfx,&reg,&rm);
        uint64_t v=ea_read(cpu,ea,rm,w2);
        switch(reg&7){
        case 0: set_flags_logic(cpu,v,w2); break; /* TEST r/m, imm */
        case 2: ea_write(cpu,ea,rm,w2,~v); break; /* NOT */
        case 3: { uint64_t nv=(uint64_t)(-(int64_t)v);
                  ea_write(cpu,ea,rm,w2,nv); set_flags_logic(cpu,nv,w2); break; } /* NEG */
        case 4: { /* MUL */
            uint64_t r=reg_read(cpu,REG_RAX,w2)*v;
            reg_write(cpu,REG_RAX,w2,r); break; }
        case 5: { /* IMUL */
            int64_t r=(int64_t)reg_read(cpu,REG_RAX,w2)*(int64_t)v;
            reg_write(cpu,REG_RAX,w2,(uint64_t)r); break; }
        case 6: { /* DIV — protected against div-by-zero */
            if (v==0) break;
            uint64_t quo=reg_read(cpu,REG_RAX,w2)/v;
            reg_write(cpu,REG_RAX,w2,quo); break; }
        case 7: { /* IDIV */
            if (v==0||v==(uint64_t)-1) break;
            int64_t q=(int64_t)reg_read(cpu,REG_RAX,w2)/(int64_t)v;
            reg_write(cpu,REG_RAX,w2,(uint64_t)q); break; }
        default: break;
        }
        if ((reg&7)==0) { /* TEST needs imm */
            uint64_t i=(w2==1)?fetch8(cpu):(w2==2)?fetch16(cpu):(uint64_t)fetch32(cpu);
            set_flags_logic(cpu,v&i,w2);
        }
        break;
    }

    /* CALL rel32 (0xE8) */
    case 0xE8: { int32_t rel=(int32_t)fetch32(cpu);
        push64(cpu,cpu->rip);
        cpu->rip=(uint64_t)((int64_t)cpu->rip+rel); break; }

    /* RET near (0xC3) */
    case 0xC3: cpu->rip=pop64(cpu); break;

    /* RET near imm16 (0xC2) */
    case 0xC2: { uint16_t n=fetch16(cpu);
        cpu->rip=pop64(cpu); cpu->regs[REG_RSP]+=n; break; }

    /* RETF (0xCB / 0xCA) */
    case 0xCB: { pop64(cpu); cpu->rip=pop64(cpu); break; } /* CS discarded */
    case 0xCA: { uint16_t n=fetch16(cpu);
        pop64(cpu); cpu->rip=pop64(cpu); cpu->regs[REG_RSP]+=n; break; }

    /* IRET (0xCF) */
    case 0xCF:
        cpu->rip    = pop64(cpu);
        pop64(cpu); /* CS */
        cpu->rflags = pop64(cpu);
        break;

    /* JMP rel8 (0xEB) */
    case 0xEB: { int8_t rel=(int8_t)fetch8(cpu);
        cpu->rip=(uint64_t)((int64_t)cpu->rip+rel); break; }

    /* JMP rel16/32 (0xE9) */
    case 0xE9: {
        int32_t rel;
        if(dw==2) rel=(int16_t)fetch16(cpu);
        else      rel=(int32_t)fetch32(cpu);
        cpu->rip=(uint64_t)((int64_t)cpu->rip+rel); break; }

    /* JMP far ptr16:16/32 (0xEA) — treat as near (ignore CS) */
    case 0xEA: { uint32_t off=(dw==2)?fetch16(cpu):fetch32(cpu);
        fetch16(cpu); /* CS */ cpu->rip=off; break; }

    /* Jcc rel8 (0x70–0x7F) */
    case 0x70: case 0x71: case 0x72: case 0x73:
    case 0x74: case 0x75: case 0x76: case 0x77:
    case 0x78: case 0x79: case 0x7A: case 0x7B:
    case 0x7C: case 0x7D: case 0x7E: case 0x7F: {
        int8_t rel=(int8_t)fetch8(cpu);
        if(eval_cond(cpu,op&0xF))
            cpu->rip=(uint64_t)((int64_t)cpu->rip+rel);
        break;
    }

    /* JCXZ / JECXZ / JRCXZ (0xE3) */
    case 0xE3: { int8_t rel=(int8_t)fetch8(cpu);
        uint64_t cx=(cpu->mode==CPU_MODE_LONG)?cpu->regs[REG_RCX]:
                    (dw==4)?cpu->regs[REG_RCX]&0xFFFFFFFF:
                            cpu->regs[REG_RCX]&0xFFFF;
        if(!cx) cpu->rip=(uint64_t)((int64_t)cpu->rip+rel);
        break; }

    /* LOOP / LOOPE / LOOPNE (0xE0–0xE2) */
    case 0xE0: case 0xE1: case 0xE2: {
        int8_t rel=(int8_t)fetch8(cpu);
        uint64_t cx=--cpu->regs[REG_RCX];
        if(dw<8) cx&=(dw==4?0xFFFFFFFF:0xFFFF);
        int take=(cx!=0);
        if(op==0xE0) take=take&&!(cpu->rflags&RFLAGS_ZF);
        if(op==0xE1) take=take&&(cpu->rflags&RFLAGS_ZF);
        if(take) cpu->rip=(uint64_t)((int64_t)cpu->rip+rel);
        break; }

    /* CALL far (0x9A) — simplified: ignore CS, treat offset as near */
    case 0x9A: { uint32_t off=(dw==2)?fetch16(cpu):fetch32(cpu);
        fetch16(cpu); push64(cpu,cpu->rip); cpu->rip=off; break; }

    /* IN AL, imm8 (0xE4) / IN AX/EAX, imm8 (0xE5) */
    case 0xE4: fetch8(cpu); cpu->regs[REG_RAX]&=~0xFFULL; break;
    case 0xE5: { fetch8(cpu);
        if(dw==2) cpu->regs[REG_RAX]&=~0xFFFFULL;
        else      { cpu->regs[REG_RAX]&=~0xFFFFFFFFULL; } break; }
    /* IN AL, DX (0xEC) / IN AX/EAX, DX (0xED) */
    case 0xEC: cpu->regs[REG_RAX]&=~0xFFULL; break;
    case 0xED: { if(dw==2) cpu->regs[REG_RAX]&=~0xFFFFULL;
                 else      { cpu->regs[REG_RAX]&=~0xFFFFFFFFULL; } break; }
    /* OUT imm8, AL (0xE6) / OUT imm8, AX/EAX (0xE7) */
    case 0xE6: fetch8(cpu); break;
    case 0xE7: fetch8(cpu); break;
    /* OUT DX, AL (0xEE) / OUT DX, AX/EAX (0xEF) */
    case 0xEE: case 0xEF: break;

    /* INT n (0xCD) */
    case 0xCD: { uint8_t n=fetch8(cpu);
        uint64_t vec=cpu->intr->vector_table[n];
        if(vec){ push64(cpu,cpu->rflags); push64(cpu,cpu->rip);
                 cpu->rflags&=~RFLAGS_IF; cpu->rip=vec; }
        else { uart_printf("[CPU] INT 0x%02x (no handler)\n",(unsigned)n); }
        break; }

    /* INT3 (0xCC) */
    case 0xCC: { uint64_t vec=cpu->intr->vector_table[3];
        if(vec){ push64(cpu,cpu->rflags); push64(cpu,cpu->rip); cpu->rip=vec; }
        break; }

    /* INTO (0xCE) */
    case 0xCE: break;

    /* ENTER (0xC8) */
    case 0xC8: { uint16_t sz=fetch16(cpu); fetch8(cpu);
        push64(cpu,cpu->regs[REG_RBP]);
        cpu->regs[REG_RBP]=cpu->regs[REG_RSP];
        cpu->regs[REG_RSP]-=sz; break; }

    /* LEAVE (0xC9) */
    case 0xC9: cpu->regs[REG_RSP]=cpu->regs[REG_RBP]; cpu->regs[REG_RBP]=pop64(cpu); break;

    /* CBW/CWDE/CDQE (0x98) */
    case 0x98:
        if(dw==8) cpu->regs[REG_RAX]=(uint64_t)(int64_t)(int32_t)(cpu->regs[REG_RAX]&0xFFFFFFFF);
        else if(dw==4) cpu->regs[REG_RAX]=(uint64_t)(int32_t)(int16_t)(cpu->regs[REG_RAX]&0xFFFF);
        else cpu->regs[REG_RAX]=(cpu->regs[REG_RAX]&~0xFFFFULL)|
                                 (uint64_t)(uint16_t)(int16_t)(int8_t)(cpu->regs[REG_RAX]&0xFF);
        break;

    /* CWD/CDQ/CQO (0x99) */
    case 0x99:
        if(dw==8) cpu->regs[REG_RDX]=((int64_t)cpu->regs[REG_RAX]<0)?(uint64_t)-1:0;
        else if(dw==4) cpu->regs[REG_RDX]=((int32_t)(cpu->regs[REG_RAX]&0xFFFFFFFF)<0)?0xFFFFFFFF:0;
        else cpu->regs[REG_RDX]=(cpu->regs[REG_RDX]&~0xFFFFULL)|
                                  (((int16_t)(cpu->regs[REG_RAX]&0xFFFF)<0)?0xFFFF:0);
        break;

    /* MOVSB/MOVSW/MOVSD/MOVSQ (0xA4/A5) */
    case 0xA4: {
        uint64_t cnt=(pfx&PFX_REP)?reg_read(cpu,REG_RCX,dw):1;
        int step=(cpu->rflags&RFLAGS_DF)?-1:1;
        for(uint64_t i=0;i<cnt;i++){
            mem_w8(cpu,cpu->regs[REG_RDI],(uint8_t)mem_r8(cpu,cpu->regs[REG_RSI]));
            cpu->regs[REG_RSI]=(uint64_t)((int64_t)cpu->regs[REG_RSI]+step);
            cpu->regs[REG_RDI]=(uint64_t)((int64_t)cpu->regs[REG_RDI]+step);
        }
        if(pfx&PFX_REP) reg_write(cpu,REG_RCX,dw,0);
        break; }
    case 0xA5: {
        uint64_t cnt=(pfx&PFX_REP)?reg_read(cpu,REG_RCX,dw):1;
        int step=(cpu->rflags&RFLAGS_DF)?-(int)dw:(int)dw;
        for(uint64_t i=0;i<cnt;i++){
            uint64_t v=ea_read(cpu,cpu->regs[REG_RSI],-1,dw);
            ea_write(cpu,cpu->regs[REG_RDI],-1,dw,v);
            cpu->regs[REG_RSI]=(uint64_t)((int64_t)cpu->regs[REG_RSI]+step);
            cpu->regs[REG_RDI]=(uint64_t)((int64_t)cpu->regs[REG_RDI]+step);
        }
        if(pfx&PFX_REP) reg_write(cpu,REG_RCX,dw,0);
        break; }

    /* STOSB/STOSW/STOSD/STOSQ (0xAA/AB) */
    case 0xAA: {
        uint64_t cnt=(pfx&PFX_REP)?reg_read(cpu,REG_RCX,dw):1;
        int step=(cpu->rflags&RFLAGS_DF)?-1:1;
        for(uint64_t i=0;i<cnt;i++){
            mem_w8(cpu,cpu->regs[REG_RDI],(uint8_t)cpu->regs[REG_RAX]);
            cpu->regs[REG_RDI]=(uint64_t)((int64_t)cpu->regs[REG_RDI]+step);
        }
        if(pfx&PFX_REP) reg_write(cpu,REG_RCX,dw,0);
        break; }
    case 0xAB: {
        uint64_t cnt=(pfx&PFX_REP)?reg_read(cpu,REG_RCX,dw):1;
        int step=(cpu->rflags&RFLAGS_DF)?-(int)dw:(int)dw;
        for(uint64_t i=0;i<cnt;i++){
            ea_write(cpu,cpu->regs[REG_RDI],-1,dw,reg_read(cpu,REG_RAX,dw));
            cpu->regs[REG_RDI]=(uint64_t)((int64_t)cpu->regs[REG_RDI]+step);
        }
        if(pfx&PFX_REP) reg_write(cpu,REG_RCX,dw,0);
        break; }

    /* LODSB/LODSW/LODSD (0xAC/AD) */
    case 0xAC: {
        reg_write(cpu,REG_RAX,1,mem_r8(cpu,cpu->regs[REG_RSI]));
        cpu->regs[REG_RSI]+=(cpu->rflags&RFLAGS_DF)?-1:1; break; }
    case 0xAD: {
        reg_write(cpu,REG_RAX,dw,ea_read(cpu,cpu->regs[REG_RSI],-1,dw));
        cpu->regs[REG_RSI]+=(cpu->rflags&RFLAGS_DF)?-(int)dw:(int)dw; break; }

    /* SCASB/SCASW/SCASD (0xAE/AF) */
    case 0xAE: {
        uint64_t cnt=(pfx&(PFX_REP|PFX_REPNE))?reg_read(cpu,REG_RCX,dw):1;
        int step=(cpu->rflags&RFLAGS_DF)?-1:1;
        for(uint64_t i=0;i<cnt;i++){
            uint64_t a=cpu->regs[REG_RAX]&0xFF, b=mem_r8(cpu,cpu->regs[REG_RDI]);
            cpu->regs[REG_RDI]=(uint64_t)((int64_t)cpu->regs[REG_RDI]+step);
            set_flags_sub(cpu,a,b,a-b,1);
            if((pfx&PFX_REP)  && !(cpu->rflags&RFLAGS_ZF)) break;
            if((pfx&PFX_REPNE)&&  (cpu->rflags&RFLAGS_ZF)) break;
        }
        if(pfx&(PFX_REP|PFX_REPNE)) reg_write(cpu,REG_RCX,dw,0);
        break; }
    case 0xAF: break; /* SCASW — stub */

    /* MOV AL/AX/EAX, moffs (0xA0/A1) */
    case 0xA0: { uint64_t addr=(cpu->mode==CPU_MODE_LONG)?fetch64(cpu):
                    (dw==4?fetch32(cpu):fetch16(cpu));
        reg_write(cpu,REG_RAX,1,mem_r8(cpu,addr)); break; }
    case 0xA1: { uint64_t addr=(cpu->mode==CPU_MODE_LONG)?fetch64(cpu):
                    (dw==4?fetch32(cpu):fetch16(cpu));
        reg_write(cpu,REG_RAX,dw,ea_read(cpu,addr,-1,dw)); break; }
    /* MOV moffs, AL/AX/EAX (0xA2/A3) */
    case 0xA2: { uint64_t addr=(cpu->mode==CPU_MODE_LONG)?fetch64(cpu):
                    (dw==4?fetch32(cpu):fetch16(cpu));
        mem_w8(cpu,addr,(uint8_t)cpu->regs[REG_RAX]); break; }
    case 0xA3: { uint64_t addr=(cpu->mode==CPU_MODE_LONG)?fetch64(cpu):
                    (dw==4?fetch32(cpu):fetch16(cpu));
        ea_write(cpu,addr,-1,dw,reg_read(cpu,REG_RAX,dw)); break; }

    /* MOV CR0, r32 (via GRP: handled in the F7/special path if we see opcode 0F 22) */
    /* We detect CR0 write here via a separate direct path for real-mode LGDT sequence */
    /* Real-mode pmode enable sequence: MOV CR0, EAX with PE bit */

    /* WAIT / FWAIT (0x9B) */
    case 0x9B: break;

    /* BOUND (0x62) — skip ModRM */
    case 0x62: fetch8(cpu); break;

    /* AAA/AAS/AAM/AAD/DAA/DAS — 8086 BCD, ignore */
    case 0x37: case 0x3F: case 0xD4: case 0xD5:
    case 0x27: case 0x2F: break;

    /* XLAT (0xD7) */
    case 0xD7: {
        uint64_t addr=cpu->regs[REG_RBX]+(cpu->regs[REG_RAX]&0xFF);
        reg_write(cpu,REG_RAX,1,mem_r8(cpu,addr)); break; }

    /* UD2 (0x0F 0B — handled via ESC2) */
    /* Nop 2-byte / multi-byte NOPs (0x0F 1F — ESC2 path skips them) */

    default:
        /* Unrecognised opcode — log but do not halt. Many real boot code
           sequences include instructions we don't implement yet. Silently
           consuming and continuing gives the boot loader the best chance
           of reaching code we do support. */
        uart_printf("[CPU] Unimpl opcode 0x%02x at 0x%llx (mode=%d) -- skipping\n",
                    (unsigned)op, (unsigned long long)(cpu->rip-1), cpu->mode);
        break;
    }

insn_done:
    /* Keep RSP register consistent */
    cpu->rsp = cpu->regs[REG_RSP];

    /* Detect CR0.PE transition (pmode enable) */
    if (cpu->mode == CPU_MODE_REAL && (cpu->cr0 & 1)) {
        cpu->mode = CPU_MODE_PROT;
        uart_printf("[CPU] Protected mode enabled\n");
    }
}

void cpu_run(CPU *cpu, size_t max_steps)
{
    for (size_t i = 0; i < max_steps && !cpu->halted && !cpu->fault; i++)
        cpu_step(cpu);
    if (!cpu->halted && !cpu->fault)
        uart_printf("[CPU] Step limit (%zu) reached, RIP=0x%llx\n",
                    max_steps, (unsigned long long)cpu->rip);
}
