#ifndef HDMI_H
#define HDMI_H

#include <stdint.h>
#include <stddef.h>

/*
 * hdmi.h — Bare-metal HDMI framebuffer driver for AArch64
 *
 * Targets two common ARM platforms:
 *
 *   1. QEMU "virt" machine — uses the "pl111" PrimeCell Color LCD
 *      controller at base address 0x1C1F0000 (ARM virt board default).
 *      -device VGA or -device virtio-gpu-pci can also be used; see note
 *      in hdmi.c about selecting the backend.
 *
 *   2. Raspberry Pi 4 — uses the VideoCore VI GPU mailbox property
 *      interface to allocate a linear framebuffer over HDMI.
 *      The mailbox is at 0xFE00B880.
 *
 * Build-time selection:
 *   -DHDMI_BACKEND=HDMI_BACKEND_PL111     (default, QEMU)
 *   -DHDMI_BACKEND=HDMI_BACKEND_RPI4      (Raspberry Pi 4)
 *
 * Pixel format: 32-bit ARGB (0xAARRGGBB) stored little-endian in RAM.
 * Default resolution: 1280 × 720.  Override:
 *   -DHDMI_WIDTH=1920 -DHDMI_HEIGHT=1080
 */

/* -----------------------------------------------------------------------
 * Backend selection
 * --------------------------------------------------------------------- */
#define HDMI_BACKEND_PL111  1
#define HDMI_BACKEND_RPI4   2

#ifndef HDMI_BACKEND
#  define HDMI_BACKEND HDMI_BACKEND_PL111
#endif

/* -----------------------------------------------------------------------
 * Resolution
 * --------------------------------------------------------------------- */
#ifndef HDMI_WIDTH
#  define HDMI_WIDTH  1280
#endif
#ifndef HDMI_HEIGHT
#  define HDMI_HEIGHT  720
#endif

#define HDMI_BPP       32                          /* bits per pixel      */
#define HDMI_PITCH    (HDMI_WIDTH * (HDMI_BPP / 8))
#define HDMI_FB_SIZE  (HDMI_PITCH * HDMI_HEIGHT)   /* bytes               */

/* -----------------------------------------------------------------------
 * PL111 CLCD register base (QEMU virt)
 * Override: -DPL111_BASE=0x...
 * --------------------------------------------------------------------- */
#ifndef PL111_BASE
#  define PL111_BASE 0x1C1F0000UL
#endif

/* PL111 register offsets */
#define PL111_TIMING0   0x000
#define PL111_TIMING1   0x004
#define PL111_TIMING2   0x008
#define PL111_TIMING3   0x00C
#define PL111_UPBASE    0x010   /* Upper panel frame-buffer base address */
#define PL111_LPBASE    0x014   /* Lower panel frame-buffer base address */
#define PL111_CONTROL   0x018
#define PL111_IMSC      0x01C

/* CONTROL bits */
#define PL111_CTRL_LCDEN   (1u <<  0)
#define PL111_CTRL_BPP24   (5u <<  1)   /* 24 bpp (packed in 32-bit words) */
#define PL111_CTRL_TFT     (1u <<  5)
#define PL111_CTRL_BGR     (1u <<  8)
#define PL111_CTRL_POWER   (1u << 11)

/* -----------------------------------------------------------------------
 * Raspberry Pi 4 VideoCore mailbox
 * Override: -DRPI4_MBOX_BASE=0x...
 * --------------------------------------------------------------------- */
#ifndef RPI4_MBOX_BASE
#  define RPI4_MBOX_BASE 0xFE00B880UL
#endif

/* Mailbox register offsets */
#define MBOX_READ    0x00
#define MBOX_STATUS  0x18
#define MBOX_WRITE   0x20

/* Mailbox status bits */
#define MBOX_FULL    (1u << 31)
#define MBOX_EMPTY   (1u << 30)

/* Mailbox channels */
#define MBOX_CH_PROP 8

/* VideoCore property tag IDs */
#define RPI_TAG_SET_PHYS_WH     0x00048003
#define RPI_TAG_SET_VIRT_WH     0x00048004
#define RPI_TAG_SET_VIRT_OFFSET 0x00048009
#define RPI_TAG_SET_DEPTH       0x00048005
#define RPI_TAG_SET_PIXEL_ORDER 0x00048006
#define RPI_TAG_ALLOC_FB        0x00040001
#define RPI_TAG_GET_PITCH       0x00040008
#define RPI_TAG_END             0x00000000

/* -----------------------------------------------------------------------
 * Framebuffer state
 * --------------------------------------------------------------------- */
typedef struct HDMI {
    uint32_t *fb;           /* Pointer to framebuffer base              */
    uint32_t  width;        /* Pixels per line                          */
    uint32_t  height;       /* Lines                                    */
    uint32_t  pitch;        /* Bytes per line                           */
    uint32_t  bpp;          /* Bits per pixel (always 32)               */
    int       ready;        /* 1 once hdmi_init() succeeded             */
    /* Text cursor */
    uint32_t  cursor_x;     /* Current text column (characters)         */
    uint32_t  cursor_y;     /* Current text row    (characters)         */
} HDMI;

/* -----------------------------------------------------------------------
 * Public API
 * --------------------------------------------------------------------- */

/*
 * hdmi_init — initialise the display controller and set up a linear
 * 32-bit ARGB framebuffer.
 *
 * fb_phys_addr: physical address of the framebuffer region in RAM.
 *               Must be at least HDMI_FB_SIZE bytes, 4 KB aligned.
 *               (Provided by the linker script as _fb_start.)
 *
 * Returns 0 on success, -1 on failure.
 */
int  hdmi_init(HDMI *hdmi, uint32_t fb_phys_addr);

/* Fill the entire screen with one colour (0xAARRGGBB). */
void hdmi_clear(HDMI *hdmi, uint32_t colour);

/* Draw a single pixel. */
void hdmi_pixel(HDMI *hdmi, uint32_t x, uint32_t y, uint32_t colour);

/* Draw a filled rectangle. */
void hdmi_rect(HDMI *hdmi, uint32_t x, uint32_t y,
               uint32_t w, uint32_t h, uint32_t colour);

/* Draw a single 8×16 character from the built-in bitmap font. */
void hdmi_char(HDMI *hdmi, uint32_t x, uint32_t y,
               char c, uint32_t fg, uint32_t bg);

/*
 * hdmi_puts — print a string at the current text cursor position,
 * handling '\n' and automatic line-wrap.  Uses 8×16 font.
 * fg/bg are 0xAARRGGBB colours.
 */
void hdmi_puts(HDMI *hdmi, const char *s, uint32_t fg, uint32_t bg);

/* Draw the FloofVM splash screen (logo + version string). */
void hdmi_splash(HDMI *hdmi);

#endif /* HDMI_H */