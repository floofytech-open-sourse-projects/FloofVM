#include "loader.h"
#include "mmu.h"
#include "cpu.h"
#include "devices.h"
#include "elf.h"
#include "uart.h"
#include "flooflibc.h"

/*
 * loader.c — El Torito ISO boot loader + protected/long mode setup
 *
 * Real AMD64 ISO boot flow (e.g. Alpine, Ubuntu, Debian):
 *
 *  1. Parse the ISO 9660 Volume Descriptor Set to find the El Torito
 *     Boot Record Descriptor.
 *  2. Read the boot catalog; select the default/initial boot entry.
 *  3. Determine load address from the El Torito entry:
 *       - No-emulation entries:  load image at 0x7C00 (BIOS convention)
 *         or at a higher address if the sector count implies a large image.
 *       - Floppy-emulation entries: load 2880 sectors at 0x7C00.
 *       - Hard-disk-emulation: load MBR at 0x7C00.
 *  4. Set up a minimal BIOS-like environment in guest RAM:
 *       - Real-mode IVT at 0x0000:0000 (256 × 4-byte vectors)
 *       - BIOS Data Area stub at 0x0040:0000
 *       - E820 memory map at 0x0000:2000 (used by Linux BIOS int 0x15)
 *       - Fake MBR signature 0x55AA at offset 510 of the boot sector
 *         (some boot loaders check this)
 *  5. Initialise CPU registers to BIOS post-reset values:
 *       CS=0x0000  IP=0x7C00  SS=0x0000  SP=0x7C00
 *       DL=0x80 (first hard disk / CD-ROM)
 *       ES:SI → El Torito drive specification packet (for GRUB/ISOLINUX)
 *  6. Run the boot image with cpu_run().
 */

/* -----------------------------------------------------------------------
 * ISO 9660 / El Torito constants
 * --------------------------------------------------------------------- */
#define ISO_SECTOR          2048
#define ISO_SYSAREA_LBAS    16
#define ISO_VD_BOOT         0x00
#define ISO_VD_PRIMARY      0x01
#define ISO_VD_TERMINATOR   0xFF

#define ELTORITO_CAT_OFFSET 32      /* default entry offset in catalog   */
#define ELTORITO_BOOTABLE   0x88
#define ELTORITO_MEDIA_NONE 0x00
#define ELTORITO_MEDIA_FD12 0x01
#define ELTORITO_MEDIA_FD144 0x02
#define ELTORITO_MEDIA_FD288 0x03
#define ELTORITO_MEDIA_HD   0x04

/* -----------------------------------------------------------------------
 * Guest memory layout constants
 * --------------------------------------------------------------------- */
#define BIOS_IVT_BASE       0x00000000UL   /* real-mode IVT (1 KB)       */
#define BIOS_DATA_BASE      0x00000400UL   /* BIOS Data Area stub        */
#define BIOS_E820_BASE      0x00002000UL   /* E820 table (max 32 entries)*/
#define BOOT_LOAD_ADDR      0x00007C00UL   /* classic BIOS boot address  */
#define EBDA_BASE           0x0009FC00UL   /* Extended BIOS Data Area    */
#define BIOS_ROM_BASE       0x000E0000UL   /* BIOS ROM shadow            */

/* El Torito Drive Specification Packet address (ES:SI on entry) */
#define ELTSPEC_SEG         0x0000
#define ELTSPEC_OFF         0x1000         /* flat 0x1000                */

/* -----------------------------------------------------------------------
 * LE helper
 * --------------------------------------------------------------------- */
static uint16_t le16(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}
static uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0]       | ((uint32_t)p[1] <<  8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

/* -----------------------------------------------------------------------
 * read_iso_sector — copy one 2 KB sector into dst
 * --------------------------------------------------------------------- */
static int read_iso_sector(const uint8_t *iso, size_t iso_size,
                            uint32_t lba, uint8_t *dst)
{
    uint64_t off = (uint64_t)lba * ISO_SECTOR;
    if (off + ISO_SECTOR > (uint64_t)iso_size) {
        uart_printf("[LDR] Sector %u OOB (iso_size=%zu)\n", lba, iso_size);
        return -1;
    }
    memcpy(dst, iso + off, ISO_SECTOR);
    return 0;
}

/* -----------------------------------------------------------------------
 * write_guest — write bytes into guest RAM
 * --------------------------------------------------------------------- */
static void write_guest(struct MMU *mmu, uint32_t addr,
                         const uint8_t *src, size_t len)
{
    for (size_t i = 0; i < len; i++)
        mmu_write8(mmu, (uint64_t)(addr + i), src[i]);
}

static void write_guest16(struct MMU *mmu, uint32_t addr, uint16_t v)
{
    mmu_write8(mmu, addr,     (uint8_t)v);
    mmu_write8(mmu, addr + 1, (uint8_t)(v >> 8));
}
static void write_guest32(struct MMU *mmu, uint32_t addr, uint32_t v)
{
    write_guest16(mmu, addr,     (uint16_t)v);
    write_guest16(mmu, addr + 2, (uint16_t)(v >> 16));
}

/* -----------------------------------------------------------------------
 * setup_bios_environment
 *
 * Populate guest RAM with the minimal BIOS-like structures that real
 * boot loaders expect to find:
 *
 *  0x0000–0x03FF  Real-mode IVT — each vector is seg:off little-endian.
 *                 We point every vector at a tiny "IRET stub" at 0x0500.
 *  0x0400–0x04FF  BIOS Data Area (selected fields only).
 *  0x0500–0x0503  IRET stub used by the fake IVT vectors.
 *  0x1000–0x105F  El Torito Drive Spec Packet (passed in ES:SI).
 *  0x2000–...     ACPI E820 memory map table (read by int 0x15 EAX=0xE820).
 * --------------------------------------------------------------------- */
static void setup_bios_environment(struct MMU *mmu, size_t ram_size)
{
    /* ---- 0x0500: IRET stub ----------------------------------------- */
    /* opcode CF = IRET */
    mmu_write8(mmu, 0x0500, 0xCF);

    /* ---- IVT: 256 vectors, all pointing to the IRET stub ----------- */
    for (int i = 0; i < 256; i++) {
        uint32_t ivt_entry = (uint32_t)(i * 4);
        write_guest16(mmu, ivt_entry,     0x0500); /* offset */
        write_guest16(mmu, ivt_entry + 2, 0x0000); /* segment */
    }

    /* ---- BIOS Data Area (0x0400) ------------------------------------ */
    /* COM1 base = 0x03F8 */
    write_guest16(mmu, 0x0400, 0x03F8);
    /* Equipment word: bit0=floppy, bits4-5=video mode (0=EGA/VGA) */
    write_guest16(mmu, 0x0410, 0x0041);
    /* Memory size (in KB below 640 KB line) */
    write_guest16(mmu, 0x0413, 640);
    /* Hard disk count */
    mmu_write8(mmu, 0x0475, 1);

    /* ---- E820 memory map at 0x2000 --------------------------------- */
    /*
     * Format: array of 20-byte entries
     *   uint64_t base
     *   uint64_t length
     *   uint32_t type  (1=usable, 2=reserved, 3=ACPI, 4=NVS, 5=bad)
     *
     * Three regions:
     *   0x00000000 – 0x0009FFFF  640 KB conventional RAM       (usable)
     *   0x000A0000 – 0x000FFFFF  384 KB VGA/ROM                (reserved)
     *   0x00100000 – ram_size-1  Extended RAM                  (usable)
     */
    uint32_t e = 0x2000;
    /* Entry 0: conventional RAM */
    write_guest32(mmu, e +  0, 0x00000000); write_guest32(mmu, e +  4, 0);
    write_guest32(mmu, e +  8, 0x000A0000); write_guest32(mmu, e + 12, 0);
    write_guest32(mmu, e + 16, 1);
    e += 20;
    /* Entry 1: VGA / ROM area */
    write_guest32(mmu, e +  0, 0x000A0000); write_guest32(mmu, e +  4, 0);
    write_guest32(mmu, e +  8, 0x00060000); write_guest32(mmu, e + 12, 0);
    write_guest32(mmu, e + 16, 2);
    e += 20;
    /* Entry 2: extended RAM */
    write_guest32(mmu, e +  0, 0x00100000); write_guest32(mmu, e +  4, 0);
    write_guest32(mmu, e +  8, (uint32_t)(ram_size - 0x100000));
    write_guest32(mmu, e + 12, (uint32_t)((ram_size - 0x100000) >> 32));
    write_guest32(mmu, e + 16, 1);

    /* ---- El Torito Drive Specification Packet at 0x1000 ----------- */
    /*
     * BIOS Enhanced Disk Drive (EDD) specification packet:
     *   byte  0: packet size (0x13)
     *   byte  1: media type (0x00 = no emulation)
     *   byte  2: drive number (0x00 = first CD-ROM, also called 0x80+)
     *   byte  3: controller index
     *   dword 4: image LBA (0 = whole device)
     *   word  8: device specification (0xFFFF)
     *   word 10: user buffer segment
     *   word 12: load segment
     *   word 14: sector count
     *   byte 16: heads per cyl (0)
     *   byte 17: sectors per track (0)
     *   byte 18: reserved (0)
     */
    mmu_write8(mmu, 0x1000 +  0, 0x13); /* size           */
    mmu_write8(mmu, 0x1000 +  1, 0x00); /* no emulation   */
    mmu_write8(mmu, 0x1000 +  2, 0x00); /* drive 0        */
    mmu_write8(mmu, 0x1000 +  3, 0x00);
    write_guest32(mmu, 0x1000 + 4,  0x00000000); /* LBA lo */
    write_guest32(mmu, 0x1000 + 8,  0x00000000); /* LBA hi */
    write_guest16(mmu, 0x1000 + 12, 0xFFFF);     /* device spec */
    write_guest16(mmu, 0x1000 + 14, 0x0000);     /* user seg */
    write_guest16(mmu, 0x1000 + 16, 0x0000);     /* load seg */
    write_guest16(mmu, 0x1000 + 18, 0x0004);     /* sector count */
}

/* -----------------------------------------------------------------------
 * loader_init
 * --------------------------------------------------------------------- */
void loader_init(Loader *ldr, struct MMU *mmu,
                 struct CPU *cpu, struct Devices *dev)
{
    ldr->mmu = mmu;
    ldr->cpu = cpu;
    ldr->dev = dev;
}

/* -----------------------------------------------------------------------
 * loader_boot_iso — El Torito boot of a real AMD64 ISO image
 * --------------------------------------------------------------------- */
void loader_boot_iso(Loader *ldr)
{
    const uint8_t *iso      = ldr->dev->iso_data;
    size_t         iso_size = ldr->dev->iso_size;

    if (!iso || iso_size < (uint64_t)ISO_SYSAREA_LBAS * ISO_SECTOR) {
        uart_printf("[LDR] No valid ISO mounted\n");
        return;
    }

    uint8_t  sector[ISO_SECTOR];
    uint32_t catalog_lba = 0;
    int      found_brd   = 0;

    /* ---- Step 1: Walk Volume Descriptor Set for Boot Record --------- */
    for (uint32_t lba = ISO_SYSAREA_LBAS; lba < ISO_SYSAREA_LBAS + 16; lba++) {
        if (read_iso_sector(iso, iso_size, lba, sector) != 0) break;

        /* Every VD starts with type byte then "CD001" then version 0x01 */
        if (memcmp(sector + 1, "CD001", 5) != 0) break;

        if (sector[0] == ISO_VD_TERMINATOR) {
            uart_printf("[LDR] VD Terminator reached — no Boot Record found\n");
            break;
        }
        if (sector[0] == ISO_VD_BOOT) {
            /* Boot System Identifier must be "EL TORITO SPECIFICATION" */
            if (memcmp(sector + 7, "EL TORITO SPECIFICATION", 23) == 0) {
                catalog_lba = le32(sector + 71);
                found_brd   = 1;
                uart_printf("[LDR] El Torito Boot Record at LBA %u, "
                            "catalog LBA %u\n", lba, catalog_lba);
                break;
            }
        }
    }

    if (!found_brd || catalog_lba == 0) {
        uart_printf("[LDR] El Torito Boot Record not found\n");
        return;
    }

    /* ---- Step 2: Read boot catalog ---------------------------------- */
    if (read_iso_sector(iso, iso_size, catalog_lba, sector) != 0) {
        uart_printf("[LDR] Cannot read boot catalog sector\n");
        return;
    }

    /* Validation Entry (first 32 bytes):
       byte 0 = 0x01 (header ID), bytes 30–31 = 0x55 0xAA */
    if (sector[0] != 0x01 || sector[30] != 0x55 || sector[31] != 0xAA) {
        uart_printf("[LDR] Boot catalog validation entry invalid\n");
        /* Non-fatal — some ISOs omit the proper checksum; proceed anyway */
    }

    /* Default/Initial Entry is at offset 32 in the catalog */
    const uint8_t *entry = sector + ELTORITO_CAT_OFFSET;

    uint8_t  bootable      = entry[0];
    uint8_t  media_type    = entry[1] & 0x0F;
    uint16_t load_segment  = le16(entry + 2);  /* 0 = 0x07C0 by convention */
    /* entry[4] = system type (partition type) */
    uint16_t sector_count  = le16(entry + 6);  /* virtual 512-byte sectors  */
    uint32_t load_lba      = le32(entry + 8);

    uart_printf("[LDR] Boot entry: bootable=0x%02x media=%u "
                "seg=0x%04x sectors=%u lba=%u\n",
                (unsigned)bootable, (unsigned)media_type,
                (unsigned)load_segment, (unsigned)sector_count,
                load_lba);

    if (bootable != ELTORITO_BOOTABLE) {
        uart_printf("[LDR] Boot entry not marked bootable — proceeding anyway\n");
    }
    if (load_lba == 0) {
        uart_printf("[LDR] Boot image LBA is 0 — invalid ISO\n");
        return;
    }

    /* ---- Step 3: Calculate load address ----------------------------- */
    /*
     * El Torito "load segment" field:
     *   0x0000 → use 0x07C0 (gives flat address 0x7C00)
     *   other  → use that segment × 16
     *
     * For "no emulation" entries (ISOLINUX, GRUB2), the image is loaded
     * at 0x7C00 and sector_count is in 512-byte units.
     *
     * For emulation entries (floppy/HD) the image is treated as a disk
     * image and the MBR is executed at 0x7C00.
     */
    uint32_t flat_load;
    if (load_segment == 0)
        flat_load = BOOT_LOAD_ADDR;   /* 0x7C00 */
    else
        flat_load = (uint32_t)load_segment * 16;

    /* Number of 2 KB ISO sectors to load */
    uint32_t iso_sectors_to_load;
    if (media_type == ELTORITO_MEDIA_NONE) {
        /* sector_count is in 512-byte virtual sectors */
        if (sector_count == 0) {
            iso_sectors_to_load = 1;
        } else {
            iso_sectors_to_load = ((uint32_t)sector_count * 512 + ISO_SECTOR - 1)
                                  / ISO_SECTOR;
        }
    } else if (media_type == ELTORITO_MEDIA_FD12 ||
               media_type == ELTORITO_MEDIA_FD144 ||
               media_type == ELTORITO_MEDIA_FD288) {
        /* Floppy emulation: 80 tracks × 2 heads × 18 sectors */
        iso_sectors_to_load = (2880 * 512 + ISO_SECTOR - 1) / ISO_SECTOR;
    } else {
        /* Hard-disk emulation: at least one MBR sector */
        iso_sectors_to_load = 1;
    }
    if (iso_sectors_to_load == 0) iso_sectors_to_load = 1;

    uart_printf("[LDR] Loading %u ISO sector(s) to guest 0x%x\n",
                iso_sectors_to_load, flat_load);

    /* ---- Step 4: Write boot image into guest RAM -------------------- */
    uint32_t dst = flat_load;
    for (uint32_t s = 0; s < iso_sectors_to_load; s++) {
        uint8_t buf[ISO_SECTOR];
        if (read_iso_sector(iso, iso_size, load_lba + s, buf) != 0) {
            uart_printf("[LDR] Read error at LBA %u\n", load_lba + s);
            break;
        }
        for (size_t b = 0; b < ISO_SECTOR; b++)
            mmu_write8(ldr->mmu, (uint64_t)(dst + b), buf[b]);
        dst += ISO_SECTOR;
    }

    /* Ensure boot sector signature 0x55AA at flat_load + 510/511
       (some boot loaders verify this even on CD-ROM) */
    mmu_write8(ldr->mmu, (uint64_t)(flat_load + 510), 0x55);
    mmu_write8(ldr->mmu, (uint64_t)(flat_load + 511), 0xAA);

    /* ---- Step 5: Set up BIOS environment ---------------------------- */
    setup_bios_environment(ldr->mmu, ldr->mmu->size);

    /* ---- Step 6: Initialise CPU to real-mode BIOS post-reset state -- */
    cpu_reset(ldr->cpu);

    /* Real-mode register state expected by BIOS boot loaders:
         CS  = 0x0000   (flat, since CS base = CS×16 = 0)
         IP  = 0x7C00
         SS  = 0x0000
         SP  = 0x7C00   (stack just below boot image)
         DL  = 0x80     (drive number — 0x80 = first hard/CD drive)
         ES  = 0x0000
         SI  = 0x1000   (pointer to El Torito drive spec packet)
       All other registers = 0
    */
    ldr->cpu->rip              = (uint64_t)flat_load;
    ldr->cpu->regs[REG_RSP]    = 0x7C00;
    ldr->cpu->rsp              = 0x7C00;
    ldr->cpu->regs[REG_RDX]    = 0x0080;   /* DL = 0x80 (boot drive)  */
    ldr->cpu->regs[REG_RSI]    = 0x1000;   /* SI = El Torito spec pkt */
    ldr->cpu->rflags           = 0x0002;   /* reserved bit 1 = 1      */
    ldr->cpu->mode             = CPU_MODE_REAL;
    ldr->cpu->halted           = 0;

    /* CR0.PE = 0 ensures we start in real mode */
    ldr->cpu->cr0 = 0;

    uart_printf("[LDR] CPU reset: RIP=0x%llx SP=0x7C00 DL=0x80 mode=REAL\n",
                (unsigned long long)ldr->cpu->rip);

    /* ---- Step 7: Run the boot image --------------------------------- */
    /* Allow up to 100 million instructions for a real boot sequence */
    cpu_run(ldr->cpu, 100000000UL);
}

/* -----------------------------------------------------------------------
 * loader_boot_elf — load and execute a flat x86_64 ELF binary
 * --------------------------------------------------------------------- */
void loader_boot_elf(Loader *ldr, const uint8_t *elf_data, size_t elf_size)
{
    if (elf_load(ldr->mmu, ldr->cpu, elf_data, elf_size) != 0) {
        uart_printf("[LDR] ELF load failed\n");
        return;
    }
    ldr->cpu->halted = 0;
    ldr->cpu->mode   = CPU_MODE_LONG;  /* ELF binaries are 64-bit */
    uart_printf("[LDR] ELF entry 0x%llx — running\n",
                (unsigned long long)ldr->cpu->rip);
    cpu_run(ldr->cpu, 100000000UL);
}
