#include "usb.h"
#include "uart.h"
#include <stdint.h>
#include "flooflibc.h"

/* -----------------------------------------------------------------------
 * MMIO helpers
 * --------------------------------------------------------------------- */
static inline void w32(uint32_t a, uint32_t v){ *(volatile uint32_t*)(uintptr_t)a=v; }
static inline uint32_t r32(uint32_t a)        { return *(volatile uint32_t*)(uintptr_t)a; }
static inline uint8_t  r8 (uint32_t a)        { return *(volatile uint8_t *)(uintptr_t)a; }

static void udelay(uint32_t us){ for(volatile uint32_t i=0;i<us*100;i++); }

/* -----------------------------------------------------------------------
 * DMA bounce buffer — all transfers use this staging area.
 * 4 KB, 4 KB-aligned; shared by all concurrent single-threaded transfers.
 * --------------------------------------------------------------------- */
#define DMA_BUF_SZ 4096
static uint8_t s_dma[DMA_BUF_SZ] __attribute__((aligned(4096)));

/* -----------------------------------------------------------------------
 * EHCI queue-head and qTD structures
 * --------------------------------------------------------------------- */
#define QTD_PID_SETUP 2
#define QTD_PID_IN    1
#define QTD_PID_OUT   0
#define QTD_ACTIVE    (1u<<7)
#define QTD_HALT      (1u<<6)
#define QTD_IOC       (1u<<15)
#define QTD_CERR(n)   ((n)<<10)
#define QTD_TBYTES(n) ((n)<<16)
#define QTD_DT(n)     ((n)<<31)

typedef struct __attribute__((packed,aligned(32))){ uint32_t next,alt,tok,buf[5]; } qTD;
typedef struct __attribute__((packed,aligned(32))){
    uint32_t hlp,epc,cap,cur,nxt,alt,tok,buf[5];
} QH;

static qTD s_qtd __attribute__((aligned(32)));
static QH  s_qh  __attribute__((aligned(32)));

static uint32_t phys32(const void *p){ return (uint32_t)(uintptr_t)p; }

/* -----------------------------------------------------------------------
 * EHCI reset + start
 * --------------------------------------------------------------------- */
static int ehci_reset(uint32_t op)
{
    w32(op+EHCI_USBCMD,0); udelay(2000);
    w32(op+EHCI_USBCMD,EHCI_CMD_HCRESET);
    for(int i=0;i<100;i++){ udelay(1000); if(!(r32(op+EHCI_USBCMD)&EHCI_CMD_HCRESET)) return 0; }
    uart_printf("[USB] EHCI reset timeout\n"); return -1;
}
static void ehci_start(uint32_t op)
{
    w32(op+EHCI_USBINTR,0);
    w32(op+EHCI_PERIODICLISTBASE,0);
    w32(op+EHCI_ASYNCLISTADDR,phys32(&s_qh));
    w32(op+EHCI_USBCMD,EHCI_CMD_RUN);
    udelay(1000);
    w32(op+EHCI_CONFIGFLAG,1);
    udelay(1000);
}

/* -----------------------------------------------------------------------
 * Port reset — returns 1 if device present
 * --------------------------------------------------------------------- */
static int port_reset(uint32_t op, int port)
{
    uint32_t ps = r32(op+EHCI_PORTSC(port));
    if(!(ps&EHCI_PORT_CONNECT)) return 0;
    w32(op+EHCI_PORTSC(port), ps|EHCI_PORT_POWER); udelay(20000);
    w32(op+EHCI_PORTSC(port), r32(op+EHCI_PORTSC(port))|EHCI_PORT_RESET); udelay(60000);
    w32(op+EHCI_PORTSC(port), r32(op+EHCI_PORTSC(port))&~EHCI_PORT_RESET); udelay(10000);
    uart_printf("[USB] Port %d portsc=0x%x\n", port, r32(op+EHCI_PORTSC(port)));
    return 1;
}

/* -----------------------------------------------------------------------
 * Queue head setup
 * --------------------------------------------------------------------- */
static void qh_setup(uint32_t op, uint8_t addr, uint8_t ep, uint16_t mps, int ctrl)
{
    (void)op;
    memset(&s_qh,0,sizeof(s_qh));
    s_qh.hlp = phys32(&s_qh)|0x2;
    s_qh.epc = (uint32_t)addr | ((uint32_t)ep<<8) | (2u<<12)
             | (ctrl?(1u<<14):0) | (1u<<15) | ((uint32_t)mps<<16);
    s_qh.cap = 1u<<30;
    s_qh.nxt = 1; s_qh.alt = 1;
}

/* -----------------------------------------------------------------------
 * Submit one qTD and poll until complete
 * --------------------------------------------------------------------- */
static int qtd_run(uint32_t op, uint8_t pid, int dt, void *buf, uint32_t len)
{
    memset(&s_qtd,0,sizeof(s_qtd));
    s_qtd.next=1; s_qtd.alt=1;
    s_qtd.tok = QTD_ACTIVE|QTD_CERR(3)|((uint32_t)pid<<8)|QTD_TBYTES(len)|QTD_DT(dt)|QTD_IOC;
    s_qtd.buf[0]=phys32(buf);
    for(int i=1;i<5;i++) s_qtd.buf[i]=(s_qtd.buf[i-1]&~0xFFFu)+0x1000u;
    s_qh.nxt=phys32(&s_qtd); s_qh.alt=1; s_qh.tok=0;
    w32(op+EHCI_USBCMD, r32(op+EHCI_USBCMD)|EHCI_CMD_ASE); udelay(100);
    for(int i=0;i<50000;i++){
        udelay(100);
        uint32_t t=s_qtd.tok;
        if(!(t&QTD_ACTIVE)){ if(t&QTD_HALT){ uart_printf("[USB] qTD halt tok=0x%x\n",t); return -1; } return 0; }
    }
    uart_printf("[USB] qTD timeout\n"); return -1;
}

/* -----------------------------------------------------------------------
 * Control transfer: SETUP [+ DATA] + STATUS
 * --------------------------------------------------------------------- */
static int ctrl_xfer(uint32_t op, uint8_t addr,
                     const uint8_t setup[8], uint8_t *in, uint16_t in_len)
{
    qh_setup(op, addr, 0, 64, 1);
    memcpy(s_dma, setup, 8);
    if(qtd_run(op, QTD_PID_SETUP, 0, s_dma, 8)) return -1;
    if(in_len && in){
        uint16_t n = in_len>DMA_BUF_SZ ? (uint16_t)DMA_BUF_SZ : in_len;
        memset(s_dma,0,n);
        if(qtd_run(op, QTD_PID_IN, 1, s_dma, n)) return -1;
        memcpy(in, s_dma, n);
    }
    uint8_t spid = in_len ? QTD_PID_OUT : QTD_PID_IN;
    return qtd_run(op, spid, 1, s_dma, 0);
}

/* -----------------------------------------------------------------------
 * Bulk transfer (chunked through DMA buffer, with data-toggle tracking)
 * --------------------------------------------------------------------- */
static int bulk_xfer(uint32_t op, uint8_t addr, uint8_t ep,
                     uint8_t pid, uint16_t mps,
                     uint8_t *buf, uint32_t len, int *dt)
{
    qh_setup(op, addr, ep&0xF, mps, 0);
    uint32_t off=0;
    while(off<len){
        uint32_t chunk=len-off; if(chunk>DMA_BUF_SZ) chunk=DMA_BUF_SZ;
        if(pid==QTD_PID_OUT) memcpy(s_dma, buf+off, chunk);
        else memset(s_dma,0,chunk);
        if(qtd_run(op, pid, *dt, s_dma, chunk)) return -1;
        if(pid==QTD_PID_IN) memcpy(buf+off, s_dma, chunk);
        *dt^=1; off+=chunk;
    }
    return 0;
}

/* -----------------------------------------------------------------------
 * Interrupt transfer (single packet, non-blocking poll — returns 0 if NAK)
 * --------------------------------------------------------------------- */
static int intr_xfer(uint32_t op, uint8_t addr, uint8_t ep,
                     uint16_t mps, uint8_t *buf, uint8_t len, int *dt)
{
    qh_setup(op, addr, ep&0xF, mps, 0);
    memset(s_dma,0,len);
    memset(&s_qtd,0,sizeof(s_qtd));
    s_qtd.next=1; s_qtd.alt=1;
    s_qtd.tok = QTD_ACTIVE|QTD_CERR(1)|((uint32_t)QTD_PID_IN<<8)
              | QTD_TBYTES(len)|QTD_DT(*dt)|QTD_IOC;
    s_qtd.buf[0]=phys32(s_dma);
    for(int i=1;i<5;i++) s_qtd.buf[i]=(s_qtd.buf[i-1]&~0xFFFu)+0x1000u;
    s_qh.nxt=phys32(&s_qtd); s_qh.alt=1; s_qh.tok=0;
    w32(op+EHCI_USBCMD, r32(op+EHCI_USBCMD)|EHCI_CMD_ASE); udelay(100);
    /* Short poll — only a few iterations; return 0 (no data) on NAK */
    for(int i=0;i<200;i++){
        udelay(100);
        uint32_t t=s_qtd.tok;
        if(!(t&QTD_ACTIVE)){
            if(t&QTD_HALT) return 0; /* NAK/STALL treated as no data */
            memcpy(buf, s_dma, len);
            *dt^=1;
            return 1;
        }
    }
    return 0; /* no data this poll */
}

/* -----------------------------------------------------------------------
 * BOT command block wrapper
 * --------------------------------------------------------------------- */
static int bot_cmd(USBDev *d, const uint8_t *cdb, uint8_t cdb_len,
                   uint8_t *data, uint32_t dlen, uint8_t dir)
{
    uint8_t cbw[BOT_CBW_SIZE]; memset(cbw,0,BOT_CBW_SIZE);
    cbw[0]=(uint8_t)(BOT_CBW_SIGNATURE); cbw[1]=(uint8_t)(BOT_CBW_SIGNATURE>>8);
    cbw[2]=(uint8_t)(BOT_CBW_SIGNATURE>>16); cbw[3]=(uint8_t)(BOT_CBW_SIGNATURE>>24);
    d->cls.msc.bot_tag++;
    cbw[4]=(uint8_t)d->cls.msc.bot_tag; cbw[5]=(uint8_t)(d->cls.msc.bot_tag>>8);
    cbw[6]=(uint8_t)(d->cls.msc.bot_tag>>16); cbw[7]=(uint8_t)(d->cls.msc.bot_tag>>24);
    cbw[8]=(uint8_t)dlen; cbw[9]=(uint8_t)(dlen>>8);
    cbw[10]=(uint8_t)(dlen>>16); cbw[11]=(uint8_t)(dlen>>24);
    cbw[12]=dir; cbw[14]=cdb_len;
    memcpy(cbw+15,cdb,cdb_len);
    int dt_out=0,dt_in=0;
    if(bulk_xfer(d->op_base,d->dev_addr,d->ep_bulk_out,
                 QTD_PID_OUT,d->bulk_mps,cbw,BOT_CBW_SIZE,&dt_out)) return -1;
    if(dlen && data){
        uint8_t pid=(dir==BOT_DIR_IN)?QTD_PID_IN:QTD_PID_OUT;
        uint8_t ep =(dir==BOT_DIR_IN)?d->ep_bulk_in:d->ep_bulk_out;
        int *dt=(dir==BOT_DIR_IN)?&dt_in:&dt_out;
        if(bulk_xfer(d->op_base,d->dev_addr,ep,pid,d->bulk_mps,data,dlen,dt)) return -1;
    }
    uint8_t csw[BOT_CSW_SIZE]; memset(csw,0,BOT_CSW_SIZE);
    if(bulk_xfer(d->op_base,d->dev_addr,d->ep_bulk_in,
                 QTD_PID_IN,d->bulk_mps,csw,BOT_CSW_SIZE,&dt_in)) return -1;
    uint32_t sig=(uint32_t)csw[0]|((uint32_t)csw[1]<<8)|((uint32_t)csw[2]<<16)|((uint32_t)csw[3]<<24);
    if(sig!=BOT_CSW_SIGNATURE||csw[12]){ uart_printf("[USB] CSW err sig=0x%x st=%u\n",sig,csw[12]); return -1; }
    return 0;
}

/* -----------------------------------------------------------------------
 * Hub class helper — port feature
 * --------------------------------------------------------------------- */
static int hub_port_feat(uint32_t op, uint8_t addr, uint8_t req,
                         uint8_t feat, uint8_t port)
{
    uint8_t setup[8]={ 0x23, req, feat, 0, port, 0, 0, 0 };
    return ctrl_xfer(op, addr, setup, NULL, 0);
}
static int hub_port_status(uint32_t op, uint8_t addr, uint8_t port,
                            uint32_t *st_out)
{
    uint8_t setup[8]={ 0xA3, HUB_REQ_GET_STATUS, 0,0, port, 0, 4, 0 };
    uint8_t buf[4]={0};
    if(ctrl_xfer(op, addr, setup, buf, 4)) return -1;
    *st_out=(uint32_t)buf[0]|((uint32_t)buf[1]<<8)|((uint32_t)buf[2]<<16)|((uint32_t)buf[3]<<24);
    return 0;
}

/* -----------------------------------------------------------------------
 * Forward declaration for recursive enumeration
 * --------------------------------------------------------------------- */
static int enumerate_device(USBHost *host, uint8_t port_addr, int hub_idx);

/* -----------------------------------------------------------------------
 * Parse configuration descriptor and populate device endpoints
 * --------------------------------------------------------------------- */
static void parse_config(USBDev *d, const uint8_t *cfg, uint16_t total)
{
    uint8_t cur_class=0, cur_sub=0, cur_proto=0, cur_iface=0;
    for(uint16_t off=0; off<total; ){
        uint8_t dlen=cfg[off], dtype=cfg[off+1];
        if(dlen<2) break;
        if(dtype==USB_DT_INTERFACE && off+9<=total){
            cur_iface = cfg[off+2];
            cur_class = cfg[off+5];
            cur_sub   = cfg[off+6];
            cur_proto = cfg[off+7];
            /* Use first interface class if device class is 0 */
            if(d->usb_class==0){ d->usb_class=cur_class; d->usb_subclass=cur_sub; d->usb_protocol=cur_proto; }
            /* Tag CDC data interface */
            if(cur_class==USB_CLASS_CDC && cur_sub==CDC_SUBCLASS_ACM)
                d->cls.cdc.ctrl_iface=cur_iface;
            if(cur_class==USB_CLASS_CDC_DATA)
                d->cls.cdc.data_iface=cur_iface;
        }
        if(dtype==USB_DT_ENDPOINT && off+7<=total && d->num_eps<USB_MAX_ENDPOINTS){
            USBEndpoint *ep=&d->eps[d->num_eps++];
            ep->addr=cfg[off+2]; ep->type=cfg[off+3]&0x3;
            ep->mps=(uint16_t)cfg[off+4]|((uint16_t)cfg[off+5]<<8);
            if(ep->type==USB_EP_BULK){
                if(ep->addr&0x80){ d->ep_bulk_in =ep->addr&0xF; d->bulk_mps=ep->mps; }
                else              { d->ep_bulk_out=ep->addr&0xF; }
            }
            if(ep->type==USB_EP_INTERRUPT && (ep->addr&0x80)){
                d->ep_intr_in=ep->addr&0xF; d->intr_mps=ep->mps;
            }
        }
        off+=dlen;
    }
    (void)cur_class; (void)cur_sub; (void)cur_proto; (void)cur_iface;
}

/* -----------------------------------------------------------------------
 * Classify a device after parse_config
 * --------------------------------------------------------------------- */
static USBDevClass classify(USBDev *d)
{
    switch(d->usb_class){
    case USB_CLASS_MASS_STOR: return USB_DEV_MSC;
    case USB_CLASS_HUB:       return USB_DEV_HUB;
    case USB_CLASS_CDC:       return USB_DEV_CDC;
    case USB_CLASS_AUDIO:     return USB_DEV_AUDIO;
    case USB_CLASS_PRINTER:   return USB_DEV_PRINTER;
    case USB_CLASS_HID:
        switch(d->usb_protocol){
        case USB_HID_PROTO_KEYBOARD: return USB_DEV_KBD;
        case USB_HID_PROTO_MOUSE:    return USB_DEV_MOUSE;
        default:                     return USB_DEV_HID;
        }
    default: return USB_DEV_UNKNOWN;
    }
}

/* -----------------------------------------------------------------------
 * Class-specific initialisation after SET_CONFIGURATION
 * --------------------------------------------------------------------- */
static void class_init(USBHost *host, USBDev *d)
{
    uint32_t op=d->op_base;
    uint8_t  addr=d->dev_addr;

    switch(d->dev_class){

    case USB_DEV_MSC: {
        uint8_t cdb[6]={SCSI_TEST_UNIT_READY,0,0,0,0,0};
        bot_cmd(d,cdb,6,NULL,0,BOT_DIR_IN); /* may fail — ignore */
        uint8_t cap[8]={0};
        uint8_t cdb2[10]={SCSI_READ_CAPACITY,0,0,0,0,0,0,0,0,0};
        if(bot_cmd(d,cdb2,10,cap,8,BOT_DIR_IN)==0){
            d->cls.msc.num_blocks=((uint32_t)cap[0]<<24)|((uint32_t)cap[1]<<16)|((uint32_t)cap[2]<<8)|cap[3];
            d->cls.msc.num_blocks++;
            d->cls.msc.block_size=((uint32_t)cap[4]<<24)|((uint32_t)cap[5]<<16)|((uint32_t)cap[6]<<8)|cap[7];
            uart_printf("[USB] MSC: %u blocks x %u bytes\n",
                        d->cls.msc.num_blocks, d->cls.msc.block_size);
        }
        break;
    }

    case USB_DEV_KBD: {
        /* SET_PROTOCOL = boot protocol (0) */
        uint8_t s[8]={0x21,HID_REQ_SET_PROTOCOL,0,0,0,0,0,0};
        ctrl_xfer(op,addr,s,NULL,0);
        /* SET_IDLE = 0 (report only on change) */
        uint8_t si[8]={0x21,HID_REQ_SET_IDLE,0,0,0,0,0,0};
        ctrl_xfer(op,addr,si,NULL,0);
        uart_printf("[USB] Keyboard ready (intr ep=%u mps=%u)\n",
                    d->ep_intr_in, d->intr_mps);
        break;
    }

    case USB_DEV_MOUSE: {
        uint8_t s[8]={0x21,HID_REQ_SET_PROTOCOL,0,0,0,0,0,0};
        ctrl_xfer(op,addr,s,NULL,0);
        uint8_t si[8]={0x21,HID_REQ_SET_IDLE,0,0,0,0,0,0};
        ctrl_xfer(op,addr,si,NULL,0);
        uart_printf("[USB] Mouse ready (intr ep=%u mps=%u)\n",
                    d->ep_intr_in, d->intr_mps);
        break;
    }

    case USB_DEV_HID: {
        uint8_t si[8]={0x21,HID_REQ_SET_IDLE,0,0,0,0,0,0};
        ctrl_xfer(op,addr,si,NULL,0);
        uart_printf("[USB] Generic HID ready\n");
        break;
    }

    case USB_DEV_CDC: {
        /* SET_LINE_CODING: 115200 8N1 */
        uint8_t lc[7]={ 0x00,0xC2,0x01,0x00, 0,0,8 }; /* 115200 LE */
        uint8_t s[8]={ 0x21,CDC_REQ_SET_LINE_CODING,0,0,
                       d->cls.cdc.ctrl_iface,0,7,0 };
        memcpy(s_dma,s,8); memcpy(s_dma+8,lc,7);
        /* Control write with data */
        qh_setup(op,addr,0,64,1);
        memcpy(s_dma,s,8);
        if(qtd_run(op,QTD_PID_SETUP,0,s_dma,8)==0){
            memcpy(s_dma,lc,7);
            qtd_run(op,QTD_PID_OUT,1,s_dma,7);
            qtd_run(op,QTD_PID_IN,1,s_dma,0);
        }
        /* SET_CONTROL_LINE_STATE: DTR+RTS */
        uint8_t sc[8]={ 0x21,CDC_REQ_SET_CTRL_STATE,0x03,0,
                        d->cls.cdc.ctrl_iface,0,0,0 };
        ctrl_xfer(op,addr,sc,NULL,0);
        d->cls.cdc.lc.baud=115200; d->cls.cdc.lc.bits=8;
        uart_printf("[USB] CDC/ACM serial ready (bulk in=%u out=%u)\n",
                    d->ep_bulk_in, d->ep_bulk_out);
        break;
    }

    case USB_DEV_AUDIO: {
        /* Query sample rate via GET_CUR on Terminal — best-effort */
        uint8_t s[8]={ 0xA1,AUDIO_REQ_GET_CUR,0,AUDIO_CS_VOLUME,
                       0x01,0,2,0 };
        uint8_t vbuf[2]={0};
        if(ctrl_xfer(op,addr,s,vbuf,2)==0){
            d->cls.audio.vol_db256=(int16_t)((uint16_t)vbuf[0]|((uint16_t)vbuf[1]<<8));
        }
        uart_printf("[USB] Audio device ready (vol=%d/256 dB)\n",
                    (int)d->cls.audio.vol_db256);
        break;
    }

    case USB_DEV_PRINTER: {
        uint8_t s[8]={ 0xA1,PRINTER_REQ_GET_PORT_STATUS,0,0,0,0,1,0 };
        uint8_t st=0;
        if(ctrl_xfer(op,addr,s,&st,1)==0) d->cls.printer.port_status=st;
        uart_printf("[USB] Printer ready (status=0x%x bidir=%d)\n",
                    d->cls.printer.port_status, d->cls.printer.bidir);
        break;
    }

    case USB_DEV_HUB: {
        /* Get hub descriptor to find port count */
        uint8_t s[8]={ 0xA0,HUB_REQ_GET_DESCRIPTOR,0,USB_DT_HUB,0,0,8,0 };
        uint8_t hdesc[8]={0};
        if(ctrl_xfer(op,addr,s,hdesc,8)==0){
            d->cls.hub.num_ports=hdesc[2];
            if(d->cls.hub.num_ports>USB_HUB_MAX_PORTS)
                d->cls.hub.num_ports=USB_HUB_MAX_PORTS;
        }
        uart_printf("[USB] Hub: %u ports\n", d->cls.hub.num_ports);
        /* Power all ports */
        for(uint8_t p=1;p<=d->cls.hub.num_ports;p++)
            hub_port_feat(op,addr,HUB_REQ_SET_FEATURE,HUB_FEAT_PORT_POWER,p);
        udelay(100000);
        /* Enumerate downstream devices */
        for(uint8_t p=1;p<=d->cls.hub.num_ports;p++){
            uint32_t st=0;
            if(hub_port_status(op,addr,p,&st)) continue;
            if(!(st&HUB_PORT_ST_CONNECT)) continue;
            hub_port_feat(op,addr,HUB_REQ_SET_FEATURE,HUB_FEAT_PORT_RESET,p);
            udelay(80000);
            hub_port_feat(op,addr,HUB_REQ_CLEAR_FEATURE,HUB_FEAT_PORT_RESET,p);
            udelay(20000);
            int idx=enumerate_device(host,addr,p);
            if(idx>=0 && (uint8_t)p<=USB_HUB_MAX_PORTS)
                d->cls.hub.child[p-1]=(uint8_t)idx;
        }
        break;
    }

    default: break;
    }
}

/* -----------------------------------------------------------------------
 * enumerate_device — assign an address and fully configure one device.
 * port_addr: address of the hub this device is behind (0 = root hub).
 * hub_port : downstream port number on that hub.
 * Returns the device-table index, or -1 on failure.
 * --------------------------------------------------------------------- */
static int enumerate_device(USBHost *host, uint8_t port_addr, int hub_port)
{
    (void)port_addr; (void)hub_port;

    if(host->n_devs>=USB_MAX_DEVICES){
        uart_printf("[USB] Device table full\n"); return -1;
    }

    USBDev *d=&host->devs[host->n_devs];
    memset(d,0,sizeof(*d));
    d->op_base=host->op_base;
    d->dev_addr=0; /* default address */
    d->bulk_mps=64; d->intr_mps=8;

    /* --- GET_DESCRIPTOR(Device, 18 bytes) at address 0 --- */
    {
        uint8_t s[8]={ 0x80,USB_REQ_GET_DESCRIPTOR,0,USB_DT_DEVICE,0,0,18,0 };
        uint8_t desc[18]={0};
        if(ctrl_xfer(host->op_base,0,s,desc,18)){
            uart_printf("[USB] GET_DESCRIPTOR(dev) failed\n"); return -1;
        }
        d->usb_class=(desc[4]);
        d->usb_subclass=(desc[5]);
        d->usb_protocol=(desc[6]);
        d->vid=(uint16_t)desc[8]|((uint16_t)desc[9]<<8);
        d->pid=(uint16_t)desc[10]|((uint16_t)desc[11]<<8);
        uart_printf("[USB] Device VID=0x%x PID=0x%x class=0x%x\n",
                    d->vid,d->pid,d->usb_class);
    }

    /* --- SET_ADDRESS --- */
    uint8_t new_addr=(uint8_t)(host->n_devs+1);
    {
        uint8_t s[8]={ 0x00,USB_REQ_SET_ADDRESS,new_addr,0,0,0,0,0 };
        if(ctrl_xfer(host->op_base,0,s,NULL,0)){
            uart_printf("[USB] SET_ADDRESS failed\n"); return -1;
        }
    }
    d->dev_addr=new_addr;
    udelay(5000);

    /* --- GET_DESCRIPTOR(Config, 255 bytes) --- */
    {
        uint8_t s[8]={ 0x80,USB_REQ_GET_DESCRIPTOR,0,USB_DT_CONFIG,0,0,255,0 };
        uint8_t cfg[255]={0};
        if(ctrl_xfer(host->op_base,new_addr,s,cfg,255)){
            uart_printf("[USB] GET_DESCRIPTOR(cfg) failed\n"); return -1;
        }
        uint16_t total=(uint16_t)cfg[2]|((uint16_t)cfg[3]<<8);
        if(total>255) total=255;
        parse_config(d,cfg,total);
    }

    /* Detect bidirectional printer (has both bulk endpoints) */
    if(d->usb_class==USB_CLASS_PRINTER && d->ep_bulk_in)
        d->cls.printer.bidir=1;

    /* --- SET_CONFIGURATION(1) --- */
    {
        uint8_t s[8]={ 0x00,USB_REQ_SET_CONFIGURATION,1,0,0,0,0,0 };
        if(ctrl_xfer(host->op_base,new_addr,s,NULL,0)){
            uart_printf("[USB] SET_CONFIG failed\n"); return -1;
        }
    }
    udelay(5000);

    d->dev_class=classify(d);
    d->active=1;
    int idx=host->n_devs++;

    uart_printf("[USB] Enumerated device %d: class=%d addr=%u\n",
                idx, (int)d->dev_class, new_addr);

    class_init(host, d);
    return idx;
}

/* -----------------------------------------------------------------------
 * usb_host_init
 * --------------------------------------------------------------------- */
int usb_host_init(USBHost *host)
{
    memset(host,0,sizeof(*host));

    uint8_t caplength=r8(USB_EHCI_BASE+EHCI_CAPLENGTH);
    host->op_base=(uint32_t)USB_EHCI_BASE+caplength;
    uart_printf("[USB] EHCI op_base=0x%x\n", host->op_base);

    if(ehci_reset(host->op_base)) return -1;
    ehci_start(host->op_base);

    /* Detect number of ports from HCSPARAMS[N_PORTS] bits[3:0] */
    uint32_t hcs=r32((uint32_t)USB_EHCI_BASE+EHCI_HCSPARAMS);
    host->num_ports=(uint8_t)(hcs&0xF);
    if(host->num_ports==0) host->num_ports=1;
    uart_printf("[USB] %u root-hub port(s)\n", host->num_ports);

    int found=0;
    for(uint8_t p=0;p<host->num_ports;p++){
        if(!port_reset(host->op_base,p)) continue;
        udelay(10000);
        int idx=enumerate_device(host,0,p);
        if(idx>=0) found++;
    }

    uart_printf("[USB] Enumeration complete: %d device(s)\n", host->n_devs);
    return found;
}

/* -----------------------------------------------------------------------
 * usb_host_poll — service all interrupt-endpoint devices
 * --------------------------------------------------------------------- */
int usb_host_poll(USBHost *host)
{
    int total=0;
    for(int i=0;i<host->n_devs;i++){
        USBDev *d=&host->devs[i];
        if(!d->active || !d->ep_intr_in) continue;

        switch(d->dev_class){
        case USB_DEV_KBD: {
            int dt=0;
            uint8_t buf[8]={0};
            if(intr_xfer(host->op_base,d->dev_addr,d->ep_intr_in,
                         d->intr_mps,buf,8,&dt)){
                if(memcmp(&d->cls.kbd.last,buf,8)){
                    memcpy(&d->cls.kbd.last,buf,8);
                    uart_printf("[KBD] mod=0x%x key=0x%x\n",buf[0],buf[2]);
                }
                total++;
            }
            break;
        }
        case USB_DEV_MOUSE: {
            int dt=0;
            uint8_t buf[4]={0};
            if(intr_xfer(host->op_base,d->dev_addr,d->ep_intr_in,
                         d->intr_mps,buf,4,&dt)){
                if(memcmp(&d->cls.mouse.last,buf,4)){
                    memcpy(&d->cls.mouse.last,buf,4);
                    uart_printf("[MOUSE] btn=0x%x dx=%d dy=%d\n",
                                buf[0],(int8_t)buf[1],(int8_t)buf[2]);
                }
                total++;
            }
            break;
        }
        case USB_DEV_HID: {
            int dt=0;
            uint8_t buf[64]={0};
            uint8_t n=(uint8_t)(d->intr_mps>64?64:d->intr_mps);
            if(intr_xfer(host->op_base,d->dev_addr,d->ep_intr_in,
                         d->intr_mps,buf,n,&dt)){
                memcpy(d->cls.hid.report,buf,n);
                d->cls.hid.len=n;
                total++;
            }
            break;
        }
        default: break;
        }
    }
    return total;
}

/* -----------------------------------------------------------------------
 * usb_host_find
 * --------------------------------------------------------------------- */
USBDev *usb_host_find(USBHost *host, USBDevClass cls)
{
    for(int i=0;i<host->n_devs;i++){
        if(host->devs[i].active && host->devs[i].dev_class==cls)
            return &host->devs[i];
    }
    return NULL;
}

/* -----------------------------------------------------------------------
 * Mass Storage
 * --------------------------------------------------------------------- */
int usb_msc_read_blocks(USBDev *d, uint32_t lba, uint32_t n, uint8_t *buf)
{
    if(!d||d->dev_class!=USB_DEV_MSC) return -1;
    uint8_t cdb[10]={ SCSI_READ10,0,
        (uint8_t)(lba>>24),(uint8_t)(lba>>16),(uint8_t)(lba>>8),(uint8_t)lba,
        0,(uint8_t)(n>>8),(uint8_t)n,0 };
    return bot_cmd(d,cdb,10,buf,n*d->cls.msc.block_size,BOT_DIR_IN);
}

int usb_msc_write_blocks(USBDev *d, uint32_t lba, uint32_t n, const uint8_t *buf)
{
    if(!d||d->dev_class!=USB_DEV_MSC) return -1;
    uint8_t cdb[10]={ SCSI_WRITE10,0,
        (uint8_t)(lba>>24),(uint8_t)(lba>>16),(uint8_t)(lba>>8),(uint8_t)lba,
        0,(uint8_t)(n>>8),(uint8_t)n,0 };
    return bot_cmd(d,cdb,10,(uint8_t*)(uintptr_t)buf,n*d->cls.msc.block_size,BOT_DIR_OUT);
}

size_t usb_msc_read_iso(USBDev *d, uint8_t *buf, size_t buf_size)
{
    if(!d||d->dev_class!=USB_DEV_MSC) return 0;
    uint64_t total=(uint64_t)d->cls.msc.num_blocks*d->cls.msc.block_size;
    if(total>buf_size) total=buf_size;
    uint32_t nblk=(uint32_t)(total/d->cls.msc.block_size);
    const uint32_t CHUNK=64;
    uint32_t lba=0; uint8_t *dst=buf;
    while(lba<nblk){
        uint32_t n=nblk-lba; if(n>CHUNK) n=CHUNK;
        if(usb_msc_read_blocks(d,lba,n,dst)){ uart_printf("[USB] MSC read err lba=%u\n",lba); break; }
        dst+=(size_t)(n*d->cls.msc.block_size); lba+=n;
        if((lba&0x3FF)==0) uart_printf("[USB] Read %u/%u blocks\r",lba,nblk);
    }
    uart_printf("[USB] MSC read done: %u blocks\n",lba);
    return (size_t)((uint64_t)lba*d->cls.msc.block_size);
}

/* -----------------------------------------------------------------------
 * HID Keyboard
 * --------------------------------------------------------------------- */
int usb_kbd_poll(USBDev *d, USBKeyReport *rep)
{
    if(!d||d->dev_class!=USB_DEV_KBD||!rep) return 0;
    int dt=0;
    uint8_t buf[8]={0};
    if(!intr_xfer(d->op_base,d->dev_addr,d->ep_intr_in,d->intr_mps,buf,8,&dt)) return 0;
    memcpy(rep,buf,sizeof(*rep)); memcpy(&d->cls.kbd.last,buf,8); return 1;
}

int usb_kbd_set_leds(USBDev *d, uint8_t leds)
{
    if(!d||d->dev_class!=USB_DEV_KBD) return -1;
    uint8_t s[8]={ 0x21,HID_REQ_SET_REPORT,0,0x02,0,0,1,0 };
    uint8_t buf[1]={leds};
    qh_setup(d->op_base,d->dev_addr,0,64,1);
    memcpy(s_dma,s,8);
    if(qtd_run(d->op_base,QTD_PID_SETUP,0,s_dma,8)) return -1;
    s_dma[0]=leds;
    if(qtd_run(d->op_base,QTD_PID_OUT,1,s_dma,1)) return -1;
    if(qtd_run(d->op_base,QTD_PID_IN,1,s_dma,0)) return -1;
    d->cls.kbd.leds=leds; (void)buf; return 0;
}

/* -----------------------------------------------------------------------
 * HID Mouse
 * --------------------------------------------------------------------- */
int usb_mouse_poll(USBDev *d, USBMouseReport *rep)
{
    if(!d||d->dev_class!=USB_DEV_MOUSE||!rep) return 0;
    int dt=0;
    uint8_t buf[4]={0};
    if(!intr_xfer(d->op_base,d->dev_addr,d->ep_intr_in,d->intr_mps,buf,4,&dt)) return 0;
    memcpy(rep,buf,sizeof(*rep)); memcpy(&d->cls.mouse.last,buf,4); return 1;
}

/* -----------------------------------------------------------------------
 * Generic HID
 * --------------------------------------------------------------------- */
int usb_hid_poll(USBDev *d, uint8_t *buf, uint8_t *out_len)
{
    if(!d||d->dev_class!=USB_DEV_HID||!buf||!out_len) return 0;
    int dt=0;
    uint8_t n=(uint8_t)(d->intr_mps>64?64:d->intr_mps);
    if(!intr_xfer(d->op_base,d->dev_addr,d->ep_intr_in,d->intr_mps,buf,n,&dt)) return 0;
    *out_len=n; return 1;
}

/* -----------------------------------------------------------------------
 * CDC/ACM Serial
 * --------------------------------------------------------------------- */
int usb_cdc_set_line_coding(USBDev *d, uint32_t baud,
                             uint8_t stop, uint8_t parity, uint8_t bits)
{
    if(!d||d->dev_class!=USB_DEV_CDC) return -1;
    uint8_t lc[7]={ (uint8_t)baud,(uint8_t)(baud>>8),(uint8_t)(baud>>16),(uint8_t)(baud>>24),
                    stop, parity, bits };
    uint8_t s[8]={ 0x21,CDC_REQ_SET_LINE_CODING,0,0,d->cls.cdc.ctrl_iface,0,7,0 };
    qh_setup(d->op_base,d->dev_addr,0,64,1);
    memcpy(s_dma,s,8);
    if(qtd_run(d->op_base,QTD_PID_SETUP,0,s_dma,8)) return -1;
    memcpy(s_dma,lc,7);
    if(qtd_run(d->op_base,QTD_PID_OUT,1,s_dma,7)) return -1;
    if(qtd_run(d->op_base,QTD_PID_IN,1,s_dma,0)) return -1;
    d->cls.cdc.lc.baud=baud; d->cls.cdc.lc.stop=stop;
    d->cls.cdc.lc.parity=parity; d->cls.cdc.lc.bits=bits;
    return 0;
}

int usb_cdc_write(USBDev *d, const uint8_t *buf, uint32_t len)
{
    if(!d||d->dev_class!=USB_DEV_CDC) return -1;
    int dt=0;
    return bulk_xfer(d->op_base,d->dev_addr,d->ep_bulk_out,
                     QTD_PID_OUT,d->bulk_mps,(uint8_t*)(uintptr_t)buf,len,&dt);
}

int usb_cdc_read(USBDev *d, uint8_t *buf, uint32_t len)
{
    if(!d||d->dev_class!=USB_DEV_CDC) return -1;
    int dt=0;
    return bulk_xfer(d->op_base,d->dev_addr,d->ep_bulk_in,
                     QTD_PID_IN,d->bulk_mps,buf,len,&dt);
}

/* -----------------------------------------------------------------------
 * Audio (UAC 1.0)
 * --------------------------------------------------------------------- */
int usb_audio_set_mute(USBDev *d, int mute)
{
    if(!d||d->dev_class!=USB_DEV_AUDIO) return -1;
    uint8_t s[8]={ 0x21,AUDIO_REQ_SET_CUR,0,AUDIO_CS_MUTE,
                   d->cls.audio.ctrl_iface,0,1,0 };
    uint8_t val=(uint8_t)(mute?1:0);
    qh_setup(d->op_base,d->dev_addr,0,64,1);
    memcpy(s_dma,s,8);
    if(qtd_run(d->op_base,QTD_PID_SETUP,0,s_dma,8)) return -1;
    s_dma[0]=val;
    if(qtd_run(d->op_base,QTD_PID_OUT,1,s_dma,1)) return -1;
    qtd_run(d->op_base,QTD_PID_IN,1,s_dma,0);
    d->cls.audio.muted=mute; return 0;
}

int usb_audio_set_volume(USBDev *d, int16_t db256)
{
    if(!d||d->dev_class!=USB_DEV_AUDIO) return -1;
    uint8_t s[8]={ 0x21,AUDIO_REQ_SET_CUR,0,AUDIO_CS_VOLUME,
                   d->cls.audio.ctrl_iface,0,2,0 };
    qh_setup(d->op_base,d->dev_addr,0,64,1);
    memcpy(s_dma,s,8);
    if(qtd_run(d->op_base,QTD_PID_SETUP,0,s_dma,8)) return -1;
    s_dma[0]=(uint8_t)db256; s_dma[1]=(uint8_t)((uint16_t)db256>>8);
    if(qtd_run(d->op_base,QTD_PID_OUT,1,s_dma,2)) return -1;
    qtd_run(d->op_base,QTD_PID_IN,1,s_dma,0);
    d->cls.audio.vol_db256=db256; return 0;
}

/* -----------------------------------------------------------------------
 * Printer
 * --------------------------------------------------------------------- */
int usb_printer_get_status(USBDev *d, uint8_t *st)
{
    if(!d||d->dev_class!=USB_DEV_PRINTER||!st) return -1;
    uint8_t s[8]={ 0xA1,PRINTER_REQ_GET_PORT_STATUS,0,0,0,0,1,0 };
    if(ctrl_xfer(d->op_base,d->dev_addr,s,st,1)) return -1;
    d->cls.printer.port_status=*st; return 0;
}

int usb_printer_write(USBDev *d, const uint8_t *buf, uint32_t len)
{
    if(!d||d->dev_class!=USB_DEV_PRINTER) return -1;
    int dt=0;
    return bulk_xfer(d->op_base,d->dev_addr,d->ep_bulk_out,
                     QTD_PID_OUT,d->bulk_mps,(uint8_t*)(uintptr_t)buf,len,&dt);
}

int usb_printer_soft_reset(USBDev *d)
{
    if(!d||d->dev_class!=USB_DEV_PRINTER) return -1;
    uint8_t s[8]={ 0x21,PRINTER_REQ_SOFT_RESET,0,0,0,0,0,0 };
    return ctrl_xfer(d->op_base,d->dev_addr,s,NULL,0);
}