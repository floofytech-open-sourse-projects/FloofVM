#ifndef LOADER_H
#define LOADER_H

#include <stdint.h>
#include <stddef.h>
#include "flooflibc.h"

struct MMU;
struct CPU;
struct Devices;

typedef struct Loader {
    struct MMU     *mmu;
    struct CPU     *cpu;
    struct Devices *dev;
} Loader;

void loader_init(Loader *ldr, struct MMU *mmu,
                 struct CPU *cpu, struct Devices *dev);

/* Boot a real AMD64 ISO image via El Torito */
void loader_boot_iso(Loader *ldr);

/* Boot a flat 64-bit ELF binary */
void loader_boot_elf(Loader *ldr, const uint8_t *elf_data, size_t elf_size);

#endif /* LOADER_H */
