#ifndef CPU_H
#define CPU_H

#include <stdint.h>
#include <stddef.h>
#include "flooflibc.h"

struct MMU;
struct Devices;
struct Interrupts;
struct JIT;

/* -----------------------------------------------------------------------
 * General-purpose register indices  (matches x86_64 encoding order)
 * --------------------------------------------------------------------- */
#define REG_RAX  0
#define REG_RCX  1
#define REG_RDX  2
#define REG_RBX  3
#define REG_RSP  4
#define REG_RBP  5
#define REG_RSI  6
#define REG_RDI  7
#define REG_R8   8
#define REG_R9   9
#define REG_R10 10
#define REG_R11 11
#define REG_R12 12
#define REG_R13 13
#define REG_R14 14
#define REG_R15 15

/* RFLAGS bit positions */
#define RFLAGS_CF   (1ULL <<  0)
#define RFLAGS_PF   (1ULL <<  2)
#define RFLAGS_AF   (1ULL <<  4)
#define RFLAGS_ZF   (1ULL <<  6)
#define RFLAGS_SF   (1ULL <<  7)
#define RFLAGS_TF   (1ULL <<  8)
#define RFLAGS_IF   (1ULL <<  9)
#define RFLAGS_DF   (1ULL << 10)
#define RFLAGS_OF   (1ULL << 11)
#define RFLAGS_IOPL (3ULL << 12)

/* CPU execution modes */
#define CPU_MODE_REAL   0   /* 16-bit real mode  (initial state)        */
#define CPU_MODE_PROT   1   /* 32-bit protected mode                    */
#define CPU_MODE_LONG   2   /* 64-bit long mode                         */

/* -----------------------------------------------------------------------
 * Legacy FloofVM custom opcodes (used by the built-in demo ISO only)
 * --------------------------------------------------------------------- */
#define OP_MOV_RI  0x01
#define OP_MOV_RR  0x02
#define OP_ADD_RR  0x03
#define OP_SUB_RR  0x04
#define OP_CMP_RR  0x05
#define OP_JZ      0x06
#define OP_JMP_F   0x07   /* renamed from OP_JMP to avoid x86 clash   */
#define OP_LOAD    0x08
#define OP_STORE   0x09
#define OP_HLT     0xFF

/* -----------------------------------------------------------------------
 * x86 prefix bytes
 * --------------------------------------------------------------------- */
#define X86_PREFIX_LOCK   0xF0
#define X86_PREFIX_REPNZ  0xF2
#define X86_PREFIX_REPZ   0xF3
#define X86_PREFIX_SEG_ES 0x26
#define X86_PREFIX_SEG_CS 0x2E
#define X86_PREFIX_SEG_SS 0x36
#define X86_PREFIX_SEG_DS 0x3E
#define X86_PREFIX_SEG_FS 0x64
#define X86_PREFIX_SEG_GS 0x65
#define X86_PREFIX_OPSIZE 0x66   /* operand-size override              */
#define X86_PREFIX_ADSIZE 0x67   /* address-size override              */
#define X86_REX_BASE      0x40   /* REX prefix range 0x40–0x4F         */
#define X86_PREFIX_ESC2   0x0F   /* two-byte opcode escape             */

/* -----------------------------------------------------------------------
 * Decoded prefix flags (packed into a uint32_t)
 * --------------------------------------------------------------------- */
#define PFX_REX   (1u << 0)
#define PFX_REXW  (1u << 1)   /* REX.W — 64-bit operand size          */
#define PFX_REXR  (1u << 2)   /* REX.R — ModRM reg extension          */
#define PFX_REXX  (1u << 3)   /* REX.X — SIB index extension          */
#define PFX_REXB  (1u << 4)   /* REX.B — ModRM r/m / SIB base ext.   */
#define PFX_OPZ   (1u << 5)   /* 0x66 operand-size override           */
#define PFX_ADZ   (1u << 6)   /* 0x67 address-size override           */
#define PFX_REP   (1u << 7)   /* REP / REPE / REPZ                    */
#define PFX_REPNE (1u << 8)   /* REPNE / REPNZ                        */
#define PFX_ESC2  (1u << 9)   /* 0x0F two-byte escape                 */

/* -----------------------------------------------------------------------
 * CPU struct
 * --------------------------------------------------------------------- */
typedef struct CPU {
    /* General-purpose registers (64-bit) */
    uint64_t regs[16];

    /* Special-purpose registers */
    uint64_t rip;
    uint64_t rsp;       /* mirror of regs[RSP] for quick access */
    uint64_t rflags;

    /* Segment base addresses (flat model: CS/DS/ES/SS base = 0) */
    uint64_t cs_base;
    uint64_t ds_base;
    uint64_t es_base;
    uint64_t ss_base;
    uint64_t fs_base;
    uint64_t gs_base;

    /* Control registers */
    uint64_t cr0;       /* bit 0 = PE, bit 31 = PG */
    uint64_t cr3;       /* page directory base (not used — flat model) */
    uint64_t cr4;

    /* EFER MSR — bit 8 = LME (long mode enable), bit 10 = LMA */
    uint64_t efer;

    /* GDT / IDT (base + limit, not used for address translation) */
    uint64_t gdtr_base;  uint16_t gdtr_limit;
    uint64_t idtr_base;  uint16_t idtr_limit;

    /* Execution mode */
    int mode;           /* CPU_MODE_REAL / PROT / LONG */

    /* Halt / fault state */
    int halted;
    int fault;          /* 1 = unrecoverable fault, stops execution */

    /* Instruction count (for debugging) */
    uint64_t insn_count;

    /* Subsystem pointers */
    struct MMU        *mmu;
    struct Devices    *dev;
    struct Interrupts *intr;
    struct JIT        *jit;
} CPU;

/* -----------------------------------------------------------------------
 * Public API
 * --------------------------------------------------------------------- */
void cpu_init(CPU *cpu, struct MMU *mmu, struct Devices *dev,
              struct Interrupts *intr, struct JIT *jit);
void cpu_reset(CPU *cpu);
void cpu_step(CPU *cpu);
void cpu_run(CPU *cpu, size_t max_steps);

/* Set execution mode explicitly (used by loader after pmode setup) */
void cpu_set_mode(CPU *cpu, int mode);

#endif /* CPU_H */
